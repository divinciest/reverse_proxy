
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import ProtectedRoute from "@/components/auth/ProtectedRoute";
import Index from "./pages/Index";
import ArticleDetail from "./pages/ArticleDetail";
import NotFound from "./pages/NotFound";
import Admin from "./pages/Admin";
import SourceProfile from "./pages/SourceProfile";
import CompanyProfile from "./pages/CompanyProfile";
import ExpertProfile from "./pages/ExpertProfile";
import AuthorProfile from "./pages/AuthorProfile";
import SP500Page from "./pages/SP500Page";
import DowJonesPage from "./pages/DowJonesPage";
import TopicPage from "./pages/TopicPage";
import TopicsPage from "./pages/TopicsPage";
import AuthorsPage from "./pages/AuthorsPage";
import StocksPage from "./pages/StocksPage";
import MarketsPage from "./pages/MarketsPage";
import SubscriptionPage from "./pages/SubscriptionPage";
import AboutPremium from "./pages/AboutPremium";
import BooksPage from "./pages/BooksPage";
import BookDetailPage from "./pages/BookDetailPage";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import EconomicChartsPage from "./pages/EconomicChartsPage";
import ChartDetailPage from "./pages/ChartDetailPage";
import BillionairesPage from "./pages/BillionairesPage";
import BillionaireProfile from "./pages/BillionaireProfile";
import WidgetsPage from "./pages/WidgetsPage";
import WidgetDetailPage from "./pages/WidgetDetailPage";

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider delayDuration={300}>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<Index />} />
              <Route path="/article/:id" element={<ArticleDetail />} />
              <Route path="/source/:sourceId" element={<SourceProfile />} />
              <Route path="/company/:companyId" element={<CompanyProfile />} />
              <Route path="/expert/:expertId" element={<ExpertProfile />} />
              <Route path="/author/:authorId" element={<AuthorProfile />} />
              <Route path="/authors" element={<AuthorsPage />} />
              <Route path="/stocks" element={<StocksPage />} />
              <Route path="/books" element={<BooksPage />} />
              <Route path="/book/:bookId" element={<BookDetailPage />} />
              <Route path="/sp500" element={<SP500Page />} />
              <Route path="/dowjones" element={<DowJonesPage />} />
              <Route path="/topics" element={<TopicsPage />} />
              <Route path="/topic/:topicSlug" element={<TopicPage />} />
              <Route path="/markets" element={<MarketsPage />} />
              <Route path="/charts" element={<EconomicChartsPage />} />
              <Route path="/charts/:chartId" element={<ChartDetailPage />} />
              <Route path="/subscription" element={<SubscriptionPage />} />
              <Route path="/about-premium" element={<AboutPremium />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/billionaires" element={<BillionairesPage />} />
              <Route path="/billionaire/:billionaireId" element={<BillionaireProfile />} />
              <Route path="/widgets" element={<WidgetsPage />} />
              <Route path="/widget/:widgetId" element={<WidgetDetailPage />} />
              <Route path="*" element={<NotFound />} />
              
              {/* Protected routes that require authentication */}
              <Route element={<ProtectedRoute />}>
                <Route path="/profile" element={<div>Profile Page (Coming Soon)</div>} />
              </Route>
              
              {/* Protected routes that require admin privileges */}
              <Route element={<ProtectedRoute requireAdmin={true} />}>
                <Route path="/admin" element={<Admin />} />
                <Route path="/admin/*" element={<Admin />} />
              </Route>
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
