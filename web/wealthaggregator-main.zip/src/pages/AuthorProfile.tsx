
import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import TopicBar from "@/components/TopicBar";
import { Button } from "@/components/ui/button";
import { Bell, Share2 } from "lucide-react";
import { getAuthor, getAuthorArticles } from "@/data/authors";
import AuthorSidebar from "@/components/author/AuthorSidebar";
import AuthorArticlesList from "@/components/author/AuthorArticlesList";
import { 
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator
} from "@/components/ui/breadcrumb";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Facebook, Twitter, Linkedin, Link2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const AuthorProfile = () => {
  const { authorId } = useParams<{ authorId: string }>();
  const author = getAuthor(authorId);
  const authorArticles = getAuthorArticles(authorId || "");
  const { toast } = useToast();
  
  if (!author) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="container mx-auto py-8 flex-1 flex flex-col items-center justify-center">
          <h1 className="text-2xl font-bold mb-4">Author not found</h1>
          <Link to="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleShare = (platform: string) => {
    const currentUrl = window.location.href;
    let shareUrl = "";
    
    switch (platform) {
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}`;
        break;
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(currentUrl)}&text=${encodeURIComponent(`Articles by ${author.name}`)}`;
        break;
      case "linkedin":
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(currentUrl)}`;
        break;
      case "copy":
        navigator.clipboard.writeText(currentUrl).then(() => {
          toast({
            title: "Link copied",
            description: "The author profile URL has been copied to your clipboard.",
            duration: 3000,
          });
        });
        return;
      default:
        return;
    }
    
    window.open(shareUrl, "_blank", "width=600,height=400");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t border-gray-300">
        <TopicBar />
      </div>
      
      <div className="container mx-auto py-8">
        <div className="mb-4">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink href="/" asChild>
                  <Link to="/">Home</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink href="/authors" asChild>
                  <Link to="/authors">Authors</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>{author.name}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
        
        <div className="mb-8">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-4xl font-bold font-serif mb-1">{author.name}</h1>
              <h2 className="text-xl text-gray-700 mb-4">{author.publication} {author.title}</h2>
            </div>
            
            <div className="flex gap-3">
              <Button className="gap-2 font-medium">
                <Bell size={18} />
                Get Alerts
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon">
                    <Share2 size={18} />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-white">
                  <DropdownMenuItem onClick={() => handleShare("facebook")}>
                    <Facebook size={16} className="mr-2 text-blue-600" />
                    Facebook
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleShare("twitter")}>
                    <Twitter size={16} className="mr-2 text-blue-400" />
                    Twitter
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleShare("linkedin")}>
                    <Linkedin size={16} className="mr-2 text-blue-700" />
                    LinkedIn
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleShare("copy")}>
                    <Link2 size={16} className="mr-2" />
                    Copy link
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="pb-6 mb-6">
              <p className="text-gray-700">{author.bio}</p>
              
              {author.twitterHandle && (
                <p className="mt-3">
                  <a href={`https://twitter.com/${author.twitterHandle}`} className="text-primary hover:underline">
                    @{author.twitterHandle}
                  </a>
                </p>
              )}
              
              {author.rssUrl && (
                <p className="mt-1">
                  <a href={author.rssUrl} className="text-primary hover:underline">
                    RSS Feed
                  </a>
                </p>
              )}
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <AuthorArticlesList 
                articles={authorArticles} 
                authorName={author.name}
              />
            </div>
          </div>
          
          <div className="lg:col-span-1">
            <AuthorSidebar author={author} articles={authorArticles} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthorProfile;
