
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Header from "@/components/Header";
import TopicBar from "@/components/TopicBar";
import StockTickerTape from "@/components/StockTickerTape";
import DateHeader from "@/components/DateHeader";
import ArticlesList from "@/components/ArticlesList";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import { convertApiArticleToUiArticle } from "@/utils/articleUtils";
import { useArticles } from "@/hooks/useArticles";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from "lucide-react";

const TopicPage = () => {
  const { topicSlug } = useParams<{ topicSlug: string }>();
  const { articles: apiArticles, isLoading, isApiAvailable } = useArticles();
  
  // Convert API articles to our data format
  const articles = apiArticles.map(convertApiArticleToUiArticle);
  
  // Decode the topic from the URL slug
  const topic = topicSlug ? decodeURIComponent(topicSlug.replace(/-/g, ' ')) : '';
  
  // Filter articles based on the topic
  const filteredArticles = articles.filter(article => 
    article.topics?.includes(topic) || article.tags?.includes(topic)
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t border-gray-300">
        <TopicBar />
      </div>
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="container mx-auto py-8 flex-1">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[{ label: "Topics", href: "/topics" }, { label: topic }]} />
        
        {!isApiAvailable && (
          <Alert className="mb-6 mt-4 bg-amber-50 border-amber-200">
            <Info className="h-4 w-4" />
            <AlertTitle>Using Demo Data</AlertTitle>
            <AlertDescription>
              API connection is unavailable. Showing demo articles instead of live data.
            </AlertDescription>
          </Alert>
        )}
        
        <Card className="mb-6 mt-4">
          <CardHeader className="pb-3">
            <CardTitle className="text-2xl font-serif">
              Topic: {topic}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              {isLoading ? "Loading articles..." : 
                `Displaying ${filteredArticles.length} articles related to ${topic}`}
            </p>
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
              <p className="mt-2 text-muted-foreground">Loading articles...</p>
            </div>
          </div>
        ) : filteredArticles.length > 0 ? (
          <ArticlesList 
            articles={filteredArticles} 
            view="grid"
            articlesPerPage={9}
          />
        ) : (
          <div className="text-center py-12">
            <p className="text-xl text-muted-foreground">No articles found for this topic.</p>
          </div>
        )}
      </main>

      <footer className="bg-gray-800 text-white py-6 border-t-4 border-gray-900">
        <div className="container mx-auto">
          <div className="text-center">
            <p className="font-serif text-lg">&copy; 2023 WealthManager.com - Financial News Aggregator</p>
            <p className="mt-1 text-gray-300">
              Providing aggregated financial content with AI-powered sentiment analysis
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default TopicPage;
