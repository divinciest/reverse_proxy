
import React, { useState } from "react";
import { useParams } from "react-router-dom";
import Header from "@/components/Header";
import TopicBar from "@/components/TopicBar";
import SourceProfileHeader from "@/components/source/SourceProfileHeader";
import SourceInfo from "@/components/source/SourceInfo";
import AllSourcesView from "@/components/source/AllSourcesView";
import SourceArticlesView from "@/components/source/SourceArticlesView";
import { useSourceArticles } from "@/hooks/useSourceArticles";

const SourceProfile = () => {
  const { sourceId } = useParams<{ sourceId: string }>();
  const [view, setView] = useState<"grid" | "list">("grid");
  
  // Handle "all" as a special case that shows all sources
  if (sourceId === "all") {
    return <AllSourcesView />;
  }
  
  const { 
    source, 
    sourceArticles, 
    lastFetched, 
    isLoading, 
    handleRefreshArticles 
  } = useSourceArticles(sourceId);

  if (!source) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-2xl font-serif font-bold mb-4">Source not found</h2>
          <a href="/">Return to Home</a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t border-gray-300">
        <TopicBar />
      </div>
      
      <div className="container mx-auto py-6">
        <SourceProfileHeader 
          onRefresh={handleRefreshArticles} 
          isLoading={isLoading} 
          view={view} 
          onViewChange={setView} 
        />
        
        <SourceInfo 
          source={source} 
          lastFetched={lastFetched} 
          articlesCount={sourceArticles.length} 
        />
        
        <SourceArticlesView 
          source={source}
          articles={sourceArticles}
          isLoading={isLoading}
          onRefresh={handleRefreshArticles}
        />
      </div>
    </div>
  );
};

export default SourceProfile;
