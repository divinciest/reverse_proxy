
import React from "react";
import AdminPage from "@/pages/admin/AdminPage";

const Admin = () => {
  return <AdminPage />;
};

export default Admin;
