import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import TopicBar from "@/components/TopicBar";
import StockTickerTape from "@/components/StockTickerTape";
import DateHeader from "@/components/DateHeader";
import { billionaires } from "@/data/billionaire";
import { getBestFaviconUrl } from "@/utils/favicon";
import BillionairesPageHeader from "@/components/billionaires/BillionairesPageHeader";
import BillionairesDisplaySection from "@/components/billionaires/BillionairesDisplaySection";
import BillionairesFooter from "@/components/billionaires/BillionairesFooter";

const BillionairesPage = () => {
  // Store company logos in state
  const [companyLogos, setCompanyLogos] = useState<Record<string, string>>({});
  
  // Load company logos on component mount
  React.useEffect(() => {
    const logos: Record<string, string> = {};
    
    billionaires.forEach(billionaire => {
      // Get main company logo
      const domain = billionaire.mainCompany.toLowerCase().replace(/[^a-z0-9]/g, '');
      logos[billionaire.id] = getBestFaviconUrl(billionaire.mainCompany, `${domain}.com`);
    });
    
    setCompanyLogos(logos);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="container mx-auto py-8 flex-1">
        <BillionairesPageHeader />
        <BillionairesDisplaySection billionaires={billionaires} companyLogos={companyLogos} />
      </main>

      <BillionairesFooter />
    </div>
  );
};

export default BillionairesPage;
