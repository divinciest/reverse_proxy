
import React, { useState, useEffect } from "react";
import Header from "@/components/Header";
import StockTickerTape from "@/components/StockTickerTape";
import DateHeader from "@/components/DateHeader";
import { getCompanies } from "@/utils/company/allCompanies";
import { getBestFaviconUrl } from "@/utils/favicon";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

import StocksPageHeader from "@/components/stocks/StocksPageHeader";
import StocksDisplaySection from "@/components/stocks/StocksDisplaySection";
import StocksFooter from "@/components/stocks/StocksFooter";

const StocksPage = () => {
  // Get all companies
  const companies = getCompanies();
  
  // Store company logos in state
  const [companyLogos, setCompanyLogos] = useState<Record<string, string>>({});
  
  // Load company logos on component mount
  useEffect(() => {
    const logos: Record<string, string> = {};
    
    // Only process companies if the array is not empty
    if (companies && companies.length > 0) {
      companies.forEach(company => {
        // Special handling for certain companies
        if (company.id === 'meta') {
          logos[company.id] = getBestFaviconUrl('Facebook', 'facebook.com');
        } else if (company.id === 'googl') {
          logos[company.id] = getBestFaviconUrl('Google', 'google.com');
        } else {
          // Get favicon URL for each company
          const domain = company.name.toLowerCase().includes(' inc') 
            ? company.name.toLowerCase().split(' inc')[0] 
            : company.name.toLowerCase();
          
          logos[company.id] = getBestFaviconUrl(company.name, `${domain.replace(/[^a-z0-9]/g, '')}.com`);
        }
      });
    }
    
    setCompanyLogos(logos);
  }, [companies]);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="container mx-auto py-8 flex-1">
        <StocksPageHeader />
        
        {companies.length === 0 && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>API Not Available</AlertTitle>
            <AlertDescription>
              Company data API is not implemented or unavailable. This system requires a real API connection.
            </AlertDescription>
          </Alert>
        )}
        
        <StocksDisplaySection companies={companies} companyLogos={companyLogos} />
      </main>

      <StocksFooter />
    </div>
  );
};

export default StocksPage;
