
import React, { useState, useEffect } from "react";
import HeaderWithAuth from "@/components/HeaderWithAuth";
import TopicBar from "@/components/TopicBar";
import NewsFeed from "@/components/NewsFeed";
import FeedFilters from "@/components/FeedFilters";
import SuggestionBanner from "@/components/SuggestionBanner";
import StockTickerTape from "@/components/StockTickerTape";
import { useAuth } from "@/hooks/useAuth";
import { useArticles } from "@/hooks/useArticles";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

/**
 * CRITICAL WARNING - ZERO TOLERANCE POLICY FOR MOCK DATA
 * 
 * ABSOLUTELY NO MOCK DATA IS ALLOWED IN THIS PAGE, UNDER ANY CIRCUMSTANCES.
 * 
 * This file MUST only fetch data EXCLUSIVELY from real API calls.
 * Even in the case of errors, testing, or development, NO HARDCODED DATA
 * or FALLBACK VALUES are permitted.
 * 
 * Violation of this policy is strictly forbidden.
 * 
 * If API calls fail:
 * - Display appropriate error states
 * - Log the error
 * - But NEVER fall back to sample/mock/hardcoded data
 * 
 * NO EXCEPTIONS. NO TEMPORARY SOLUTIONS.
 */

const Index = () => {
  const { isAuthenticated } = useAuth();
  const [isApiAvailable, setIsApiAvailable] = useState<boolean | null>(null);
  const [selectedFeedSources, setSelectedFeedSources] = useState<string[]>([]);
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>([]);
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);
  
  // Get article data including counts and companies
  // CRITICAL: Only use real API data - never generate mock data
  const { 
    sourcesArticleCounts, 
    companiesArticleCounts, 
    companies, 
    isLoading, 
    error 
  } = useArticles();
  
  // Check if the API is available
  useEffect(() => {
    const checkApi = async () => {
      try {
        // Make a fetch request with a short timeout to test API connectivity
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
        
        await fetch("https://api.advisorassist.ai/api/get_feeds_articles", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ urls: ["https://feeds.feedburner.com/TechCrunch/"], since: 1 }),
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        setIsApiAvailable(true);
      } catch (error) {
        console.error("API not available:", error);
        setIsApiAvailable(false);
      }
    };
    
    checkApi();
  }, []);

  // Handler for feed source selection from FeedFilters
  const handleFeedSourceChange = (sources: string[]) => {
    setSelectedFeedSources(sources);
  };

  // Handler for company selection from FeedFilters
  const handleCompanyChange = (companies: string[]) => {
    setSelectedCompanies(companies);
  };
  
  // Handler for topic selection from FeedFilters
  const handleTopicChange = (topics: string[]) => {
    setSelectedTopics(topics);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderWithAuth />
      <div className="border-t border-gray-300">
        <TopicBar />
      </div>
      
      <StockTickerTape />
      
      <div className="container mx-auto px-4 py-6">
        {isApiAvailable === false && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>API Connection Failed</AlertTitle>
            <AlertDescription>
              Unable to connect to the data API. This application requires a working API connection and cannot use mock data.
            </AlertDescription>
          </Alert>
        )}
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <FeedFilters 
              onFeedSourcesChange={handleFeedSourceChange}
              onCompaniesChange={handleCompanyChange}
              onTopicsChange={handleTopicChange}
              sourcesArticleCounts={sourcesArticleCounts}
              companiesArticleCounts={companiesArticleCounts}
              companiesData={companies}
            />
          </div>
          
          <div className="lg:col-span-3">
            <h1 className="text-3xl font-serif font-bold mb-6">
              Latest Financial News
            </h1>
            
            {!isAuthenticated && (
              <SuggestionBanner 
                title="Get personalized news and analysis"
                description="Sign up for a free account to personalize your feed and save your favorite articles."
                buttonText="Sign Up"
                buttonLink="/signup"
                className="mb-6"
              />
            )}
            
            <NewsFeed 
              selectedFeedSources={selectedFeedSources}
              selectedCompanies={selectedCompanies}
              selectedTags={selectedTopics}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
