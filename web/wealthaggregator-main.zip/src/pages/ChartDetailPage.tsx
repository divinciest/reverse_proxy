
import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import StockTickerTape from "@/components/StockTickerTape";
import EconomicChart from "@/components/economic/EconomicChart";
import { getChartById, getChartsByCategory } from "@/utils/economicChartsService";
import { ChartLine, Download, Image, Calendar, Clock, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import ChartCard from "@/components/economic/ChartCard";

const ChartDetailPage = () => {
  const { chartId } = useParams<{ chartId: string }>();
  const [showRecessions, setShowRecessions] = useState(true);
  const [timeframe, setTimeframe] = useState("all");
  
  // Fetch chart data
  const chart = chartId ? getChartById(chartId) : undefined;
  
  // Get related charts (same category)
  const relatedCharts = chart 
    ? getChartsByCategory(chart.category).filter(c => c.id !== chart.id).slice(0, 3) 
    : [];
  
  // Filter data points based on selected timeframe
  const filteredData = React.useMemo(() => {
    if (!chart) return [];
    
    const currentYear = new Date().getFullYear();
    
    switch (timeframe) {
      case "5y":
        return chart.dataPoints.filter(point => {
          const year = new Date(point.date).getFullYear();
          return year >= currentYear - 5;
        });
      case "10y":
        return chart.dataPoints.filter(point => {
          const year = new Date(point.date).getFullYear();
          return year >= currentYear - 10;
        });
      case "20y":
        return chart.dataPoints.filter(point => {
          const year = new Date(point.date).getFullYear();
          return year >= currentYear - 20;
        });
      case "30y":
        return chart.dataPoints.filter(point => {
          const year = new Date(point.date).getFullYear();
          return year >= currentYear - 30;
        });
      default:
        return chart.dataPoints;
    }
  }, [chart, timeframe]);

  if (!chart) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-10 text-center">
          <h1 className="text-3xl font-bold mb-4">Chart Not Found</h1>
          <p className="mb-6">The economic chart you're looking for couldn't be found.</p>
          <Button asChild>
            <Link to="/charts">Back to All Charts</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      
      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav 
          items={[
            { label: "Economic Charts", href: "/charts" },
            { label: chart.name }
          ]} 
        />
        
        <div className="my-4">
          <Button 
            variant="outline" 
            size="sm" 
            className="mb-4"
            asChild
          >
            <Link to="/charts">
              <ArrowLeft size={16} className="mr-1" />
              Back to All Charts
            </Link>
          </Button>
          
          <h1 className="text-3xl font-bold mb-2 flex items-center">
            <ChartLine size={28} className="mr-2 text-blue-500" />
            {chart.name} - Historical Chart
          </h1>
          <div className="flex flex-wrap gap-2 text-sm text-gray-600 mb-6">
            <span className="flex items-center">
              <Calendar size={14} className="mr-1" /> {chart.timeframe}
            </span>
            <span className="flex items-center">
              <Clock size={14} className="mr-1" /> Last updated: {new Date().toLocaleDateString()}
            </span>
          </div>
        </div>
        
        {/* Chart visualization and controls */}
        <div className="bg-white p-4 border rounded-lg shadow-sm mb-6">
          {/* Timeframe selector and controls */}
          <div className="flex flex-wrap justify-between items-center mb-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-gray-600">Click and drag or select:</span>
              <div className="flex gap-1">
                {["5y", "10y", "20y", "30y", "all"].map(period => (
                  <Button 
                    key={period}
                    variant={timeframe === period ? "default" : "outline"}
                    size="sm"
                    onClick={() => setTimeframe(period)}
                    className="text-xs h-8 px-2"
                  >
                    {period === "all" ? "All Years" : period}
                  </Button>
                ))}
              </div>
            </div>
            
            <div className="flex items-center gap-2 mt-2 sm:mt-0">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="show-recessions"
                  checked={showRecessions}
                  onChange={() => setShowRecessions(!showRecessions)}
                  className="mr-2 h-4 w-4"
                />
                <label htmlFor="show-recessions" className="text-sm">Show Recessions</label>
              </div>
              
              <Button variant="outline" size="sm" className="ml-2">
                <Download size={14} className="mr-1" />
                Download Data
              </Button>
              
              <Button variant="outline" size="sm">
                <Image size={14} className="mr-1" />
                Export Image
              </Button>
            </div>
          </div>
          
          {/* Main chart */}
          <EconomicChart 
            data={filteredData}

            height={450}
            showGrid={true}
            showRecessions={showRecessions}
            color="#3b82f6"
          />
        </div>
        
        {/* Chart information and statistics */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <Tabs defaultValue="description">
              <TabsList>
                <TabsTrigger value="description">Description</TabsTrigger>
                <TabsTrigger value="statistics">Statistics</TabsTrigger>
                <TabsTrigger value="faqs">FAQs</TabsTrigger>
              </TabsList>
              
              <TabsContent value="description" className="p-4">
                <h3 className="text-xl font-semibold mb-3">About {chart.name}</h3>
                <p className="text-gray-700 mb-4">{chart.description}</p>
                <p className="text-gray-700">
                  This chart shows historical data from {chart.timeframe}, allowing you to analyze trends, 
                  cycles, and correlations with other economic events. The gray vertical bands indicate 
                  recession periods as defined by the National Bureau of Economic Research (NBER).
                </p>
              </TabsContent>
              
              <TabsContent value="statistics" className="p-4">
                <h3 className="text-xl font-semibold mb-3">Key Statistics</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="border rounded p-3">
                    <p className="text-sm text-gray-600">Current Value</p>
                    <p className="text-2xl font-bold">{filteredData[filteredData.length - 1]?.value.toFixed(2)}</p>
                  </div>
                  <div className="border rounded p-3">
                    <p className="text-sm text-gray-600">All-Time High</p>
                    <p className="text-2xl font-bold">{Math.max(...filteredData.map(d => d.value)).toFixed(2)}</p>
                  </div>
                  <div className="border rounded p-3">
                    <p className="text-sm text-gray-600">All-Time Low</p>
                    <p className="text-2xl font-bold">{Math.min(...filteredData.map(d => d.value)).toFixed(2)}</p>
                  </div>
                  <div className="border rounded p-3">
                    <p className="text-sm text-gray-600">Average</p>
                    <p className="text-2xl font-bold">
                      {(filteredData.reduce((sum, d) => sum + d.value, 0) / filteredData.length).toFixed(2)}
                    </p>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="faqs" className="p-4">
                <h3 className="text-xl font-semibold mb-3">Frequently Asked Questions</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium">Why is this indicator important?</h4>
                    <p className="text-gray-700">
                      This economic indicator provides valuable insights into the overall health of the economy 
                      and can help predict future economic trends and financial market movements.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium">How is this data collected?</h4>
                    <p className="text-gray-700">
                      The data is collected from various government agencies, financial institutions, and 
                      market exchanges. It is then aggregated and standardized for consistency.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium">How often is this data updated?</h4>
                    <p className="text-gray-700">
                      Depending on the indicator, data is updated monthly or quarterly as new information 
                      becomes available from official sources.
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          <div>
            <Card>
              <CardContent className="p-4">
                <h3 className="text-lg font-semibold mb-3">Related Charts</h3>
                <div className="space-y-4">
                  {relatedCharts.map(relatedChart => (
                    <Link 
                      key={relatedChart.id} 
                      to={`/charts/${relatedChart.id}`}
                      className="block border rounded hover:shadow-sm p-3 transition-shadow"
                    >
                      <h4 className="font-medium mb-1">{relatedChart.name}</h4>
                      <p className="text-sm text-gray-600 mb-2">{relatedChart.category}</p>
                      <EconomicChart 
                        data={relatedChart.dataPoints} 
                        height={80} 
                        showGrid={false}
                      />
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChartDetailPage;
