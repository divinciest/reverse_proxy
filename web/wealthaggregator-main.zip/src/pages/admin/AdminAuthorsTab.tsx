
import React from "react";
import { Link } from "react-router-dom";
import TabContent from "@/components/admin/TabContent";
import { User, ExternalLink } from "lucide-react";
import { useAuthors } from "@/hooks/useAuthors";
import AuthorGridView from "@/components/admin/authors/AuthorGridView";
import AuthorListView from "@/components/admin/authors/AuthorListView";
import NewAuthorFormManager from "@/components/admin/authors/NewAuthorFormManager";
import EditAuthorForm from "@/components/admin/authors/EditAuthorForm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

const AdminAuthorsTab = () => {
  const {
    authors,
    filteredSortedAuthors,
    isAdding,
    isEditing,
    editingAuthorId,
    authorSearch,
    authorSort,
    setAuthorSearch,
    setAuthorSort,
    handleAddAuthor,
    handleUpdateAuthor,
    handleDeleteAuthor,
    getAuthorArticleCount,
    startEditingAuthor,
    cancelEditing
  } = useAuthors();

  const editingAuthor = authors.find(author => author.id === editingAuthorId);

  return (
    <TabContent
      title="Author Management"
      description="Manage author profiles and their RSS feeds for content aggregation."
      icon={<User className="h-5 w-5" />}
    >
      <div className="space-y-6">
        {editingAuthor ? (
          <Card className="overflow-hidden">
            <div className="p-6 bg-white">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Editing {editingAuthor.name}</h3>
                <Link to={`/author/${editingAuthor.id}`}>
                  <Button variant="outline" size="sm" className="flex items-center gap-1">
                    <ExternalLink className="h-4 w-4" />
                    View Profile
                  </Button>
                </Link>
              </div>
              <EditAuthorForm 
                author={editingAuthor}
                onUpdate={handleUpdateAuthor}
                onCancel={cancelEditing}
                isProcessing={isEditing}
              />
            </div>
          </Card>
        ) : (
          <NewAuthorFormManager onAddAuthor={handleAddAuthor} />
        )}
        
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Input
              type="text"
              placeholder="Search authors..."
              className="w-52 text-sm"
              value={authorSearch}
              onChange={(e) => setAuthorSearch(e.target.value)}
            />
            <select
              className="border rounded-md px-3 py-1.5 text-sm"
              value={authorSort}
              onChange={(e) => setAuthorSort(e.target.value as "default" | "az" | "za" | "articles")}
            >
              <option value="default">Sort by popularity</option>
              <option value="articles">Sort by article count</option>
              <option value="az">A-Z</option>
              <option value="za">Z-A</option>
            </select>
          </div>
          <div>
            <span className="text-sm text-muted-foreground">
              {filteredSortedAuthors.length} authors
            </span>
          </div>
        </div>
        
        <div className="hidden md:block">
          <AuthorListView 
            authors={filteredSortedAuthors}
            onDeleteAuthor={handleDeleteAuthor}
            onEditAuthor={startEditingAuthor}
            getAuthorArticleCount={getAuthorArticleCount}
          />
        </div>
        
        <div className="md:hidden">
          <AuthorGridView 
            authors={filteredSortedAuthors}
            onDeleteAuthor={handleDeleteAuthor}
            onEditAuthor={startEditingAuthor}
            getAuthorArticleCount={getAuthorArticleCount}
          />
        </div>
      </div>
    </TabContent>
  );
};

export default AdminAuthorsTab;
