import React, { useState, useMemo, useEffect } from "react";
import { toast } from "sonner";
import { Tag } from "@/types/admin";
import TabContent from "@/components/admin/TabContent";
import AddTagForm from "@/components/admin/tags/AddTagForm";
import ContentList from "@/components/admin/ContentList";
import TagGridView from "@/components/admin/tags/TagGridView";
import TagListView from "@/components/admin/tags/TagListView";
import EditTagDialog from "@/components/admin/tags/EditTagDialog";
import { Tag as TagIcon, Hash } from "lucide-react";
import { tagService } from "@/utils/tagService";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

const AdminTopicsTab = () => {
  // Tags state
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // UI state for views, search, and sort
  const [activeView, setActiveView] = useState<"grid" | "list">("grid");
  const [tagSearch, setTagSearch] = useState("");
  const [tagSort, setTagSort] = useState<"default" | "az" | "za">("default");
  
  // Edit dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [currentTag, setCurrentTag] = useState<Tag | null>(null);
  
  // Delete confirmation dialog state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [tagToDelete, setTagToDelete] = useState<string | null>(null);

  // Load tags from API
  const fetchTags = async () => {
    setLoading(true);
    setError(null);
    try {
      const fetchedTags = await tagService.getAllTags();
      setTags(fetchedTags);
    } catch (err) {
      console.error("Error fetching tags:", err);
      setError("Failed to load tags. Please check your connection and try again.");
      toast.error("Failed to load tags");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTags();
  }, []);

  // Handle tag actions
  const handleAddTag = async (tagName: string, aliases: string[]) => {
    try {
      const newTag = await tagService.addTag(tagName, aliases);
      setTags([...tags, newTag]);
      toast.success(`Added new tag: ${tagName}`);
    } catch (err) {
      console.error("Error adding tag:", err);
      toast.error("Failed to add tag");
    }
  };

  const handleEditTag = (tag: Tag) => {
    setCurrentTag(tag);
    setEditDialogOpen(true);
  };

  const handleSaveTag = async (tagId: string, tagName: string, aliases: string[]) => {
    try {
      const updatedTag = await tagService.updateTag(tagId, { tagName, aliases });
      setTags(tags.map(tag => tag._id === tagId ? updatedTag : tag));
      setEditDialogOpen(false);
      toast.success("Tag updated successfully");
    } catch (err) {
      console.error("Error updating tag:", err);
      toast.error("Failed to update tag");
    }
  };

  const confirmDeleteTag = (tagId: string) => {
    setTagToDelete(tagId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteTag = async () => {
    if (!tagToDelete) return;
    
    try {
      await tagService.deleteTag(tagToDelete);
      setTags(tags.filter(tag => tag._id !== tagToDelete));
      toast.success("Tag deleted successfully");
    } catch (err) {
      console.error("Error deleting tag:", err);
      toast.error("Failed to delete tag");
    } finally {
      setDeleteDialogOpen(false);
      setTagToDelete(null);
    }
  };

  // Filtered and sorted tags
  const filteredSortedTags = useMemo(() => {
    let result = [...tags];
    
    // Apply search filter
    if (tagSearch) {
      const searchLower = tagSearch.toLowerCase();
      result = result.filter(tag => 
        tag.tagName.toLowerCase().includes(searchLower) || 
        tag.aliases.some(alias => alias.toLowerCase().includes(searchLower))
      );
    }
    
    // Apply sort
    if (tagSort === "az") {
      result.sort((a, b) => a.tagName.localeCompare(b.tagName));
    } else if (tagSort === "za") {
      result.sort((a, b) => b.tagName.localeCompare(a.tagName));
    }
    
    return result;
  }, [tags, tagSearch, tagSort]);

  return (
    <TabContent 
      title="Manage Tags" 
      description="Add, edit or remove tags that appear on the home page and are used to categorize articles."
      icon={<TagIcon className="h-6 w-6 mb-1 text-green-600" />}
    >
      <AddTagForm
        onAddTag={handleAddTag}
        icon={<Hash className="h-4 w-4" />}
      />

      {error && (
        <div className="bg-red-50 text-red-800 p-4 rounded-md my-4">
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500"></div>
        </div>
      ) : (
        <ContentList
          title="Current Tags"
          searchValue={tagSearch}
          onSearchChange={setTagSearch}
          sortValue={tagSort}
          onSortChange={setTagSort}
          viewType={activeView}
          onViewChange={setActiveView}
          renderGridView={() => (
            <TagGridView 
              tags={filteredSortedTags} 
              onDelete={confirmDeleteTag} 
              onEdit={handleEditTag} 
            />
          )}
          renderListView={() => (
            <TagListView 
              tags={filteredSortedTags} 
              onDelete={confirmDeleteTag} 
              onEdit={handleEditTag} 
            />
          )}
          icon={<Hash className="h-4 w-4 mr-2 text-green-500" />}
        />
      )}

      <EditTagDialog 
        isOpen={editDialogOpen}
        onClose={() => setEditDialogOpen(false)}
        tag={currentTag}
        onSave={handleSaveTag}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the tag and remove it from all associated content.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteTag} className="bg-red-500 hover:bg-red-600">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </TabContent>
  );
};

export default AdminTopicsTab;
