
import React, { useState } from "react";
import { toast } from "sonner";
import TabContent from "@/components/admin/TabContent";
import ContentList from "@/components/admin/ContentList";
import FeedGridView from "@/components/admin/feeds/FeedGridView";
import FeedListView from "@/components/admin/feeds/FeedListView";
import { Newspaper, Rss } from "lucide-react";
import FeedRefreshBar from "@/components/admin/feeds/FeedRefreshBar";
import NewFeedFormManager from "@/components/admin/feeds/NewFeedFormManager";
import { useFeeds } from "@/hooks/useFeeds";

// Initialize with an empty array - we'll load from API
const initializeFeedSources = () => {
  // Add "All" feed as a default
  return [{
    id: "all",
    name: "All",
    logo: "",
    count: 0,
    selected: true,
    url: "",
    lastFetched: new Date().toISOString()
  }];
};

const AdminFeedsTab = () => {
  const [activeView, setActiveView] = useState<"grid" | "list">("grid");
  
  const {
    filteredSortedFeeds,
    feedSearch,
    feedSort,
    isFetching,
    lastAutoFetch,
    setFeedSearch,
    setFeedSort,
    refreshArticleCounts,
    handleAddFeed,
    handleDeleteFeed,
    handleAddLogo
  } = useFeeds(initializeFeedSources());

  return (
    <TabContent 
      title="Manage Feed Sources" 
      description="Add, edit or remove feed sources that appear on the home page."
      icon={<Newspaper className="h-6 w-6 mb-1 text-blue-600" />}
    >
      <NewFeedFormManager onAddFeed={handleAddFeed} />

      <FeedRefreshBar 
        lastAutoFetch={lastAutoFetch} 
        isFetching={isFetching} 
        onRefresh={() => refreshArticleCounts(false)} 
      />

      <ContentList
        title="Current Feed Sources"
        searchValue={feedSearch}
        onSearchChange={setFeedSearch}
        sortValue={feedSort}
        onSortChange={setFeedSort}
        viewType={activeView}
        onViewChange={setActiveView}
        renderGridView={() => <FeedGridView feeds={filteredSortedFeeds} onDelete={handleDeleteFeed} onAddLogo={handleAddLogo} />}
        renderListView={() => <FeedListView feeds={filteredSortedFeeds} onDelete={handleDeleteFeed} onAddLogo={handleAddLogo} />}
        icon={<Rss className="h-4 w-4 mr-2 text-blue-500" />}
      />
    </TabContent>
  );
};

export default AdminFeedsTab;
