
import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Newspaper, Briefcase, Tag, User, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import Header from "@/components/Header";
import TopicBar from "@/components/TopicBar";
import AdminFeedsTab from "@/pages/admin/AdminFeedsTab";
import AdminCompaniesTab from "@/pages/admin/AdminCompaniesTab";
import AdminTopicsTab from "@/pages/admin/AdminTopicsTab";
import AdminAuthorsTab from "@/pages/admin/AdminAuthorsTab";
import AdminBooksTab from "@/pages/admin/AdminBooksTab";

const AdminPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t border-gray-300">
        <TopicBar />
      </div>
      
      <div className="container mx-auto py-6">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/">
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft size={16} />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-serif font-bold">Content Management</h1>
        </div>

        <Tabs defaultValue="feeds" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="feeds" className="flex items-center gap-2">
              <Newspaper size={16} />
              Popular Feeds
            </TabsTrigger>
            <TabsTrigger value="companies" className="flex items-center gap-2">
              <Briefcase size={16} />
              Companies
            </TabsTrigger>
            <TabsTrigger value="topics" className="flex items-center gap-2">
              <Tag size={16} />
              Tags
            </TabsTrigger>
            <TabsTrigger value="authors" className="flex items-center gap-2">
              <User size={16} />
              Authors
            </TabsTrigger>
            <TabsTrigger value="books" className="flex items-center gap-2">
              <BookOpen size={16} />
              Books
            </TabsTrigger>
          </TabsList>
          
          {/* Feed Sources Tab */}
          <TabsContent value="feeds">
            <AdminFeedsTab />
          </TabsContent>
          
          {/* Companies Tab */}
          <TabsContent value="companies">
            <AdminCompaniesTab />
          </TabsContent>
          
          {/* Tags Tab (renamed from Topics) */}
          <TabsContent value="topics">
            <AdminTopicsTab />
          </TabsContent>
          
          {/* Authors Tab */}
          <TabsContent value="authors">
            <AdminAuthorsTab />
          </TabsContent>
          
          {/* Books Tab */}
          <TabsContent value="books">
            <AdminBooksTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminPage;
