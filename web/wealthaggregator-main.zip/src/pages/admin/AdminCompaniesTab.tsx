
import React, { useState, useMemo, useEffect } from "react";
import { toast } from "sonner";
import { CompanySource } from "@/types/admin";
import TabContent from "@/components/admin/TabContent";
import AddCompanyForm from "@/components/admin/companies/AddCompanyForm";
import ContentList from "@/components/admin/ContentList";
import CompanyGridView from "@/components/admin/companies/CompanyGridView";
import CompanyListView from "@/components/admin/companies/CompanyListView";
import { Briefcase, Building2 } from "lucide-react";
import { getBestFaviconUrl } from "@/utils/favicon";
import { companyService } from "@/utils/companyService";

// Initialize with empty array, we'll load from the API
const initialCompanySources: CompanySource[] = [
  { id: "all", name: "All", logo: "", count: 5, selected: true, url: "" },
  { id: "ge", name: "General Electric", logo: "", count: 5, selected: false, url: "" },
  { id: "x", name: "X (Twitter)", logo: "", count: 20, selected: true, url: "" },
  { id: "tsla", name: "Tesla", logo: "", count: 9, selected: true, url: "" },
  { id: "aapl", name: "Apple", logo: "", count: 7, selected: false, url: "" },
  { id: "intc", name: "Intel", logo: "", count: 6, selected: false, url: "" },
];

const AdminCompaniesTab = () => {
  // Company sources state
  const [companySources, setCompanySources] = useState<CompanySource[]>(initialCompanySources);
  const [newCompanyName, setNewCompanyName] = useState("");
  const [newCompanyLogo, setNewCompanyLogo] = useState("");
  const [newCompanyCount, setNewCompanyCount] = useState(0);
  
  // UI state for views, search, and sort
  const [activeView, setActiveView] = useState<"grid" | "list">("grid");
  const [companySearch, setCompanySearch] = useState("");
  const [companySort, setCompanySort] = useState<"default" | "az" | "za">("default");

  // Load companies from API
  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        const data = await companyService.getPlatformCompanies();
        if (data && data.length > 0) {
          const formattedCompanies: CompanySource[] = data.map(company => ({
            id: company._id,
            name: company.name,
            logo: company.favicon || "",
            count: 0, // Default value
            selected: false,
            url: company.domain || ""
          }));
          setCompanySources([
            { id: "all", name: "All", logo: "", count: formattedCompanies.length, selected: true, url: "" },
            ...formattedCompanies
          ]);
        }
      } catch (error) {
        console.error("Error fetching companies:", error);
      }
    };
    
    fetchCompanies();
  }, []);

  // Auto-generate logos on component mount for companies that don't have one
  useEffect(() => {
    const updatedCompanies = companySources.map(company => {
      if (!company.logo && company.id !== "all") {
        // For companies, attempt to use their domain name if possible
        let domain = "";
        if (company.name.toLowerCase().includes("apple")) domain = "apple.com";
        else if (company.name.toLowerCase().includes("tesla")) domain = "tesla.com";
        else if (company.name.toLowerCase().includes("general electric")) domain = "ge.com";
        else if (company.name.toLowerCase().includes("intel")) domain = "intel.com";
        else if (company.name.toLowerCase().includes("twitter") || company.name === "X") domain = "twitter.com";
        
        return {
          ...company,
          logo: getBestFaviconUrl(company.name, domain)
        };
      }
      return company;
    });
    
    setCompanySources(updatedCompanies);
  }, []);

  // Handle company source actions
  const handleAddCompany = () => {
    if (!newCompanyName) {
      toast.error("Company name is required");
      return;
    }

    const newCompany: CompanySource = {
      id: newCompanyName.toLowerCase().replace(/\s+/g, '-'),
      name: newCompanyName,
      logo: newCompanyLogo || "",
      count: newCompanyCount,
      selected: false,
      url: ""
    };

    setCompanySources([...companySources, newCompany]);
    setNewCompanyName("");
    setNewCompanyLogo("");
    setNewCompanyCount(0);
    toast.success(`Added new company: ${newCompanyName}`);
  };

  const handleDeleteCompany = (id: string) => {
    setCompanySources(companySources.filter(company => company.id !== id));
    toast.success("Company deleted successfully");
  };

  const handleAddLogo = (id: string) => {
    const company = companySources.find(c => c.id === id);
    if (!company) return;

    // For companies, attempt to use their domain name if possible
    let domain = "";
    if (company.name.toLowerCase().includes("apple")) domain = "apple.com";
    else if (company.name.toLowerCase().includes("tesla")) domain = "tesla.com";
    else if (company.name.toLowerCase().includes("general electric")) domain = "ge.com";
    else if (company.name.toLowerCase().includes("intel")) domain = "intel.com";
    else if (company.name.toLowerCase().includes("twitter") || company.name === "X") domain = "twitter.com";
    
    // Generate favicon URL based on name and domain
    const faviconUrl = getBestFaviconUrl(company.name, domain);

    // Update the company with the new logo
    setCompanySources(companySources.map(c => 
      c.id === id ? { ...c, logo: faviconUrl } : c
    ));

    toast.success(`Generated logo for ${company.name}`);
  };

  // Filtered and sorted companies
  const filteredSortedCompanies = useMemo(() => {
    let result = [...companySources];
    
    // Apply search filter
    if (companySearch) {
      result = result.filter(company => 
        company.name.toLowerCase().includes(companySearch.toLowerCase())
      );
    }
    
    // Apply sort
    if (companySort === "az") {
      result.sort((a, b) => a.name.localeCompare(b.name));
    } else if (companySort === "za") {
      result.sort((a, b) => b.name.localeCompare(a.name));
    }
    
    return result;
  }, [companySources, companySearch, companySort]);

  return (
    <TabContent 
      title="Manage Companies" 
      description="Add, edit or remove companies that appear on the home page."
      icon={<Briefcase className="h-6 w-6 mb-1 text-purple-600" />}
    >
      <AddCompanyForm
        newCompanyName={newCompanyName}
        setNewCompanyName={setNewCompanyName}
        newCompanyLogo={newCompanyLogo}
        setNewCompanyLogo={setNewCompanyLogo}
        newCompanyCount={newCompanyCount}
        setNewCompanyCount={setNewCompanyCount}
        handleAddCompany={handleAddCompany}
        icon={<Building2 className="h-4 w-4" />}
      />

      <ContentList
        title="Current Companies"
        searchValue={companySearch}
        onSearchChange={setCompanySearch}
        sortValue={companySort}
        onSortChange={setCompanySort}
        viewType={activeView}
        onViewChange={setActiveView}
        renderGridView={() => <CompanyGridView companies={filteredSortedCompanies} onDelete={handleDeleteCompany} onAddLogo={handleAddLogo} />}
        renderListView={() => <CompanyListView companies={filteredSortedCompanies} onDelete={handleDeleteCompany} onAddLogo={handleAddLogo} />}
        icon={<Building2 className="h-4 w-4 mr-2 text-purple-500" />}
      />
    </TabContent>
  );
};

export default AdminCompaniesTab;
