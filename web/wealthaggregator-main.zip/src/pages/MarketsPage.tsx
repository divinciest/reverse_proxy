
import React, { useState, useMemo } from "react";
import Header from "@/components/Header";
import StockTickerTape from "@/components/StockTickerTape";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import MarketCard from "@/components/markets/MarketCard";
import RegionSelector from "@/components/markets/RegionSelector";
import { getMarketIndices, marketRegions } from "@/utils/marketDataService";

const MarketsPage = () => {
  const [activeRegion, setActiveRegion] = useState("Americas");
  const allMarkets = useMemo(() => getMarketIndices(), []);
  
  // Filter markets by region
  const filteredMarkets = useMemo(() => {
    return allMarkets.filter(market => market.region === activeRegion);
  }, [allMarkets, activeRegion]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      
      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[{ label: "Markets" }]} />
        
        <div className="my-6">
          <h1 className="text-4xl font-bold mb-2">Markets</h1>
          <p className="text-gray-600">
            Track major global indices and their daily performance
          </p>
        </div>
        
        {/* Region selector */}
        <RegionSelector 
          regions={marketRegions}
          activeRegion={activeRegion}
          onRegionChange={setActiveRegion}
        />
        
        {/* Market cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filteredMarkets.map((market) => (
            <MarketCard key={market.symbol} market={market} />
          ))}
        </div>
        
        <div className="mt-12 mb-4">
          <div className="text-xs text-gray-500 text-center">
            Market data from financial exchanges around the world
          </div>
          <div className="text-xs text-gray-500 text-center">
            All times are in local time zone • Last updated: {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketsPage;
