
import React from "react";
import Header from "@/components/Header";
import TopicBar from "@/components/TopicBar";
import StockTickerTape from "@/components/StockTickerTape";
import StockDataProvider from "@/components/sp500/StockDataProvider";
import StocksDisplaySection from "@/components/sp500/StocksDisplaySection";
import IndexCardSection from "@/components/sp500/IndexCardSection";
import BreadcrumbNav from "@/components/BreadcrumbNav";

const SP500Page = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <TopicBar />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      
      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[{ label: "Markets", href: "/markets" }, { label: "S&P 500" }]} />
        
        <StockDataProvider>
          {({ 
            spxIndex, 
            indexLoading, 
            indexError, 
            stocksData, 
            stocksError, 
            loading,
            handleRefresh,
            fetchIndexData,
            fetchStocksData
          }) => (
            <>
              {/* S&P 500 Index Card */}
              <IndexCardSection 
                spxIndex={spxIndex}
                indexLoading={indexLoading}
                indexError={indexError}
                fetchIndexData={fetchIndexData}
              />
              
              {/* Stocks Display Section */}
              <StocksDisplaySection 
                stocksData={stocksData}
                loading={loading}
                stocksError={stocksError}
                onRefresh={handleRefresh}
                fetchStocksData={fetchStocksData}
              />

              {/* Citation */}
              <div className="text-xs text-gray-500 text-center mt-8 pb-4">
                Index data courtesy of Standard & Poor's
              </div>
            </>
          )}
        </StockDataProvider>
      </div>
    </div>
  );
};

export default SP500Page;
