
import React from "react";
import { useParams, Link } from "react-router-dom";
import { getBookById, getBookDescription } from "@/utils/books";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import BookPageLayout from "@/components/layouts/BookPageLayout";
import BookCover from "@/components/books/BookCover";
import BookDetails from "@/components/books/BookDetails";
import BookNotFound from "@/components/books/BookNotFound";

const BookDetailPage = () => {
  const { bookId } = useParams<{ bookId: string }>();
  
  // Get book details
  const book = bookId ? getBookById(bookId) : null;
  
  // If book not found, show error message
  if (!book) {
    return (
      <BookPageLayout>
        <BreadcrumbNav items={[{ label: "Books", href: "/books" }, { label: "Not Found" }]} />
        <BookNotFound />
      </BookPageLayout>
    );
  }

  // Get book description from our utility
  const bookDescription = getBookDescription(book.id);

  return (
    <BookPageLayout>
      {/* Breadcrumb Navigation */}
      <BreadcrumbNav items={[{ label: "Books", href: "/books" }, { label: book.title }]} />
      
      <div className="mt-8">
        <Button variant="outline" size="sm" asChild className="mb-6">
          <Link to="/books" className="flex items-center">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Books
          </Link>
        </Button>
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column - Book Cover */}
          <div className="lg:col-span-4">
            <BookCover book={book} />
          </div>
          
          {/* Right Column - Book Details */}
          <div className="lg:col-span-8">
            <BookDetails book={book} description={bookDescription} />
          </div>
        </div>
      </div>
    </BookPageLayout>
  );
};

export default BookDetailPage;
