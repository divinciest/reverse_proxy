
import React from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import StockTickerTape from "@/components/StockTickerTape";
import DateHeader from "@/components/DateHeader";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import WidgetGrid from "@/components/widgets/WidgetGrid";

const WidgetsPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="container mx-auto py-8 flex-1">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[{ label: "Widgets" }]} />
        
        <div className="mt-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold font-serif">Widgets Gallery</h1>
              <p className="text-muted-foreground mt-1">
                Customize your financial dashboard with these powerful widgets
              </p>
            </div>
            
            <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search widgets..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
          </div>
          
          <Card className="mb-8">
            <CardHeader className="pb-3">
              <CardTitle className="text-2xl font-serif">
                Featured Widgets
              </CardTitle>
              <CardDescription>
                Most popular financial widgets to enhance your dashboard
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WidgetGrid filter="featured" />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-2xl font-serif">
                All Widgets
              </CardTitle>
              <CardDescription>
                Browse our complete collection of financial widgets
              </CardDescription>
            </CardHeader>
            <CardContent>
              <WidgetGrid filter="all" />
            </CardContent>
            <CardFooter className="flex justify-center pt-2 pb-6">
              <p className="text-sm text-muted-foreground">
                Looking for something specific? Try searching above or{" "}
                <Link to="/contact" className="text-primary hover:underline">
                  contact us
                </Link>
                {" "}for custom widgets.
              </p>
            </CardFooter>
          </Card>
        </div>
      </main>

      <footer className="bg-gray-800 text-white py-6 border-t-4 border-gray-900">
        <div className="container mx-auto">
          <div className="text-center">
            <p className="font-serif text-lg">&copy; 2023 WealthManager.com - Financial News Aggregator</p>
            <p className="mt-1 text-gray-300">
              Providing aggregated financial content with AI-powered sentiment analysis
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default WidgetsPage;
