import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import TopicBar from "@/components/TopicBar";
import { Button } from "@/components/ui/button";
import { ArrowLeft, AlertCircle } from "lucide-react";
import { fetchStockData } from "@/utils/stockDataService";
import { getCompanyData, getCompanyInfo, getRelatedCompanies } from "@/utils/companyDataService";
import CompanyHeader from "@/components/company/CompanyHeader";
import StockChartCard from "@/components/company/StockChartCard";
import KeyFactsCard from "@/components/company/KeyFactsCard";
import RelatedCompanies from "@/components/company/RelatedCompanies";
import CompanyArticles from "@/components/company/CompanyArticles";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import { useArticles } from "@/hooks/useArticles";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from "lucide-react";
import { convertApiArticleToUiArticle } from "@/utils/articleUtils";

const CompanyProfile = () => {
  const { companyId } = useParams();
  const [stockData, setStockData] = useState<Array<{time: string; price: number}>>([]);
  const [loading, setLoading] = useState(true);
  const { articles: apiArticles, isLoading: articlesLoading, isApiAvailable } = useArticles();
  
  // Convert API articles to our data format
  const articles = apiArticles.map(convertApiArticleToUiArticle);

  // Get company data
  const companyData = getCompanyData(companyId);

  // Get related companies
  const relatedCompanies = getRelatedCompanies();

  // Filter related companies to only include those in the same industry
  // Only attempt filtering if companies and industry data are available
  const industryRelatedCompanies = relatedCompanies.filter(
    company => company.industry === companyData.industry
  );

  // Filter articles related to this company
  const companyArticles = companyId && companyData.name !== 'API Not Available'
    ? articles.filter(article => 
        article.title.toLowerCase().includes(companyData.ticker.toLowerCase()) || 
        article.summary.toLowerCase().includes(companyData.name.toLowerCase()) ||
        article.summary.toLowerCase().includes(companyData.ticker.toLowerCase()) ||
        (article.topics?.some(topic => topic.toLowerCase().includes(companyData.name.toLowerCase()))) ||
        (article.tags?.some(tag => tag.toLowerCase().includes(companyData.name.toLowerCase()))) ||
        (companyId === "intc" && article.id === "intel-article") ||
        (companyId === "aapl" && article.id === "apple-article") ||
        (companyId === "msft" && article.id === "msft-article") ||
        (companyId === "tsla" && article.id.includes("tsla"))
      )
    : [];
  
  // If no company-specific articles are found, use the first 5 general articles
  const displayArticles = companyArticles.length > 0 ? companyArticles : articles.slice(0, 5);

  useEffect(() => {
    const getStockData = async () => {
      if (companyId) {
        setLoading(true);
        try {
          const data = await fetchStockData(companyData.ticker, companyData.exchange);
          setStockData(data);
        } catch (error) {
          console.error("Failed to fetch stock data:", error);
          // Keep stockData as empty array
        } finally {
          setLoading(false);
        }
      }
    };

    getStockData();
  }, [companyId, companyData.exchange, companyData.ticker]);

  const isApiNotAvailable = companyData.name === 'API Not Available';

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <TopicBar />
      
      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[
          { label: "Stocks", href: "/stocks" },
          { label: companyData.name }
        ]} />
        
        <div className="mb-6">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/stocks" className="flex items-center text-muted-foreground">
              <ArrowLeft size={16} className="mr-1" /> Back to Stocks
            </Link>
          </Button>
        </div>

        {isApiNotAvailable && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>API Not Available</AlertTitle>
            <AlertDescription>
              Company data API is not implemented or unavailable. This system requires a real API connection.
            </AlertDescription>
          </Alert>
        )}

        {!isApiAvailable && (
          <Alert className="mb-6 bg-amber-50 border-amber-200">
            <Info className="h-4 w-4" />
            <AlertTitle>Using Demo Data</AlertTitle>
            <AlertDescription>
              API connection is unavailable. Showing demo articles instead of live data.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <CompanyHeader 
            name={companyData.name}
            ticker={companyData.ticker}
            exchange={companyData.exchange}
            price={companyData.price}
            change={companyData.change}
            changePercent={companyData.changePercent}
            description={companyData.description}
            companyInfo={companyId ? getCompanyInfo(companyId) : undefined}
          />
          
          <div className="md:col-span-1">
            <StockChartCard data={stockData} loading={loading} />
          </div>
        </div>

        <KeyFactsCard companyData={companyData} />

        <CompanyArticles 
          companyId={companyId} 
          articles={displayArticles} 
          isLoading={articlesLoading}
        />

        <RelatedCompanies 
          companies={industryRelatedCompanies}
          currentCompanyId={companyId || ""}
        />
      </main>
    </div>
  );
};

export default CompanyProfile;
