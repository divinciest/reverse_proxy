
import React from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import StockTickerTape from "@/components/StockTickerTape";
import DateHeader from "@/components/DateHeader";
import { topicsStrings } from "@/data/topics";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import TopicBadge from "@/components/TopicBadge";

const TopicsPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="container mx-auto py-8 flex-1">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[{ label: "Topics" }]} />
        
        <Card className="mb-6 mt-4">
          <CardHeader className="pb-3">
            <CardTitle className="text-2xl font-serif">
              All Topics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">
              Browse all {topicsStrings.length} available topics on WealthManager.com
            </p>
            
            <div className="flex flex-wrap gap-3">
              {topicsStrings.map((topic, index) => (
                <Link 
                  key={index} 
                  to={`/topic/${encodeURIComponent(topic.replace(/ /g, '-'))}`}
                >
                  <TopicBadge 
                    topic={topic} 
                    variant="topic" 
                    className="text-sm px-4 py-2"
                  />
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>

      <footer className="bg-gray-800 text-white py-6 border-t-4 border-gray-900">
        <div className="container mx-auto">
          <div className="text-center">
            <p className="font-serif text-lg">&copy; 2023 WealthManager.com - Financial News Aggregator</p>
            <p className="mt-1 text-gray-300">
              Providing aggregated financial content with AI-powered sentiment analysis
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default TopicsPage;
