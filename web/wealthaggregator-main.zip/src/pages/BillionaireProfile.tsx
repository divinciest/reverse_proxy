
import React from "react";
import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import DateHeader from "@/components/DateHeader";
import TopicBar from "@/components/TopicBar";
import StockTickerTape from "@/components/StockTickerTape";
import { Card } from "@/components/ui/card";
import { getBillionaireById, getBillionaireCompanyLogos, getBillionaireNews } from "@/data/billionaire";
import BillionaireBiography from "@/components/billionaire/BillionaireBiography";
import BillionaireCompanies from "@/components/billionaire/BillionaireCompanies";
import BillionaireSidebar from "@/components/billionaire/BillionaireSidebar";
import BillionaireQuickNav from "@/components/billionaire/BillionaireQuickNav";
import { 
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator
} from "@/components/ui/breadcrumb";
import { Home, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const BillionaireProfile = () => {
  const { billionaireId } = useParams<{ billionaireId: string }>();
  const billionaireData = billionaireId ? getBillionaireById(billionaireId) : undefined;
  const companyLogos = billionaireData ? getBillionaireCompanyLogos(billionaireData) : {};
  const newsItems = billionaireId ? getBillionaireNews(billionaireId) : [];
  
  if (!billionaireData) {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50">
        <Header />
        <div className="container mx-auto py-12">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Not Found</AlertTitle>
            <AlertDescription>
              The billionaire profile you're looking for was not found.
            </AlertDescription>
          </Alert>
          <div className="mt-6">
            <Link to="/billionaires" className="text-primary hover:underline">
              Return to Billionaires List
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t border-gray-300">
        <TopicBar />
      </div>
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="flex-1">
        <div className="container mx-auto py-6">
          {/* Breadcrumb navigation */}
          <Breadcrumb className="mb-4">
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/" className="flex items-center">
                    <Home className="h-4 w-4 mr-1" />
                    Home
                  </Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/billionaires">Billionaires</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>{billionaireData.name}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>

          {/* Billionaire Quick Navigation */}
          <BillionaireQuickNav currentBillionaireId={billionaireId || ''} />

          <div className="flex flex-col lg:flex-row gap-6">
            <div className="w-full lg:w-2/3">
              {/* Billionaire Biography and Companies */}
              <Card className="mb-6">
                <BillionaireBiography 
                  name={billionaireData.name}
                  rank={billionaireData.rank}
                  netWorth={billionaireData.netWorth}
                  change={billionaireData.change}
                  changePercent={billionaireData.changePercent}
                  source={billionaireData.source}
                  country={billionaireData.country}
                  age={billionaireData.age}
                  bio={billionaireData.bio}
                  imageUrl={billionaireData.imageUrl}
                />
                <BillionaireCompanies 
                  billionaire={billionaireData}
                  companyLogos={companyLogos}
                />
              </Card>
            </div>
            
            <div className="w-full lg:w-1/3">
              <BillionaireSidebar 
                billionaire={billionaireData} 
                newsItems={newsItems}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default BillionaireProfile;
