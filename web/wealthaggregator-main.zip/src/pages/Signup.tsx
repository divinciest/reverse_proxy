
import React from "react";
import { useAuth } from "@/hooks/useAuth";
import SignupForm from "@/components/auth/SignupForm";
import { Navigate } from "react-router-dom";

const Signup = () => {
  const { isAuthenticated } = useAuth();
  
  // Redirect if already authenticated
  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          Create a New Account
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600 max-w">
          Join us to get the latest financial news and analysis
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <SignupForm />
      </div>
    </div>
  );
};

export default Signup;
