
import React, { useState, useEffect } from "react";
import Header from "@/components/Header";
import StockTickerTape from "@/components/StockTickerTape";
import DateHeader from "@/components/DateHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import FilterToolbar from "@/components/FilterToolbar";
import { getFinanceBooks } from "@/utils/books";
import { useToast } from "@/hooks/use-toast";
import { useSortedBooks } from "@/hooks/useSortedBooks";
import BookGrid from "@/components/books/BookGrid";

const BooksPage = () => {
  // Get all books
  const books = getFinanceBooks();
  const { toast } = useToast();
  
  // UI state
  const [view, setView] = useState<"grid" | "list">("grid");
  const [dateFilter, setDateFilter] = useState<string>("all");
  const [imagesLoaded, setImagesLoaded] = useState<boolean>(false);
  
  // Use our custom hook for sorting
  const { currentSort, setCurrentSort, sortedBooks } = useSortedBooks(books);

  // Effects
  useEffect(() => {
    // Notify when images are loaded
    setImagesLoaded(true);
    toast({
      title: "Books loaded",
      description: `Loaded ${books.length} finance books with high-quality cover images`,
    });
  }, [books.length, toast]);

  // Handle refresh
  const handleRefresh = () => {
    console.log("Refreshing book data...");
    toast({
      title: "Refreshed book data",
      description: "Latest book data has been loaded"
    });
  };

  // Handle sort change
  const handleSort = (sortType: string) => {
    setCurrentSort(sortType);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="container mx-auto py-8 flex-1">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[{ label: "Books" }]} />
        
        <Card className="mb-6 mt-4">
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <CardTitle className="text-2xl font-serif">
                Books / Finance
              </CardTitle>
              
              {/* Add filter toolbar */}
              <FilterToolbar
                dateFilter={dateFilter}
                onDateFilterChange={setDateFilter}
                view={view}
                onViewChange={setView}
                onRefresh={handleRefresh}
                sortProps={{
                  onSort: handleSort,
                  currentSort: currentSort
                }}
              />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">
              Essential finance books from top authors across the industry with high-quality cover images
            </p>
            
            {/* Books grid using the new component */}
            <BookGrid books={sortedBooks} view={view} />
          </CardContent>
        </Card>
      </main>

      <footer className="bg-gray-800 text-white py-6 border-t-4 border-gray-900">
        <div className="container mx-auto">
          <div className="text-center">
            <p className="font-serif text-lg">&copy; 2023 WealthManager.com - Financial News Aggregator</p>
            <p className="mt-1 text-gray-300">
              Providing aggregated financial content with AI-powered sentiment analysis
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default BooksPage;
