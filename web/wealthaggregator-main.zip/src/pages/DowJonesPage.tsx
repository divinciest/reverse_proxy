
import React from "react";
import DowJonesLayout from "@/components/dowjones/DowJonesLayout";
import DowJonesStockDataProvider from "@/components/dowjones/DowJonesStockDataProvider";
import DowJonesPageContent from "@/components/dowjones/DowJonesPageContent";

const DowJonesPage = () => {
  return (
    <DowJonesLayout>
      <DowJonesStockDataProvider>
        {({ 
          djiaIndex, 
          indexLoading, 
          indexError, 
          stocksData, 
          stocksError, 
          loading,
          handleRefresh,
          fetchIndexData,
          fetchStocksData
        }) => (
          <DowJonesPageContent 
            djiaIndex={djiaIndex}
            indexLoading={indexLoading}
            indexError={indexError}
            stocksData={stocksData}
            stocksError={stocksError}
            loading={loading}
            handleRefresh={handleRefresh}
            fetchIndexData={fetchIndexData}
            fetchStocksData={fetchStocksData}
          />
        )}
      </DowJonesStockDataProvider>
    </DowJonesLayout>
  );
};

export default DowJonesPage;
