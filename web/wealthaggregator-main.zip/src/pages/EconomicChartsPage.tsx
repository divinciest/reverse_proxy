
import React, { useState, useMemo } from "react";
import Header from "@/components/Header";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import { getEconomicCharts, chartCategories } from "@/utils/economicChartsService";
import ChartCard from "@/components/economic/ChartCard";
import CategoryFilter from "@/components/economic/CategoryFilter";
import StockTickerTape from "@/components/StockTickerTape";
import { ChartLine, TrendingUp, DollarSign } from "lucide-react";

const EconomicChartsPage = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const allCharts = useMemo(() => getEconomicCharts(), []);
  
  // Filter charts by category
  const filteredCharts = useMemo(() => {
    if (activeCategory === "All") {
      return allCharts;
    }
    return allCharts.filter(chart => chart.category === activeCategory);
  }, [allCharts, activeCategory]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      
      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[{ label: "Economic Charts" }]} />
        
        <div className="my-6">
          <div className="flex items-center">
            <ChartLine size={28} className="mr-2 text-blue-500" />
            <h1 className="text-4xl font-bold">Economic Charts</h1>
          </div>
          <p className="text-gray-600 mt-2">
            Track major economic indicators and their historical performance
          </p>
        </div>
        
        {/* Category filter */}
        <CategoryFilter 
          categories={chartCategories}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
        />
        
        {/* Featured indicators section */}
        {activeCategory === "All" && (
          <div className="mb-10 bg-blue-50 p-6 rounded-lg border border-blue-100">
            <div className="flex items-center mb-4">
              <TrendingUp size={24} className="mr-2 text-blue-600" />
              <h2 className="text-2xl font-bold text-blue-800">Featured Economic Indicators</h2>
            </div>
            <p className="text-gray-700 mb-6">
              These key indicators provide a snapshot of economic health, monetary policy, and financial market conditions.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {allCharts
                .filter(chart => ['federal-funds-rate', 'inflation-rate', 'gdp-growth'].includes(chart.id))
                .map(chart => (
                  <ChartCard key={chart.id} chart={chart} />
                ))}
            </div>
          </div>
        )}
        
        {/* Main charts grid */}
        <div>
          <h2 className="text-2xl font-bold mb-4 flex items-center">
            <DollarSign size={24} className="mr-2 text-green-600" />
            {activeCategory === "All" ? "All Economic Charts" : activeCategory + " Charts"}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCharts.map((chart) => (
              <ChartCard key={chart.id} chart={chart} />
            ))}
          </div>
        </div>
        
        <div className="mt-12 mb-4">
          <div className="text-xs text-gray-500 text-center">
            Data sourced from various financial and government databases
          </div>
          <div className="text-xs text-gray-500 text-center">
            Last updated: {new Date().toLocaleDateString()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EconomicChartsPage;
