
import React from "react";
import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import StockTickerTape from "@/components/StockTickerTape";
import DateHeader from "@/components/DateHeader";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import { getWidgetById } from "@/data/widgets/widgetData";
import { ArrowLeft, Plus, Star, Download, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import WidgetGrid from "@/components/widgets/WidgetGrid";

const WidgetDetailPage = () => {
  const { widgetId } = useParams<{ widgetId: string }>();
  const widget = widgetId ? getWidgetById(widgetId) : null;
  
  if (!widget) {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50">
        <Header />
        <div className="border-t-2 border-b-2 border-gray-800">
          <StockTickerTape />
        </div>
        <DateHeader />
        
        <main className="container mx-auto py-8 flex-1">
          <BreadcrumbNav items={[
            { label: "Widgets", href: "/widgets" },
            { label: "Not Found" }
          ]} />
          
          <div className="text-center py-20">
            <h1 className="text-3xl font-bold mb-4">Widget Not Found</h1>
            <p className="text-muted-foreground mb-8">Sorry, the widget you're looking for doesn't exist.</p>
            <Button asChild>
              <Link to="/widgets">Back to Widgets</Link>
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="container mx-auto py-8 flex-1">
        <BreadcrumbNav items={[
          { label: "Widgets", href: "/widgets" },
          { label: widget.name }
        ]} />
        
        <Button variant="outline" size="sm" asChild className="mb-6">
          <Link to="/widgets" className="flex items-center">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Widgets
          </Link>
        </Button>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Widget Image */}
          <div className="lg:col-span-1">
            <img 
              src={widget.imageUrl} 
              alt={widget.name} 
              className="w-full h-auto rounded-lg border shadow-sm"
            />
            
            <div className="mt-4 flex flex-col gap-3">
              <Button className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Add to My Dashboard
              </Button>
              
              <div className="grid grid-cols-3 gap-3">
                <Button variant="outline" size="sm" className="w-full">
                  <Star className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  <Download className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="mt-6 bg-white rounded-lg border p-4">
              <h3 className="font-medium mb-2">Widget Information</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Category:</span>
                  <span className="font-medium">{widget.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Version:</span>
                  <span>{widget.version}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Last Updated:</span>
                  <span>{widget.updatedAt}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Users:</span>
                  <span>{widget.users.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rating:</span>
                  <span>★★★★☆ ({widget.rating})</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right Column - Widget Details */}
          <div className="lg:col-span-2">
            <h1 className="text-3xl font-bold mb-2">{widget.name}</h1>
            <p className="text-muted-foreground mb-6">{widget.description}</p>
            
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="features">Features</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
                <TabsTrigger value="support">Support</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="mt-6">
                <Card>
                  <CardContent className="pt-6">
                    <div className="prose max-w-none">
                      <h3>About {widget.name}</h3>
                      <p>{widget.longDescription}</p>
                      
                      <h3 className="mt-6">How to use</h3>
                      <p>Simply click the "Add to My Dashboard" button to add this widget to your personalized dashboard. Once added, you can arrange and resize it to your preference.</p>
                      
                      <h3 className="mt-6">Customization options</h3>
                      <ul>
                        <li>Resize widget to small, medium, or large</li>
                        <li>Change refresh frequency</li>
                        <li>Customize display settings</li>
                        <li>Set alerts for specific conditions</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="features">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <h3 className="text-xl font-medium">Key Features</h3>
                      <ul className="space-y-2">
                        {widget.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <div className="bg-primary/10 text-primary rounded-full p-1 mr-3 mt-0.5">
                              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                              </svg>
                            </div>
                            <div>
                              <p className="font-medium">{feature.title}</p>
                              <p className="text-sm text-muted-foreground">{feature.description}</p>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="reviews">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <h3 className="text-xl font-medium">User Reviews</h3>
                      <p className="text-muted-foreground">
                        This widget has been rated {widget.rating} out of 5 stars by our users.
                      </p>
                      
                      <div className="space-y-4 mt-6">
                        {widget.reviews.map((review, index) => (
                          <div key={index} className="border-b pb-4 last:border-0">
                            <div className="flex justify-between items-center mb-2">
                              <div className="font-medium">{review.user}</div>
                              <div className="text-sm text-muted-foreground">{review.date}</div>
                            </div>
                            <div className="flex items-center mb-2">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                                />
                              ))}
                            </div>
                            <p className="text-sm">{review.comment}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="support">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <h3 className="text-xl font-medium">Support</h3>
                      <p>If you have any questions or need help with this widget, our support team is here to help:</p>
                      
                      <div className="space-y-4 mt-4">
                        <div className="bg-blue-50 p-4 rounded-lg">
                          <h4 className="font-medium mb-2">Documentation</h4>
                          <p className="text-sm">
                            Read our comprehensive documentation to learn more about how to use and customize this widget.
                          </p>
                          <Button variant="link" className="px-0 py-1">View Documentation</Button>
                        </div>
                        
                        <div className="bg-green-50 p-4 rounded-lg">
                          <h4 className="font-medium mb-2">Email Support</h4>
                          <p className="text-sm">
                            Contact our support team for personalized assistance with any issues.
                          </p>
                          <Button variant="link" className="px-0 py-1">Contact Support</Button>
                        </div>
                        
                        <div className="bg-purple-50 p-4 rounded-lg">
                          <h4 className="font-medium mb-2">Video Tutorials</h4>
                          <p className="text-sm">
                            Watch step-by-step video guides on how to get the most from this widget.
                          </p>
                          <Button variant="link" className="px-0 py-1">Watch Tutorials</Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
            
            <div className="mt-8">
              <h3 className="text-xl font-medium mb-4">Similar Widgets</h3>
              <WidgetGrid filter={widget.category} />
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-gray-800 text-white py-6 border-t-4 border-gray-900 mt-12">
        <div className="container mx-auto">
          <div className="text-center">
            <p className="font-serif text-lg">&copy; 2023 WealthManager.com - Financial News Aggregator</p>
            <p className="mt-1 text-gray-300">
              Providing aggregated financial content with AI-powered sentiment analysis
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default WidgetDetailPage;
