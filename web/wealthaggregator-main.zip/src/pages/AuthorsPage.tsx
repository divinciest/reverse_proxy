
import React from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import StockTickerTape from "@/components/StockTickerTape";
import DateHeader from "@/components/DateHeader";
import { authors } from "@/data/authors";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import BreadcrumbNav from "@/components/BreadcrumbNav";
import { Avatar } from "@/components/ui/avatar";
import { ExternalLink } from "lucide-react";

const AuthorsPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="container mx-auto py-8 flex-1">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[{ label: "Authors" }]} />
        
        <Card className="mb-6 mt-4">
          <CardHeader className="pb-3">
            <CardTitle className="text-2xl font-serif">
              All Authors
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">
              Browse all {authors.length} authors on WealthManager.com
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {authors.map((author) => (
                <Link key={author.id} to={`/author/${author.id}`} 
                  className="group block p-4 bg-white rounded-lg border border-gray-200 hover:border-primary hover:shadow-md transition-all">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      {author.imageUrl ? (
                        <img
                          src={author.imageUrl}
                          alt={author.name}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center bg-primary/10 text-primary font-medium">
                          {author.name.charAt(0)}
                        </div>
                      )}
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium group-hover:text-primary flex items-center gap-1">
                        {author.name}
                        <ExternalLink className="h-3.5 w-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <div className="text-sm text-muted-foreground">{author.title}, {author.publication}</div>
                    </div>
                  </div>
                  <p className="mt-2 text-sm text-gray-600 line-clamp-2">{author.bio}</p>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>

      <footer className="bg-gray-800 text-white py-6 border-t-4 border-gray-900">
        <div className="container mx-auto">
          <div className="text-center">
            <p className="font-serif text-lg">&copy; 2023 WealthManager.com - Financial News Aggregator</p>
            <p className="mt-1 text-gray-300">
              Providing aggregated financial content with AI-powered sentiment analysis
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default AuthorsPage;
