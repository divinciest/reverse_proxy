
import React, { useEffect, useState, useMemo } from "react";
import { useParams, Link } from "react-router-dom";
import { getAuthorArticles, authors } from "@/data/authors";
import Header from "@/components/Header";
import TopicBar from "@/components/TopicBar";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import ArticleHeader from "@/components/article/ArticleHeader";
import ArticleImage from "@/components/article/ArticleImage";
import ArticleContent from "@/components/article/ArticleContent";
import SentimentCoverage from "@/components/article/SentimentCoverage";
import RelatedArticles from "@/components/article/RelatedArticles";
import ExpertsCard from "@/components/ExpertsCard";
import SourcesSection from "@/components/SourcesSection";
import SuggestionBanner from "@/components/SuggestionBanner";
import { sources } from "@/data/sources";
import { useArticles } from "@/hooks/useArticles";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from "lucide-react";
import { convertApiArticleToUiArticle } from "@/utils/articleUtils";

const ArticleDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { articles: apiArticles, isLoading, error, isApiAvailable } = useArticles();
  
  // Convert API articles to our consistent format
  const articles = apiArticles.map(convertApiArticleToUiArticle);
  const article = articles.find(a => a.id === id);

  const authorName = article?.source === "Bloomberg" ? "Matt Levine" : null;
  const authorId = authorName ? "matt-levine" : null;
  
  const relatedArticles = useMemo(() => {
    if (!article) return [];
    
    if (authorId) {
      const authorArticles = getAuthorArticles(authorId);
      return authorArticles.filter(a => a.id !== article.id).slice(0, 5);
    }
    
    return articles
      .filter(a => a.source === article.source && a.id !== article.id)
      .slice(0, 5);
  }, [article, authorId, articles]);

  const featuredSources = useMemo(() => {
    return sources.slice(0, 3);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="container mx-auto py-8 flex-1 flex flex-col items-center justify-center">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
            <p className="mt-2 text-muted-foreground">Loading article...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="container mx-auto py-8 flex-1 flex flex-col items-center justify-center">
          <h1 className="text-2xl font-bold mb-4">Article not found</h1>
          <Link to="/">
            <Button>
              <ArrowLeft size={16} className="mr-2" /> Back to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const formattedDate = new Date(article.date || article.publishDate || "").toLocaleDateString(
    "en-US",
    {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
    }
  );

  const sentimentCoverage = {
    bullish: 40,
    bearish: 10,
    neutral: 13
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t border-gray-300">
        <TopicBar />
      </div>
      
      <div className="container mx-auto py-8">
        {!isApiAvailable && (
          <Alert className="mb-6 bg-amber-50 border-amber-200">
            <Info className="h-4 w-4" />
            <AlertTitle>Using Demo Data</AlertTitle>
            <AlertDescription>
              API connection is unavailable. Showing demo articles instead of live data.
            </AlertDescription>
          </Alert>
        )}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-sm">
            <ArticleHeader 
              formattedDate={formattedDate}
              title={article.title}
              source={article.source}
              sourceUrl={article.sourceUrl}
              category={article.category || article.source}
              sentiment={article.sentiment || "neutral"}
            />
            
            {authorName && authorId && (
              <div className="mb-6">
                <Link to={`/author/${authorId}`} className="text-primary hover:underline font-medium">
                  By {authorName}
                </Link>
              </div>
            )}
            
            <ArticleImage 
              imageUrl={article.imageUrl} 
              title={article.title}
              source={article.source} 
            />
            
            <ArticleContent 
              summary={article.summary}
              topics={article.topics || article.tags || []}
              url={article.url || article.sourceUrl || "#"}
              source={article.source}
            />
            
            <SentimentCoverage 
              sourceCount={63}
              sentimentCoverage={sentimentCoverage}
            />
          </div>

          <div className="lg:col-span-1 space-y-6">
            <RelatedArticles 
              source={authorName || article.source}
              relatedArticles={relatedArticles}
            />
            
            <ExpertsCard />

            <div className="bg-white p-4 rounded-lg shadow-sm">
              <h2 className="text-xl font-serif font-bold mb-4 pb-2 border-b">Featured Sources</h2>
              <div className="space-y-4">
                {featuredSources.map((source) => (
                  <Link key={source.id} to={`/source/${source.id}`} className="block hover:bg-gray-50 p-2 rounded-md">
                    <div className="flex items-center">
                      {source.logoUrl && (
                        <img 
                          src={source.logoUrl} 
                          alt={source.name} 
                          className="h-10 w-10 object-contain mr-3"
                        />
                      )}
                      <div>
                        <h3 className="font-medium">{source.name}</h3>
                        <p className="text-sm text-muted-foreground">{source.category}</p>
                      </div>
                    </div>
                  </Link>
                ))}
                <Link to="/sources" className="block text-center text-primary hover:underline text-sm pt-2">
                  View all sources
                </Link>
              </div>
            </div>
            
            <div className="bg-[#e9dbbd] p-4 rounded-lg">
              <h2 className="text-lg font-semibold mb-2">Suggest a source</h2>
              <p className="text-sm text-muted-foreground mb-2">
                Looking for a source we don't already have? Suggest one <a href="#" className="underline font-medium">here</a>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticleDetail;
