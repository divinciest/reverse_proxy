
import React from "react";
import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import DateHeader from "@/components/DateHeader";
import TopicBar from "@/components/TopicBar";
import StockTickerTape from "@/components/StockTickerTape";
import { Card } from "@/components/ui/card";
import ExpertBiography from "@/components/expert/ExpertBiography";
import ExpertStockPicks from "@/components/expert/ExpertStockPicks";
import PortfolioChart from "@/components/expert/PortfolioChart";
import ExpertSidebar from "@/components/expert/ExpertSidebar";
import RecentAnalysis from "@/components/expert/RecentAnalysis";
import SectorChart from "@/components/expert/SectorChart";
import BerkshireInvestors from "@/components/expert/BerkshireInvestors";
import { useExpertStockPicks } from "@/hooks/useExpertData";
import { expertSectorData } from "@/data/expertSectors";
import { 
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator
} from "@/components/ui/breadcrumb";
import { Home } from "lucide-react";

const ExpertProfile = () => {
  const { expertId } = useParams<{ expertId: string }>();
  const { stockPicksData, isLoading, expertData } = useExpertStockPicks(expertId);

  // Get sector data for the current expert
  const sectorData = expertId ? expertSectorData[expertId] || [] : [];
  
  // Check if the current expert is Warren Buffett
  const isWarrenBuffett = expertId === "warren-buffett";
  
  if (!expertData) {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50">
        <Header />
        <div className="container mx-auto py-12">
          <h1 className="text-2xl font-bold">Expert not found</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t border-gray-300">
        <TopicBar />
      </div>
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="flex-1">
        <div className="container mx-auto py-6">
          {/* Breadcrumb navigation */}
          <Breadcrumb className="mb-6">
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/" className="flex items-center">
                    <Home className="h-4 w-4 mr-1" />
                    Home
                  </Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>{expertData.name}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>

          <div className="flex flex-col lg:flex-row gap-6">
            <div className="w-full lg:w-2/3">
              {/* Expert Biography and Stock Picks */}
              <Card className="mb-6">
                <ExpertBiography 
                  name={expertData.name}
                  title={expertData.title}
                  bio={expertData.bio}
                  specialty={expertData.specialty}
                  performance={expertData.performance}
                  imageUrl={expertData.imageUrl}
                />
                <ExpertStockPicks 
                  isLoading={isLoading}
                  stockPicksData={stockPicksData}
                />
              </Card>
              
              {/* Show BerkshireInvestors component only for Warren Buffett */}
              {isWarrenBuffett && (
                <BerkshireInvestors className="mb-6" />
              )}
              
              {/* Sector Chart */}
              {sectorData.length > 0 && (
                <SectorChart
                  expertName={expertData.name}
                  sectorData={sectorData}
                  className="mb-6"
                />
              )}
              
              {/* Portfolio Chart */}
              <PortfolioChart
                data={expertData.portfolioData}
                expertName={expertData.name}
                expertImage={expertData.imageUrl}
                className="mb-6"
              />
              
              {/* Recent Analysis */}
              <RecentAnalysis expertName={expertData.name} />
            </div>
            
            <div className="w-full lg:w-1/3">
              <ExpertSidebar name={expertData.name} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ExpertProfile;
