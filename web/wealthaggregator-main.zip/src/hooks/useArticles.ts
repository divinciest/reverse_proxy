
import { useState, useEffect, useCallback } from "react";
import { Article, FeedSource, CompanyMetadata, feedService } from "@/utils/feedService";
import { toast } from "sonner";

/**
 * CRITICAL WARNING - ZERO TOLERANCE POLICY FOR MOCK DATA
 * 
 * ABSOLUTELY NO MOCK DATA IS ALLOWED IN THIS HOOK, UNDER ANY CIRCUMSTANCES.
 * 
 * This file MUST only fetch data EXCLUSIVELY from real API calls.
 * Even in the case of errors, testing, or development, NO HARDCODED DATA
 * or FALLBACK VALUES are permitted.
 * 
 * Violation of this policy is strictly forbidden.
 * 
 * If API calls fail:
 * - Return empty arrays
 * - Set appropriate error states
 * - Log the error
 * - But NEVER fall back to sample/mock/hardcoded data
 * 
 * NO EXCEPTIONS. NO TEMPORARY SOLUTIONS.
 */

interface UseArticlesOptions {
  sourceIds?: string[];
  companyIds?: string[];
  initialDays?: number;
}

interface ArticleCounts {
  [id: string]: number;
}

export function useArticles(options: UseArticlesOptions = {}) {
  const [articles, setArticles] = useState<Article[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sourcesArticleCounts, setSourcesArticleCounts] = useState<ArticleCounts>({});
  const [companiesArticleCounts, setCompaniesArticleCounts] = useState<ArticleCounts>({});
  const [companies, setCompanies] = useState<CompanyMetadata[]>([]);
  const [feedSources, setFeedSources] = useState<FeedSource[]>([]);
  const [isApiAvailable, setIsApiAvailable] = useState(true);
  
  const { sourceIds, companyIds, initialDays = 7 } = options;

  // Fetch feed sources from the API - NEVER use static data
  useEffect(() => {
    const loadFeedSources = async () => {
      try {
        const sources = await feedService.getPopularFeeds();
        setFeedSources(sources);
        setIsApiAvailable(true);
      } catch (err) {
        console.error("Error loading feed sources:", err);
        setIsApiAvailable(false);
      }
    };
    
    loadFeedSources();
  }, []);

  const fetchArticles = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      let fetchedArticles: Article[] = [];
      let fetchedCompanies: CompanyMetadata[] = [];
      
      if (!isApiAvailable) {
        // API is not available - show error
        console.error("API is not available. Unable to fetch articles.");
        setError("API connection is unavailable. Please try again later.");
        setArticles([]);
        setSourcesArticleCounts({});
        setCompaniesArticleCounts({});
        setCompanies([]);
        setIsLoading(false);
        return;
      }
      
      if (companyIds && companyIds.length > 0) {
        // Fetch articles for specific companies
        const companyPromises = companyIds.map(id => 
          feedService.getCompanyArticles(id)
        );
        
        const companyResults = await Promise.allSettled(companyPromises);
        
        // Collect all articles from successful company requests
        fetchedArticles = companyResults
          .filter((result): result is PromiseFulfilledResult<{
            company: string;
            articles: Article[];
            feeds_sourced: any[];
            companies_metadata: any[];
          }> => result.status === 'fulfilled')
          .flatMap(result => result.value.articles || []);
          
        // Collect all company metadata from successful requests
        fetchedCompanies = companyResults
          .filter((result): result is PromiseFulfilledResult<{
            company: string;
            articles: Article[];
            feeds_sourced: any[];
            companies_metadata: CompanyMetadata[];
          }> => result.status === 'fulfilled')
          .flatMap(result => result.value.companies_metadata || []);
      } else {
        // Get all popular feeds first if we haven't loaded them yet
        const currentFeedSources = feedSources.length > 0 ? feedSources : await feedService.getPopularFeeds();
        
        // Filter sources by IDs if provided
        const relevantFeeds = sourceIds && sourceIds.length > 0
          ? currentFeedSources.filter(feed => sourceIds.includes(feed._id))
          : currentFeedSources.filter(feed => feed.enabled);
        
        // Extract URLs from selected sources
        const urls = relevantFeeds.flatMap(feed => feed.urls || []);
        
        if (urls.length > 0) {
          console.log(`Fetching articles from ${urls.length} feed URLs:`, urls);
          // Fetch articles from multiple feeds
          const response = await feedService.getFeedsArticles(urls, initialDays);
          fetchedArticles = response?.articles || [];
          fetchedCompanies = response?.companies || [];
        } else {
          setError("No feed URLs available");
        }
      }
      
      // Set articles from API response only - NEVER generate mock articles
      setArticles(fetchedArticles);
      setCompanies(fetchedCompanies);

      // Calculate article counts by source and company
      const sourceCountsMap: ArticleCounts = {};
      const companyCountsMap: ArticleCounts = {};
      
      // Count articles by source
      fetchedArticles.forEach(article => {
        if (article.source) {
          const sourceItem = feedSources.find(s => s.name === article.source);
          if (sourceItem) {
            sourceCountsMap[sourceItem._id] = (sourceCountsMap[sourceItem._id] || 0) +  1;
          }
        }
      });
      
      // Use the article_count property from companies API response
      if (fetchedCompanies && fetchedCompanies.length > 0) {
        fetchedCompanies.forEach(company => {
          if (company._id) {
            companyCountsMap[company._id] = company.article_count || 0;
          }
        });
      } else {
        // Fallback to counting the companies mentioned in articles
        fetchedArticles.forEach(article => {
          if (article.companies && Array.isArray(article.companies)) {
            article.companies.forEach(company => {
              if (typeof company === 'string') {
                companyCountsMap[company] = (companyCountsMap[company] || 0) + 1;
              } else if (company && typeof company === 'object' && '_id' in company) {
                companyCountsMap[company._id] = (companyCountsMap[company._id] || 0) + 1;
              }
            });
          }
        });
      }
      
      setSourcesArticleCounts(sourceCountsMap);
      setCompaniesArticleCounts(companyCountsMap);
    } catch (err) {
      console.error("Error fetching articles:", err);
      setError(err instanceof Error ? err.message : "Failed to fetch articles");
      toast.error("Could not load articles. Please try again later.");
      
      // Set empty arrays on error - NEVER use mock data
      setArticles([]);
      setSourcesArticleCounts({});
      setCompaniesArticleCounts({});
      setCompanies([]);
    } finally {
      setIsLoading(false);
    }
  }, [sourceIds, companyIds, initialDays, feedSources, isApiAvailable]);

  useEffect(() => {
    fetchArticles();
  }, [fetchArticles]);

  const refreshArticles = () => {
    fetchArticles();
  };

  return { 
    articles, 
    isLoading, 
    error, 
    refreshArticles,
    sourcesArticleCounts,
    companiesArticleCounts,
    companies,
    isApiAvailable
  };
}
