
import { useState, useEffect, useMemo } from "react";
import { toast } from "sonner";
import { Author } from "@/data/authors";
import { authors as initialAuthors, getAuthor, authorArticles } from "@/data/authors";

export function useAuthors() {
  const [authors, setAuthors] = useState<Author[]>(initialAuthors);
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingAuthorId, setEditingAuthorId] = useState<string | null>(null);
  const [authorSearch, setAuthorSearch] = useState("");
  const [authorSort, setAuthorSort] = useState<"default" | "az" | "za" | "articles">("default");
  
  const filteredSortedAuthors = useMemo(() => {
    let result = [...authors];
    
    if (authorSearch) {
      result = result.filter(author => 
        author.name.toLowerCase().includes(authorSearch.toLowerCase()) ||
        author.publication.toLowerCase().includes(authorSearch.toLowerCase())
      );
    }
    
    if (authorSort === "az") {
      result.sort((a, b) => a.name.localeCompare(b.name));
    } else if (authorSort === "za") {
      result.sort((a, b) => b.name.localeCompare(a.name));
    } else if (authorSort === "articles") {
      result.sort((a, b) => {
        const aArticles = authorArticles[a.id]?.length || 0;
        const bArticles = authorArticles[b.id]?.length || 0;
        return bArticles - aArticles;
      });
    } else {
      // Default sort by number of articles
      result.sort((a, b) => {
        const aArticles = authorArticles[a.id]?.length || 0;
        const bArticles = authorArticles[b.id]?.length || 0;
        return bArticles - aArticles;
      });
    }
    
    return result;
  }, [authors, authorSearch, authorSort]);

  const handleAddAuthor = (newAuthor: Omit<Author, "id">) => {
    setIsAdding(true);
    
    try {
      const authorId = newAuthor.name
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "-")
        .replace(/-+/g, "-")
        .replace(/^-|-$/g, "");
      
      if (authors.some(author => author.id === authorId)) {
        toast.error("An author with a similar name already exists");
        setIsAdding(false);
        return;
      }

      const authorWithId = {
        ...newAuthor,
        id: authorId,
      };

      setAuthors(prevAuthors => [...prevAuthors, authorWithId]);
      toast.success(`Added new author: ${newAuthor.name}`);
    } catch (error) {
      console.error("Error adding author:", error);
      toast.error("Failed to add author");
    } finally {
      setIsAdding(false);
    }
  };

  const handleUpdateAuthor = (updatedAuthor: Author) => {
    setIsEditing(true);
    
    try {
      setAuthors(prevAuthors => 
        prevAuthors.map(author => 
          author.id === updatedAuthor.id ? updatedAuthor : author
        )
      );
      toast.success(`Updated author: ${updatedAuthor.name}`);
      setEditingAuthorId(null);
    } catch (error) {
      console.error("Error updating author:", error);
      toast.error("Failed to update author");
    } finally {
      setIsEditing(false);
    }
  };

  const handleDeleteAuthor = (id: string) => {
    setAuthors(authors.filter(author => author.id !== id));
    toast.success("Author deleted successfully");
  };

  const getAuthorArticleCount = (authorId: string): number => {
    return authorArticles[authorId]?.length || 0;
  };

  const startEditingAuthor = (id: string) => {
    setEditingAuthorId(id);
  };

  const cancelEditing = () => {
    setEditingAuthorId(null);
  };

  return {
    authors,
    filteredSortedAuthors,
    isAdding,
    isEditing,
    editingAuthorId,
    authorSearch,
    authorSort,
    setAuthorSearch,
    setAuthorSort,
    handleAddAuthor,
    handleUpdateAuthor,
    handleDeleteAuthor,
    getAuthorArticleCount,
    startEditingAuthor,
    cancelEditing
  };
}
