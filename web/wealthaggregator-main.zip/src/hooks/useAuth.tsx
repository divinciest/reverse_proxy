
import React, { createContext, useState, useContext, useEffect, ReactNode } from "react";
import { authService, User } from "@/utils/auth";
import { toast } from "sonner";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  signup: (email: string, password: string, username?: string, isAdmin?: boolean, adminKey?: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializeAuth = async () => {
      setIsLoading(true);
      try {
        // Try to get user from local storage first for instant UI update
        const storedUser = localStorage.getItem("userData");
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }

        // Then verify with the server
        const currentUser = await authService.getCurrentUser();
        if (currentUser) {
          setUser(currentUser);
          // Update stored user data with latest from server
          localStorage.setItem("userData", JSON.stringify(currentUser));
        } else if (storedUser) {
          // If we had a stored user but server says invalid, clear it
          setUser(null);
          localStorage.removeItem("userData");
          localStorage.removeItem("authToken");
        }
      } catch (error) {
        console.error("Auth initialization error:", error);
      } finally {
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    const response = await authService.login(email, password);
    if (response) {
      setUser(response.user);
      toast.success(`Welcome back, ${response.user.username || response.user.email}!`);
      return true;
    }
    return false;
  };

  const logout = () => {
    authService.logout();
    setUser(null);
    toast.info("You have been logged out");
  };

  const signup = async (
    email: string, 
    password: string, 
    username?: string, 
    isAdmin: boolean = false, 
    adminKey?: string
  ): Promise<boolean> => {
    return await authService.signup(email, password, username, isAdmin, adminKey);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        isAdmin: user?.role === "admin" || false,
        login,
        logout,
        signup,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
