import { useState, useMemo } from 'react';
import { FinanceBook } from '@/utils/books';

export function useSortedBooks(books: FinanceBook[]) {
  const [currentSort, setCurrentSort] = useState<string>("default");
  
  // Sort books based on currentSort
  const sortedBooks = useMemo(() => {
    if (!books) return [];
    
    const sortedData = [...books];
    
    switch (currentSort) {
      case "az":
        return sortedData.sort((a, b) => a.title.localeCompare(b.title));
      case "za":
        return sortedData.sort((a, b) => b.title.localeCompare(a.title));
      case "yearNew":
        return sortedData.sort((a, b) => b.year - a.year);
      case "yearOld":
        return sortedData.sort((a, b) => a.year - b.year);
      default:
        return sortedData;
    }
  }, [books, currentSort]);

  return {
    currentSort,
    setCurrentSort,
    sortedBooks
  };
}
