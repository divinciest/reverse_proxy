
import { useState, useEffect, useCallback } from "react";
import { FeedSource, CompanyMetadata, feedService, adminFeedService } from "@/utils/feedService";
import { toast } from "sonner";
import { getBestFaviconUrl } from "@/utils/favicon";
import { FeedSource as AdminFeedSource } from "@/types/admin";

// Function to convert API FeedSource to AdminFeedSource for admin UI
const convertApiToAdminFeedSource = (apiFeed: FeedSource): AdminFeedSource => {
  return {
    id: apiFeed._id,
    name: apiFeed.name,
    logo: apiFeed.favicon || "",
    count: 0, // We'll need to get this from elsewhere
    selected: apiFeed.enabled,
    url: apiFeed.urls[0] || "",
    lastFetched: new Date().toISOString()
  };
};

// Convert AdminFeedSource to API FeedSource format for backend operations
const convertAdminToApiFeedSource = (adminFeed: Omit<AdminFeedSource, "id" | "lastFetched">): { name: string, urls: string[] } => {
  return {
    name: adminFeed.name,
    urls: adminFeed.url ? [adminFeed.url] : []
  };
};

export function useFeeds(initialFeeds: AdminFeedSource[] = []) {
  const [feeds, setFeeds] = useState<AdminFeedSource[]>(initialFeeds);
  const [feedSearch, setFeedSearch] = useState("");
  const [feedSort, setFeedSort] = useState<"default" | "az" | "za">("default");
  const [isFetching, setIsFetching] = useState(false);
  const [lastAutoFetch, setLastAutoFetch] = useState<Date | null>(null);

  const loadFeeds = useCallback(async () => {
    setIsFetching(true);
    try {
      const popularFeeds = await feedService.getPopularFeeds();
      // Convert API feeds to admin feeds format
      const adminFeeds = popularFeeds.map(feed => convertApiToAdminFeedSource(feed));
      setFeeds(adminFeeds);
      setLastAutoFetch(new Date());
    } catch (error) {
      console.error("Error loading feeds:", error);
      toast.error("Failed to load feed sources");
    } finally {
      setIsFetching(false);
    }
  }, []);

  useEffect(() => {
    loadFeeds();
  }, [loadFeeds]);

  const refreshArticleCounts = async (silent = true) => {
    if (!silent) {
      setIsFetching(true);
    }
    
    try {
      // First clear cache to ensure we get fresh data
      await feedService.clearRssCache();
      
      // Then reload feeds
      await loadFeeds();
      
      if (!silent) {
        toast.success("Feed sources refreshed");
      }
    } catch (error) {
      console.error("Error refreshing feeds:", error);
      if (!silent) {
        toast.error("Failed to refresh feeds");
      }
    } finally {
      if (!silent) {
        setIsFetching(false);
      }
    }
  };

  const handleAddFeed = async (feedData: Omit<AdminFeedSource, "id" | "lastFetched">) => {
    try {
      if (!feedData.name.trim()) {
        toast.error("Feed name is required");
        return;
      }

      if (!feedData.url) {
        toast.error("Feed URL is required");
        return;
      }

      // Convert to API format
      const apiFeedData = convertAdminToApiFeedSource(feedData);
      
      // Add new feed via API
      const newFeed = await adminFeedService.addFeedSource(apiFeedData.name, apiFeedData.urls);
      
      // Convert API response to admin feed format
      const adminFeed = convertApiToAdminFeedSource(newFeed);
      
      // Update local state
      setFeeds((prevFeeds) => [...prevFeeds, adminFeed]);
      
      toast.success(`Added new feed source: ${feedData.name}`);
    } catch (error) {
      console.error("Error adding feed:", error);
      toast.error("Failed to add feed source");
    }
  };

  const handleDeleteFeed = async (id: string) => {
    try {
      // For "all" feed, prevent deletion
      if (id === "all") {
        toast.error("The 'All' feed cannot be deleted");
        return;
      }

      // Update the status to disabled instead of deleting
      await adminFeedService.updateFeedStatus(id, false);
      
      // Update local state
      setFeeds((prevFeeds) => prevFeeds.filter((feed) => feed.id !== id));
      
      toast.success("Feed source deleted successfully");
    } catch (error) {
      console.error("Error deleting feed:", error);
      toast.error("Failed to delete feed source");
    }
  };

  const handleAddLogo = async (id: string) => {
    try {
      const feed = feeds.find((f) => f.id === id);
      if (!feed) return;

      // For feeds, we can use the domain
      let domain = "";
      if (feed.url) {
        try {
          const url = new URL(feed.url);
          domain = url.hostname;
        } catch (e) {
          console.error("Invalid URL:", feed.url);
        }
      }

      // Generate favicon URL based on name and domain
      const faviconUrl = getBestFaviconUrl(feed.name, domain);

      // In a real app, we would update this on the backend
      // For now, we'll just update the local state
      setFeeds((prevFeeds) =>
        prevFeeds.map((f) => (f.id === id ? { ...f, logo: faviconUrl } : f))
      );

      toast.success(`Generated logo for ${feed.name}`);
    } catch (error) {
      console.error("Error adding logo:", error);
      toast.error("Failed to generate logo");
    }
  };

  // Filtered and sorted feeds
  const filteredSortedFeeds = (() => {
    let result = [...feeds];

    // Apply search filter
    if (feedSearch) {
      result = result.filter((feed) =>
        feed.name.toLowerCase().includes(feedSearch.toLowerCase())
      );
    }

    // Apply sort
    if (feedSort === "az") {
      result.sort((a, b) => a.name.localeCompare(b.name));
    } else if (feedSort === "za") {
      result.sort((a, b) => b.name.localeCompare(a.name));
    }

    return result;
  })();

  return {
    feeds,
    filteredSortedFeeds,
    feedSearch,
    feedSort,
    isFetching,
    lastAutoFetch,
    setFeedSearch,
    setFeedSort,
    refreshArticleCounts,
    handleAddFeed,
    handleDeleteFeed,
    handleAddLogo,
  };
}
