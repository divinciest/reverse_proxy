
import { useState, useEffect } from "react";
import { sources } from "@/data/sources";
import { Article } from "@/data/types";
import { useToast } from "@/hooks/use-toast";
import { useArticles } from "@/hooks/useArticles";
import { convertApiArticleToUiArticle } from "@/utils/articleUtils";

/**
 * CRITICAL WARNING - ZERO TOLERANCE POLICY FOR MOCK DATA
 * 
 * ABSOLUTELY NO MOCK DATA IS ALLOWED IN THIS HOOK, UNDER ANY CIRCUMSTANCES.
 * 
 * This file MUST only fetch data EXCLUSIVELY from real API calls.
 * Even in the case of errors, testing, or development, NO HARDCODED DATA
 * or FALLBACK VALUES are permitted.
 * 
 * Violation of this policy is strictly forbidden.
 * 
 * If API calls fail:
 * - Return empty arrays
 * - Set appropriate error states
 * - Log the error
 * - But NEVER fall back to sample/mock/hardcoded data
 * 
 * NO EXCEPTIONS. NO TEMPORARY SOLUTIONS.
 */

export function useSourceArticles(sourceId: string | undefined) {
  const [lastFetched, setLastFetched] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [sourceArticles, setSourceArticles] = useState<Article[]>([]);
  const { toast } = useToast();
  const { articles: allApiArticles, isApiAvailable } = useArticles();
  
  // Convert API articles to data articles for consistency
  const allArticles = allApiArticles.map(convertApiArticleToUiArticle);
  
  // Find current source
  const source = sources.find((s) => s.id === sourceId);
  
  // Function to fetch articles for a specific source - ONLY from API, NEVER use mock data
  const fetchArticlesForSource = (sourceId: string) => {
    setIsLoading(true);
    
    // Get source name from sources array
    const sourceName = sources.find(s => s.id === sourceId)?.name || "";
    
    // Small delay for UX purposes only
    setTimeout(() => {
      console.log(`Fetching articles for ${sourceName} with ID ${sourceId}`);
      
      // Filter articles by source name - using ONLY articles from API
      let filteredArticles = allArticles.filter((article) => 
        article.source.toLowerCase() === sourceName.toLowerCase()
      );
      
      console.log(`Found ${filteredArticles.length} articles for ${sourceName} in data`);
      
      // NO mock article generation is allowed - only use real data
      setSourceArticles(filteredArticles);
      setIsLoading(false);
    }, 500);
  };

  // Check local storage for last fetched time and fetch articles on page load
  useEffect(() => {
    if (source) {
      // Get last fetched time from localStorage
      const storedFetchData = localStorage.getItem(`feed_last_fetched_${source.id}`);
      if (storedFetchData) {
        setLastFetched(storedFetchData);
      } else {
        // If no stored data, set to current time and store it
        const currentTime = new Date().toISOString();
        setLastFetched(currentTime);
        localStorage.setItem(`feed_last_fetched_${source.id}`, currentTime);
      }
      
      // Automatically fetch articles when component mounts
      fetchArticlesForSource(source.id);
    }
  }, [source, allArticles]);

  // Function to handle manual refresh of articles
  const handleRefreshArticles = () => {
    if (!source) return;
    
    setIsLoading(true);
    
    // Short delay for UX purposes only
    setTimeout(() => {
      // Update the last fetched time
      const currentTime = new Date().toISOString();
      setLastFetched(currentTime);
      localStorage.setItem(`feed_last_fetched_${source.id}`, currentTime);
      
      // Fetch articles
      fetchArticlesForSource(source.id);
      
      toast({
        title: "Articles Refreshed",
        description: `Latest articles from ${source.name} have been fetched.`,
      });
    }, 1500);
  };

  return {
    source,
    sourceArticles,
    lastFetched,
    isLoading,
    handleRefreshArticles,
    isApiAvailable
  };
}
