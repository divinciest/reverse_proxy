
import { useState, useEffect, useCallback, useMemo } from "react";
import { warrenBuffettPortfolio, carlIcahnPortfolio, cathieWoodPortfolio } from "@/data/expertPortfolios";
import { StockPickData, getMultipleStockPicks } from "@/utils/stockPickService";

export interface ExpertTopPick {
  ticker: string; 
  name: string; 
  exchange: string;
}

export interface ExpertData {
  name: string;
  imageUrl: string;
  title: string;
  bio: string;
  specialty: string;
  performance: string;
  topPicks: ExpertTopPick[];
  portfolioData: any[];
}

// This would typically come from an API or database
export const getExpertData = (id: string): ExpertData | null => {
  const experts: Record<string, ExpertData> = {
    "warren-buffett": {
      name: "Warren Buffett",
      imageUrl: "/lovable-uploads/ecd851fe-cc7e-4e84-8a01-516b2b3fad96.png",
      title: "Chairman and CEO of Berkshire Hathaway",
      bio: "Warren Buffett is an American business magnate, investor, and philanthropist. He is widely considered one of the most successful investors in the world.",
      specialty: "Value Investing",
      performance: "+12.5% YTD",
      topPicks: [
        { ticker: "AAPL", name: "Apple", exchange: "NASDAQ" },
        { ticker: "BAC", name: "Bank of America", exchange: "NYSE" },
        { ticker: "KO", name: "Coca-Cola", exchange: "NYSE" },
        { ticker: "AXP", name: "American Express", exchange: "NYSE" }
      ],
      portfolioData: warrenBuffettPortfolio,
    },
    "carl-icahn": {
      name: "Carl Icahn",
      imageUrl: "/lovable-uploads/6cac2ef1-c8a4-4b34-91a5-e39350000214.png",
      title: "Chairman of Icahn Enterprises",
      bio: "Carl Icahn is an American businessman, investor, and philanthropist. He is the founder and controlling shareholder of Icahn Enterprises.",
      specialty: "Activist Investing",
      performance: "+7.8% YTD",
      topPicks: [
        { ticker: "CVI", name: "CVR Energy", exchange: "NYSE" },
        { ticker: "NWL", name: "Newell Brands", exchange: "NASDAQ" },
        { ticker: "OXY", name: "Occidental Petroleum", exchange: "NYSE" },
        { ticker: "SWX", name: "Southwest Gas", exchange: "NYSE" }
      ],
      portfolioData: carlIcahnPortfolio,
    },
    "cathie-wood": {
      name: "Cathie Wood",
      imageUrl: "/lovable-uploads/25661a83-dd08-471b-8b53-df4c8bd950b1.png", 
      title: "Founder and CEO of ARK Invest",
      bio: "Cathie Wood is the founder, CEO, and CIO of ARK Invest, an investment management firm that focuses on disruptive innovation.",
      specialty: "Innovation Investing",
      performance: "-5.2% YTD",
      topPicks: [
        { ticker: "TSLA", name: "Tesla", exchange: "NASDAQ" },
        { ticker: "ZM", name: "Zoom", exchange: "NASDAQ" },
        { ticker: "SQ", name: "Block (Square)", exchange: "NYSE" },
        { ticker: "ROKU", name: "Roku", exchange: "NASDAQ" }
      ],
      portfolioData: cathieWoodPortfolio,
    }
  };
  
  return experts[id] || null;
};

export const useExpertStockPicks = (expertId: string | undefined) => {
  const [stockPicksData, setStockPicksData] = useState<StockPickData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Memoize expert data to prevent re-calculations on every render
  const expertData = useMemo(() => 
    expertId ? getExpertData(expertId) : null,
    [expertId]
  );

  // Use useCallback to prevent recreation of this function on every render
  const fetchStockPicks = useCallback(async () => {
    if (expertData?.topPicks) {
      setIsLoading(true);
      try {
        const picksData = await getMultipleStockPicks(expertData.topPicks);
        setStockPicksData(picksData);
      } catch (error) {
        console.error("Error fetching stock picks:", error);
      } finally {
        setIsLoading(false);
      }
    }
  }, [expertData]);

  useEffect(() => {
    // Only fetch if we have expert data and haven't already loaded data
    if (expertData && (stockPicksData.length === 0 || isLoading)) {
      fetchStockPicks();
    }
    
    // Set up a refresh interval (optional, can be removed if not needed)
    // const intervalId = setInterval(fetchStockPicks, 60000); // Refresh every minute
    
    // return () => clearInterval(intervalId);
  }, [expertData, fetchStockPicks]);

  return { stockPicksData, isLoading, expertData };
};
