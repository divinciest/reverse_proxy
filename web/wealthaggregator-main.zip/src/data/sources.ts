
import { Source } from './types';

export const sources: Source[] = [
  {
    id: "bloomberg",
    name: "Bloomberg",
    url: "https://www.bloomberg.com",
    category: "Markets & Economy",
    logoUrl: "/lovable-uploads/5f76db07-6347-48db-b300-d4cd7b15f8b8.png"
  },
  {
    id: "yahoo",
    name: "Yahoo Finance",
    url: "https://finance.yahoo.com",
    category: "Investing"
  },
  {
    id: "reuters",
    name: "Reuters",
    url: "https://www.reuters.com",
    category: "Markets & Economy"
  },
  {
    id: "ft",
    name: "Financial Times",
    url: "https://www.ft.com",
    category: "Markets & Economy"
  },
  {
    id: "cnbc",
    name: "CNBC",
    url: "https://www.cnbc.com",
    category: "Markets & Economy"
  },
  {
    id: "wsj",
    name: "Wall Street Journal",
    url: "https://www.wsj.com",
    category: "Markets & Economy"
  },
  {
    id: "forbes",
    name: "Forbes",
    url: "https://www.forbes.com",
    category: "Business"
  },
  {
    id: "market",
    name: "MarketWatch",
    url: "https://www.marketwatch.com",
    category: "Markets & Economy"
  },
  {
    id: "nbc",
    name: "NBC",
    url: "https://www.nbcnews.com",
    category: "General News"
  }
];
