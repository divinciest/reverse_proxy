
export interface Article {
  id: string;
  title: string;
  source: string;
  sourceUrl: string;
  category?: string;
  summary: string;
  publishDate?: string;
  date?: string;
  url?: string;
  sentiment?: 'bullish' | 'neutral' | 'bearish';
  leftCoverage?: number;
  rightCoverage?: number;
  centerCoverage?: number;
  sourceCount?: number;
  imageUrl?: string;
  topics?: string[];
  tags?: string[];
  hoursAgo?: number;
  author?: { name: string; image: string | null };
  sourceLogo?: string;
  sourceColor?: string;
  companies?: any[];
}

export interface Source {
  id: string;
  name: string;
  url: string;
  category: string;
  logoUrl?: string;
}
