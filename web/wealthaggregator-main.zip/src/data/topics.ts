
import { Article, Source } from './types';
import { Topic } from '@/types/admin';

// Define topics as strings for simplicity
export const topicsStrings = [
  "Billionaires",
  "US Economy",
  "Wall Street",
  "Federal Reserve",
  "Inflation",
  "Stock Markets",
  "Trade War",
  "Donald Trump",
  "Tariffs",
  "US Politics",
  "Recession",
  "S&P 500",
  "Money",
  "Wages",
  "Asian Economy",
  "Technology & AI",
  "Banking",
  "Interest Rates",
  "Real Estate",
  "Cryptocurrency",
  "Small Business",
  "Global Markets",
  "Investment Strategies"
];

// Convert the topic strings to Topic objects for use with the admin UI
export const topics: Topic[] = topicsStrings.map(name => ({
  name,
  count: 0,
  selected: false
}));
