
import { PortfolioItem } from "@/components/expert/PortfolioTypes";

// Warren Buffett's Berkshire Hathaway portfolio data
export const warrenBuffettPortfolio: PortfolioItem[] = [
  { name: "Apple Inc", value: 28.12, amount: 75100000000, color: "#4285F4" },
  { name: "American Express Co", value: 16.84, amount: 45000000000, color: "#34A853" },
  { name: "Bank of America Corp", value: 11.19, amount: 29900000000, color: "#FBBC05" },
  { name: "Coca-Cola Co", value: 9.32, amount: 24900000000, color: "#EA4335" },
  { name: "Chevron Corp", value: 6.43, amount: 17200000000, color: "#8667C9" },
  { name: "Occidental Petroleum Corp", value: 4.89, amount: 13000000000, color: "#FFC928" },
  { name: "Moodys Corp", value: 4.37, amount: 11700000000, color: "#36C5F0" },
  { name: "The Kraft Heinz Co", value: 3.74, amount: 10000000000, color: "#A1D36E" },
  { name: "Chubb Ltd", value: 2.80, amount: 7500000000, color: "#D4A650" },
  { name: "DaVita Inc", value: 2.02, amount: 5400000000, color: "#E96E9C" },
  { name: "Others", value: 10.28, amount: 27500000000, color: "#CCCCCC" },
];

// Carl Icahn's portfolio data (simplified for demonstration)
export const carlIcahnPortfolio: PortfolioItem[] = [
  { name: "CVR Energy", value: 22.15, amount: 3200000000, color: "#4285F4" },
  { name: "Newell Brands", value: 18.42, amount: 2700000000, color: "#34A853" },
  { name: "Occidental Petroleum", value: 16.78, amount: 2400000000, color: "#FBBC05" },
  { name: "Southwest Gas", value: 12.33, amount: 1800000000, color: "#EA4335" },
  { name: "FirstEnergy", value: 10.57, amount: 1500000000, color: "#8667C9" },
  { name: "Icahn Enterprises", value: 9.84, amount: 1400000000, color: "#FFC928" },
  { name: "Bausch Health", value: 4.32, amount: 630000000, color: "#36C5F0" },
  { name: "Others", value: 5.59, amount: 810000000, color: "#CCCCCC" },
];

// Cathie Wood's ARK portfolio data (simplified for demonstration)
export const cathieWoodPortfolio: PortfolioItem[] = [
  { name: "Tesla", value: 19.87, amount: 2900000000, color: "#4285F4" },
  { name: "Zoom", value: 14.52, amount: 2100000000, color: "#34A853" },
  { name: "Square", value: 12.68, amount: 1850000000, color: "#FBBC05" },
  { name: "Roku", value: 11.34, amount: 1650000000, color: "#EA4335" },
  { name: "Coinbase", value: 8.92, amount: 1300000000, color: "#8667C9" },
  { name: "Unity Software", value: 7.64, amount: 1120000000, color: "#FFC928" },
  { name: "Teladoc Health", value: 6.85, amount: 1000000000, color: "#36C5F0" },
  { name: "Shopify", value: 5.73, amount: 840000000, color: "#A1D36E" },
  { name: "Twilio", value: 4.28, amount: 625000000, color: "#D4A650" },
  { name: "Others", value: 8.17, amount: 1190000000, color: "#CCCCCC" },
];
