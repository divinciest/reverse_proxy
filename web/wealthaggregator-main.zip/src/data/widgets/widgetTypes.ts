
// Define the widget types
export interface Widget {
  id: string;
  name: string;
  description: string;
  longDescription: string;
  category: "news" | "books" | "stocks" | "indexes" | "billionaires";
  imageUrl: string;
  featured: boolean;
  users: number;
  rating: number;
  version: string;
  updatedAt: string;
  features: {
    title: string;
    description: string;
  }[];
  reviews: {
    user: string;
    rating: number;
    date: string;
    comment: string;
  }[];
}
