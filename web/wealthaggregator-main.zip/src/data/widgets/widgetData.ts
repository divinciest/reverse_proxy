
import { Widget } from "./widgetTypes";

// Widget data
const widgets: Widget[] = [
  {
    id: "news-feed",
    name: "News Feed Widget",
    description: "Stay up-to-date with the latest financial news from trusted sources",
    longDescription: "The News Feed Widget provides a continuous stream of the latest financial news from top sources around the world. Get real-time updates on market movements, company announcements, economic reports, and more. The widget features customizable filters allowing you to focus on the news that matters most to your investments.",
    category: "news",
    imageUrl: "/lovable-uploads/0e976c5c-8310-4e78-b3e3-aa6b7ab8df50.png",
    featured: true,
    users: 25678,
    rating: 4.7,
    version: "2.3.1",
    updatedAt: "2023-03-15",
    features: [
      {
        title: "Real-time Updates",
        description: "Get the latest news as it happens with automatic refreshing"
      },
      {
        title: "Source Filtering",
        description: "Choose which news sources you want to include or exclude"
      },
      {
        title: "Topic Focus",
        description: "Filter news by topics, industries, or specific companies"
      },
      {
        title: "Sentiment Analysis",
        description: "See AI-powered sentiment indicators for each news item"
      }
    ],
    reviews: [
      {
        user: "InvestorPro",
        rating: 5,
        date: "2023-02-18",
        comment: "This news widget is incredible. I love how I can customize it to show only the sectors I care about."
      },
      {
        user: "MarketTrader",
        rating: 4,
        date: "2023-01-05",
        comment: "Very useful for keeping on top of market news. Would give 5 stars if it had better mobile support."
      }
    ]
  },
  {
    id: "book-recommendations",
    name: "Finance Books Widget",
    description: "Discover top-rated finance and investment books recommended by experts",
    longDescription: "The Finance Books Widget showcases handpicked book recommendations from leading financial experts and thought leaders. From investment strategies to personal finance, this widget helps you discover the knowledge you need to make better financial decisions. Each book comes with ratings, reviews, and insights into what makes it valuable.",
    category: "books",
    imageUrl: "/lovable-uploads/6095d2a3-1c1e-452e-9e81-ec09016e8dae.png",
    featured: true,
    users: 12405,
    rating: 4.5,
    version: "1.7.0",
    updatedAt: "2023-02-10",
    features: [
      {
        title: "Expert Recommendations",
        description: "Books chosen by top financial professionals and academics"
      },
      {
        title: "Category Filtering",
        description: "Browse books by investment type, skill level, or topic"
      },
      {
        title: "Reading Progress",
        description: "Track which books you've read or want to read"
      },
      {
        title: "Direct Purchase Links",
        description: "Buy books directly through affiliate partner links"
      }
    ],
    reviews: [
      {
        user: "BookwormInvestor",
        rating: 5,
        date: "2023-01-30",
        comment: "I've discovered so many amazing finance books through this widget. Great recommendations!"
      },
      {
        user: "WealthBuilder",
        rating: 4,
        date: "2022-12-15",
        comment: "Very helpful for finding quality books. Would be nice to have more international authors."
      }
    ]
  },
  {
    id: "stock-tracker",
    name: "Stock Tracker Widget",
    description: "Track your portfolio with real-time stock quotes and performance metrics",
    longDescription: "The Stock Tracker Widget lets you monitor your investments with real-time data on stock prices, performance trends, and key indicators. Create watchlists, set price alerts, and visualize your portfolio's performance over time. Perfect for active traders and long-term investors alike who want to stay on top of their investments.",
    category: "stocks",
    imageUrl: "/lovable-uploads/5f76db07-6347-48db-b300-d4cd7b15f8b8.png",
    featured: true,
    users: 34982,
    rating: 4.8,
    version: "3.1.2",
    updatedAt: "2023-03-20",
    features: [
      {
        title: "Real-time Stock Data",
        description: "Live quotes with minimal delay from major exchanges"
      },
      {
        title: "Custom Watchlists",
        description: "Create multiple watchlists for different investment strategies"
      },
      {
        title: "Technical Indicators",
        description: "View key metrics like RSI, MACD, moving averages and more"
      },
      {
        title: "Price Alerts",
        description: "Get notified when stocks hit your target prices"
      }
    ],
    reviews: [
      {
        user: "DayTraderPro",
        rating: 5,
        date: "2023-03-05",
        comment: "Best stock widget I've used. The real-time data is incredibly fast and accurate."
      },
      {
        user: "RetirementPlanner",
        rating: 5,
        date: "2023-02-22",
        comment: "Love how I can track my entire portfolio in one place with excellent visualization options."
      }
    ]
  },
  {
    id: "market-indices",
    name: "Market Indices Widget",
    description: "Monitor major market indices like S&P 500, Dow Jones, and NASDAQ in real-time",
    longDescription: "The Market Indices Widget provides a comprehensive view of global market indices performance. Track the S&P 500, Dow Jones Industrial Average, NASDAQ, and international markets all in one place. The widget includes historical performance charts, sector breakdowns, and comparative analysis tools to help you understand broader market trends.",
    category: "indexes",
    imageUrl: "/lovable-uploads/bd7de873-ae9d-4629-943c-a55bc2f536f5.png",
    featured: false,
    users: 28734,
    rating: 4.6,
    version: "2.0.3",
    updatedAt: "2023-02-28",
    features: [
      {
        title: "Global Market Coverage",
        description: "Track indices from North America, Europe, Asia, and emerging markets"
      },
      {
        title: "Historical Charts",
        description: "View performance over custom time periods with interactive charts"
      },
      {
        title: "Sector Analysis",
        description: "Break down index performance by industry sectors"
      },
      {
        title: "Correlation Tools",
        description: "See how different indices relate to each other"
      }
    ],
    reviews: [
      {
        user: "GlobalInvestor",
        rating: 5,
        date: "2023-02-10",
        comment: "Excellent for keeping track of markets worldwide. The sector breakdown is particularly useful."
      },
      {
        user: "MacroTrader",
        rating: 4,
        date: "2023-01-15",
        comment: "Very comprehensive index coverage. Would like to see more emerging markets added."
      }
    ]
  },
  {
    id: "billionaires-tracker",
    name: "Billionaires Tracker Widget",
    description: "Follow the wealth, investments, and strategies of the world's top billionaires",
    longDescription: "The Billionaires Tracker Widget lets you monitor the net worth, investment decisions, and business strategies of the world's wealthiest individuals. Get insights into which stocks billionaires are buying and selling, track their net worth changes in real-time, and learn from their success through detailed profiles and analysis of their investment philosophies.",
    category: "billionaires",
    imageUrl: "/lovable-uploads/66f05640-6829-49d4-acf1-555563f5024f.png",
    featured: true,
    users: 18965,
    rating: 4.7,
    version: "1.5.4",
    updatedAt: "2023-03-10",
    features: [
      {
        title: "Wealth Rankings",
        description: "Real-time updates of billionaire wealth rankings and changes"
      },
      {
        title: "Portfolio Insights",
        description: "See what stocks and assets billionaires are investing in"
      },
      {
        title: "Wealth Timeline",
        description: "Track how billionaire net worth has changed over time"
      },
      {
        title: "News Alerts",
        description: "Get notifications about major moves by billionaire investors"
      }
    ],
    reviews: [
      {
        user: "AspiringInvestor",
        rating: 5,
        date: "2023-03-01",
        comment: "Fascinating insights into how the ultra-wealthy invest. I've learned so much by following their moves."
      },
      {
        user: "ValueSeeker",
        rating: 4,
        date: "2023-02-12",
        comment: "Great widget for understanding billionaire strategies. Would like more historical data."
      }
    ]
  }
];

// Get all widgets
export const getWidgets = (): Widget[] => {
  return widgets;
};

// Get widget by ID
export const getWidgetById = (id: string): Widget | undefined => {
  return widgets.find(widget => widget.id === id);
};

// Get widgets by category
export const getWidgetsByCategory = (category: Widget['category']): Widget[] => {
  return widgets.filter(widget => widget.category === category);
};

// Get featured widgets
export const getFeaturedWidgets = (): Widget[] => {
  return widgets.filter(widget => widget.featured);
};
