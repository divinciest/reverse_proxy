
import { FeedSource, CompanySource, Topic } from "@/types/admin";

/**
 * CRITICAL WARNING - ZERO TOLERANCE POLICY FOR MOCK DATA
 * 
 * ABSOLUTELY NO MOCK DATA IS ALLOWED IN THIS APPLICATION, UNDER ANY CIRCUMSTANCES.
 * 
 * This file MUST only contain empty arrays that are populated EXCLUSIVELY 
 * from real API calls. Even in the case of errors, testing, or development,
 * NO HARDCODED DATA or FALLBACK VALUES are permitted.
 * 
 * Violation of this policy is strictly forbidden.
 * 
 * If API calls fail:
 * - Display appropriate error messages to users
 * - Log the error
 * - But NEVER fall back to sample/mock/hardcoded data
 * 
 * NO EXCEPTIONS. NO TEMPORARY SOLUTIONS.
 */

// These MUST be populated from API calls ONLY - NEVER add static data
export const feedSources: FeedSource[] = [];
export const companySources: CompanySource[] = [];
export const topics: Topic[] = [];
