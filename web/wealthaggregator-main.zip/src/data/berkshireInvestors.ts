
export interface BerkshireInvestor {
  firm: string;
  manager: string;
  sharesHeld: number;
  value: number; // in millions of dollars
  portfolioPercent: number;
  change: number; // net change in shares
}

export const berkshireInvestors: BerkshireInvestor[] = [
  {
    firm: "Berkshire Hathaway",
    manager: "Warren Buffett",
    sharesHeld: 229465000,
    value: 73288,
    portfolioPercent: 50.4,
    change: 0
  },
  {
    firm: "Bill & Melinda Gates Foundation Trust",
    manager: "Bill Gates",
    sharesHeld: 27866360,
    value: 8899,
    portfolioPercent: 45.7,
    change: -1900000
  },
  {
    firm: "The Vanguard Group",
    manager: "Mortimer J. Buckley",
    sharesHeld: 27631728,
    value: 8825,
    portfolioPercent: 0.3,
    change: 125488
  },
  {
    firm: "BlackRock",
    manager: "Laurence Fink",
    sharesHeld: 21248607,
    value: 6785,
    portfolioPercent: 0.2,
    change: -223451
  },
  {
    firm: "State Street",
    manager: "Ronald O'Hanley",
    sharesHeld: 11219369,
    value: 3583,
    portfolioPercent: 0.3,
    change: -891646
  },
  {
    firm: "Geode Capital Management",
    manager: "Robert Goldstein",
    sharesHeld: 7984705,
    value: 2550,
    portfolioPercent: 0.7,
    change: 63841
  }
];
