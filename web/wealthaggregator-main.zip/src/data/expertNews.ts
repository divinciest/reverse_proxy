
// Expert-specific news data
export interface NewsItem {
  date: string;
  title: string;
  link?: string;
  requiresSubscription?: boolean;
}

// News data for Warren Buffett
export const buffettNews: NewsItem[] = [
  {
    date: "11 Feb 2025",
    title: "Berkshire modestly increases Occidental Petroleum stake - 763,017 share added",
    link: "https://example.com/news/berkshire-occidental-stake"
  },
  {
    date: "03 Feb 2025",
    title: "Berkshire Hathaway boosts Sirius XM Holdings stake by 2.3 million shares or 2%",
    link: "https://example.com/news/berkshire-sirius-xm"
  },
  {
    date: "22 Jan 2025",
    title: "Meet the man picked to succeed Warren Buffett",
    link: "https://example.com/news/buffett-successor",
    requiresSubscription: true
  },
  {
    date: "22 Jan 2025",
    title: "Warren Buffett's Pilot Co shuts oil trading business, sources say",
    link: "https://example.com/news/pilot-co-oil-trading"
  },
  {
    date: "03 Jan 2025",
    title: "Berkshire Hathaway boosts Verisign stake by 20,044 shares or 0.15%",
    link: "https://example.com/news/berkshire-verisign-stake-1"
  },
  {
    date: "30 Dec 2024",
    title: "Berkshire Hathaway boosts Verisign stake by 76,487 shares or 0.6%",
    link: "https://example.com/news/berkshire-verisign-stake-2"
  },
  {
    date: "26 Dec 2024",
    title: "Berkshire boosts Verisign stake by 143,424 shares or 1%",
    link: "https://example.com/news/berkshire-verisign-stake-3"
  }
];

// News data for Carl Icahn
export const icahnNews: NewsItem[] = [
  {
    date: "14 Feb 2025",
    title: "Carl Icahn doubles stake in JetBlue Airways to 9.8%",
    link: "https://example.com/news/icahn-jetblue-stake"
  },
  {
    date: "06 Feb 2025",
    title: "Icahn raises SouthWest Gas holding to 15.2% from 14.7%",
    link: "https://example.com/news/icahn-southwest-gas"
  },
  {
    date: "28 Jan 2025",
    title: "Icahn Enterprises announces strategic restructuring plan",
    link: "https://example.com/news/icahn-enterprises-plan",
    requiresSubscription: true
  },
  {
    date: "12 Jan 2025",
    title: "Carl Icahn settles legal dispute with former protégé",
    link: "https://example.com/news/icahn-legal-settlement"
  }
];

// News data for Cathie Wood
export const woodNews: NewsItem[] = [
  {
    date: "15 Feb 2025",
    title: "ARK Invest buys $42M of Coinbase stock as Bitcoin surges past $90K",
    link: "https://example.com/news/ark-coinbase-purchase"
  },
  {
    date: "08 Feb 2025",
    title: "Cathie Wood: AI will drive 50% of economic growth by 2030",
    link: "https://example.com/news/cathie-wood-ai-prediction",
    requiresSubscription: true
  },
  {
    date: "01 Feb 2025",
    title: "ARK Innovation ETF sees first quarterly profit since 2021",
    link: "https://example.com/news/ark-innovation-etf-profit"
  },
  {
    date: "25 Jan 2025",
    title: "Cathie Wood reduces Robinhood stake by 5% amid regulatory concerns",
    link: "https://example.com/news/wood-reduces-robinhood"
  }
];

// Function to get news for a specific expert
export const getExpertNews = (expertName: string): NewsItem[] => {
  if (expertName === "Warren Buffett") {
    return buffettNews;
  } else if (expertName === "Carl Icahn") {
    return icahnNews;
  } else if (expertName === "Cathie Wood") {
    return woodNews;
  }
  return [];
};
