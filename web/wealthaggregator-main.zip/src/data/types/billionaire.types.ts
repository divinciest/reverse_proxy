
// Define billionaire-related types
export interface Billionaire {
  id: string;
  name: string;
  netWorth: number; // In billions
  change: number; // Daily change in billions
  changePercent: number; // Daily percent change
  rank: number;
  country: string;
  age: number;
  source: string; // Source of wealth
  mainCompany: string;
  companies: string[];
  companyIds: string[]; // References to company IDs for linking
  industries: string[];
  bio: string;
  imageUrl: string;
}

export interface BillionaireNews {
  id: string;
  title: string;
  date: string;
  source: string;
  url: string;
  summary: string;
  imageUrl?: string;
  relatedCompanies: string[];
}
