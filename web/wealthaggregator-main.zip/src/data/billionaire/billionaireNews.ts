
import { BillionaireNews } from "../types/billionaire.types";

// Sample news items for billionaires
const billionaireNewsItems: Record<string, BillionaireNews[]> = {
  "warren-buffett": [
    {
      id: "wb-news-1",
      title: "Buffett's Berkshire Hathaway sells more Bank of America shares",
      date: "2025-04-02",
      source: "Financial Times",
      url: "#",
      summary: "Warren Buffett's Berkshire Hathaway has further reduced its position in Bank of America, selling shares worth about $1.5 billion.",
      imageUrl: undefined,
      relatedCompanies: ["Berkshire Hathaway", "Bank of America"]
    },
    {
      id: "wb-news-2",
      title: "Buffett increases stake in Occidental Petroleum amid oil price volatility",
      date: "2025-03-28",
      source: "Wall Street Journal",
      url: "#",
      summary: "Berkshire Hathaway has increased its ownership in Occidental Petroleum to over 28%, signaling confidence in the energy sector.",
      imageUrl: undefined,
      relatedCompanies: ["Berkshire Hathaway", "Occidental Petroleum"]
    },
    {
      id: "wb-news-3",
      title: "Warren Buffett donates $4.1 billion to philanthropic foundations",
      date: "2025-03-15",
      source: "Business Insider",
      url: "#",
      summary: "The Oracle of Omaha continues his pledge to give away most of his wealth, with his latest donation going to five foundations.",
      imageUrl: undefined,
      relatedCompanies: ["Berkshire Hathaway"]
    }
  ],
  "elon-musk": [
    {
      id: "em-news-1",
      title: "Tesla announces new energy storage products at annual event",
      date: "2025-04-05",
      source: "Reuters",
      url: "#",
      summary: "Tesla unveiled next-generation energy storage solutions aimed at utility-scale applications.",
      imageUrl: undefined,
      relatedCompanies: ["Tesla"]
    },
    {
      id: "em-news-2",
      title: "SpaceX Starship completes successful orbital test flight",
      date: "2025-04-01",
      source: "CNBC",
      url: "#",
      summary: "The fifth test flight of SpaceX's Starship rocket successfully completed orbital insertion and recovery.",
      imageUrl: undefined,
      relatedCompanies: ["SpaceX"]
    },
    {
      id: "em-news-3",
      title: "Musk says X (Twitter) returning to profitability with focus on AI",
      date: "2025-03-25",
      source: "Bloomberg",
      url: "#",
      summary: "After challenging years, X is approaching profitability, according to owner Elon Musk.",
      imageUrl: undefined,
      relatedCompanies: ["X (Twitter)"]
    }
  ],
  "bernard-arnault": [
    {
      id: "ba-news-1",
      title: "LVMH posts record quarterly revenues as luxury demand rebounds in Asia",
      date: "2025-04-04",
      source: "Financial Times",
      url: "#",
      summary: "French luxury group LVMH reported better-than-expected first-quarter sales, driven by strong performance in fashion and leather goods.",
      imageUrl: undefined,
      relatedCompanies: ["LVMH"]
    },
    {
      id: "ba-news-2",
      title: "Bernard Arnault appoints daughter to lead Dior as succession plans take shape",
      date: "2025-03-22",
      source: "Vogue Business",
      url: "#",
      summary: "The appointment highlights the Arnault family's continued control over the luxury empire.",
      imageUrl: undefined,
      relatedCompanies: ["LVMH", "Christian Dior"]
    }
  ]
};

// Get news related to a billionaire
export const getBillionaireNews = (billionaireId: string): BillionaireNews[] => {
  // Return news for the specified billionaire, or empty array if none exist
  return billionaireNewsItems[billionaireId] || [];
};
