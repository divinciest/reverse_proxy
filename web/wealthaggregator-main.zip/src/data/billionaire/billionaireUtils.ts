
import { Billionaire } from "../types/billionaire.types";
import { getBestFaviconUrl } from "@/utils/favicon";

// Get billionaire company logos
export const getBillionaireCompanyLogos = (billionaire: Billionaire): Record<string, string> => {
  const logos: Record<string, string> = {};
  
  billionaire.companies.forEach((company, index) => {
    // Create domain from company name for favicon
    const domain = company.toLowerCase().replace(/[^a-z0-9]/g, '');
    logos[billionaire.companyIds[index] || domain] = getBestFaviconUrl(company, `${domain}.com`);
  });
  
  return logos;
};
