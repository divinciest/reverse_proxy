
// Sector data for expert portfolios
export interface SectorData {
  sector: string;
  weighting: number; // percentage weight in portfolio (positive)
  sellImpact?: number; // negative values represent selling impact
  buyImpact?: number; // positive values represent buying impact
}

export interface ExpertSectorAllocation {
  name: string;
  sectors: SectorData[];
}

// Warren Buffett's sector allocation data
export const warrenBuffettSectors: SectorData[] = [
  { sector: "Financial Services", weighting: 38.97, sellImpact: -3.04 },
  { sector: "Technology", weighting: 29.15, buyImpact: 0.04 },
  { sector: "Consumer Defensive", weighting: 14.68 },
  { sector: "Energy", weighting: 11.32, buyImpact: 0.47 },
  { sector: "Communication Services", weighting: 2.27, sellImpact: -0.15 },
  { sector: "Healthcare", weighting: 2.02 },
  { sector: "Consumer Cyclical", weighting: 1.23 },
  { sector: "Industrials", weighting: 0.37, sellImpact: -0.01 },
  { sector: "Real Estate", weighting: 0.00 }
];

// Carl Icahn's sector allocation data
export const carlIcahnSectors: SectorData[] = [
  { sector: "Energy", weighting: 42.35, buyImpact: 1.27 },
  { sector: "Consumer Cyclical", weighting: 18.42 },
  { sector: "Utilities", weighting: 12.33, buyImpact: 0.35 },
  { sector: "Healthcare", weighting: 10.57, sellImpact: -0.89 },
  { sector: "Industrials", weighting: 8.75 },
  { sector: "Financial Services", weighting: 7.58, sellImpact: -0.42 }
];

// Cathie Wood's sector allocation data
export const cathieWoodSectors: SectorData[] = [
  { sector: "Technology", weighting: 34.68, buyImpact: 1.85 },
  { sector: "Communication Services", weighting: 22.14, buyImpact: 0.72 },
  { sector: "Healthcare", weighting: 18.76, sellImpact: -1.05 },
  { sector: "Financial Services", weighting: 12.45, buyImpact: 0.38 },
  { sector: "Consumer Cyclical", weighting: 9.28 },
  { sector: "Industrials", weighting: 2.69, sellImpact: -0.24 }
];

// Export expert sector data
export const expertSectorData: Record<string, SectorData[]> = {
  "warren-buffett": warrenBuffettSectors,
  "carl-icahn": carlIcahnSectors,
  "cathie-wood": cathieWoodSectors
};
