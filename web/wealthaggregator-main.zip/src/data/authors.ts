import { Article } from "./types";

export interface Author {
  id: string;
  name: string;
  title: string;
  publication: string;
  bio: string;
  imageUrl?: string;
  twitterHandle?: string;
  rssUrl?: string;
  articles?: Article[];
}

export const authors: Author[] = [
  {
    id: "matt-levine",
    name: "Matt Levine",
    title: "Opinion Columnist",
    publication: "Bloomberg",
    bio: "Matt Levine is a Bloomberg Opinion columnist. A former investment banker at Goldman Sachs, he was a mergers and acquisitions lawyer at Wachtell, Lipton, Rosen & Katz; a clerk for the U.S. Court of Appeals for the 3rd Circuit; and an editor of Dealbreaker.",
    twitterHandle: "matt_levine",
    rssUrl: "https://www.bloomberg.com/authors/ARbTQlRLRjE/matthew-s-levine.rss",
    imageUrl: "https://images.unsplash.com/photo-1473091534298-04dcbce3278c?w=800&auto=format&fit=crop"
  },
  {
    id: "paul-krugman",
    name: "Paul Krugman",
    title: "Op-Ed Columnist",
    publication: "The New York Times",
    bio: "Paul Krugman is an American economist, Distinguished Professor of Economics at the Graduate Center of the City University of New York, and a columnist for The New York Times.",
    twitterHandle: "paulkrugman",
    rssUrl: "https://www.nytimes.com/svc/collections/v1/publish/https://www.nytimes.com/column/paul-krugman/rss.xml",
    imageUrl: "https://images.unsplash.com/photo-1590402494587-44b71d7772f6?w=800&auto=format&fit=crop"
  },
  {
    id: "scott-galloway",
    name: "Scott Galloway",
    title: "Professor of Marketing",
    publication: "No Mercy / No Malice",
    bio: "Scott Galloway is a professor of marketing at NYU Stern School of Business and a public speaker, author, and entrepreneur.",
    twitterHandle: "profgalloway",
    rssUrl: "https://www.profgalloway.com/feed/",
    imageUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=800&auto=format&fit=crop"
  },
  {
    id: "emma-smith",
    name: "Emma Smith",
    title: "Senior Editor",
    publication: "Pan Macmillan",
    bio: "Emma Smith is a senior editor at Pan Macmillan with over 15 years of experience in the publishing industry. She specializes in financial literature and personal development books, curating reading lists that help readers build wealth and financial literacy.",
    twitterHandle: "emmasmith_books",
    rssUrl: "https://www.panmacmillan.com/blogs/general/rss",
    imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&auto=format&fit=crop"
  }
];

// Mock articles for Matt Levine based on RSS feed
export const authorArticles: Record<string, Article[]> = {
  "matt-levine": [
    {
      id: "matt-levine-1",
      title: "Stablecoins Are Growing Up",
      summary: "Circle, slangy wealth management chatbots, private credit runs, SEC climate rules and OCC desk space.",
      source: "Bloomberg",
      sourceUrl: "https://www.bloomberg.com",
      category: "Money Stuff",
      publishDate: new Date().toISOString(),
      url: "https://www.bloomberg.com/opinion/articles/2023-03-25/stablecoins-are-growing-up",
      sentiment: "neutral",
      topics: ["finance", "crypto", "stablecoins"],
      imageUrl: "https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?w=800&auto=format&fit=crop"
    },
    {
      id: "matt-levine-2",
      title: "Is DOGE Securities Fraud?",
      summary: "Also the OpenAI coup, Goldman executive pay and putting the account number in the amount field.",
      source: "Bloomberg",
      sourceUrl: "https://www.bloomberg.com",
      category: "Money Stuff",
      publishDate: new Date(Date.now() - 86400000).toISOString(),
      url: "https://www.bloomberg.com/opinion/articles/2023-03-24/is-doge-securities-fraud",
      sentiment: "bearish",
      topics: ["finance", "crypto", "securities"],
      imageUrl: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=800&auto=format&fit=crop"
    },
    {
      id: "matt-levine-3",
      title: "Musk Merged His Xes",
      summary: "Also FX liquidity illusion, a Luna settlement, fraud convictions and pardons, and NYSE Texas.",
      source: "Bloomberg",
      sourceUrl: "https://www.bloomberg.com",
      category: "Money Stuff",
      publishDate: new Date(Date.now() - 172800000).toISOString(),
      url: "https://www.bloomberg.com/opinion/articles/2023-03-23/musk-merged-his-xes",
      sentiment: "neutral",
      topics: ["finance", "tech", "elon musk"],
      imageUrl: "https://images.unsplash.com/photo-1573091640776-354ad97171cc?w=800&auto=format&fit=crop"
    },
    {
      id: "matt-levine-4",
      title: "The Synthetic Lender of Last Resort",
      summary: "Basis trades, narrower banking, Robinhood estate planning, HSBC bonuses, Endeavor and GameStop.",
      source: "Bloomberg",
      sourceUrl: "https://www.bloomberg.com",
      category: "Money Stuff",
      publishDate: new Date(Date.now() - 259200000).toISOString(),
      url: "https://www.bloomberg.com/opinion/articles/2023-03-22/the-synthetic-lender-of-last-resort",
      sentiment: "bullish",
      topics: ["finance", "banking", "markets"],
      imageUrl: "https://images.unsplash.com/photo-1561414927-6d86591d0c4f?w=800&auto=format&fit=crop"
    },
    {
      id: "matt-levine-5",
      title: "You Can't Change Your Mind About Mergers",
      summary: "Desktop Metal, KKR Strategic Holdings, software loans, GameStop Bitcoins and incorrect cliches.",
      source: "Bloomberg",
      sourceUrl: "https://www.bloomberg.com",
      category: "Money Stuff",
      publishDate: new Date(Date.now() - 345600000).toISOString(),
      url: "https://www.bloomberg.com/opinion/articles/2023-03-21/you-cant-change-your-mind-about-mergers",
      sentiment: "bearish",
      topics: ["finance", "mergers", "acquisitions"],
      imageUrl: "https://images.unsplash.com/photo-1591696205602-2f950c417cb9?w=800&auto=format&fit=crop"
    },
    {
      id: "matt-levine-6",
      title: "Private Markets Get More Public",
      summary: "Also equity funding costs, buying the dip, Endeavor, litigation funding arbitrage and accountant narcissism.",
      source: "Bloomberg",
      sourceUrl: "https://www.bloomberg.com",
      category: "Money Stuff",
      publishDate: new Date(Date.now() - 432000000).toISOString(),
      url: "https://www.bloomberg.com/opinion/articles/2023-03-20/private-markets-get-more-public",
      sentiment: "neutral",
      topics: ["finance", "markets", "private equity"],
      imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop"
    }
  ],
  "paul-krugman": [
    {
      id: "paul-krugman-1",
      title: "The Economics of Climate Change",
      summary: "How economic policy can help address climate change and promote sustainable growth.",
      source: "The New York Times",
      sourceUrl: "https://www.nytimes.com",
      category: "Opinion",
      publishDate: new Date().toISOString(),
      url: "https://www.nytimes.com/opinion/climate-change-economics.html",
      sentiment: "neutral",
      topics: ["economy", "climate", "policy"],
      imageUrl: "https://images.unsplash.com/photo-1611273426858-450286b36689?w=800&auto=format&fit=crop"
    },
    {
      id: "paul-krugman-2",
      title: "Understanding Inflation in Today's Economy",
      summary: "Analysis of current inflation trends and their implications for monetary policy.",
      source: "The New York Times",
      sourceUrl: "https://www.nytimes.com",
      category: "Opinion",
      publishDate: new Date(Date.now() - 86400000).toISOString(),
      url: "https://www.nytimes.com/opinion/inflation-economy.html",
      sentiment: "bearish",
      topics: ["finance", "inflation", "economy"],
      imageUrl: "https://images.unsplash.com/photo-1604594849809-dfedbc827105?w=800&auto=format&fit=crop"
    }
  ],
  "scott-galloway": [
    {
      id: "scott-galloway-1",
      title: "The Four: The Hidden DNA of Amazon, Apple, Facebook, and Google",
      summary: "Analysis of how the tech giants have reshaped business and society.",
      source: "No Mercy / No Malice",
      sourceUrl: "https://www.profgalloway.com",
      category: "Tech Analysis",
      publishDate: new Date(Date.now() - 172800000).toISOString(),
      url: "https://www.profgalloway.com/the-four",
      sentiment: "neutral",
      topics: ["tech", "business", "amazon", "apple", "facebook", "google"],
      imageUrl: "https://images.unsplash.com/photo-1616469829941-c7200edec809?w=800&auto=format&fit=crop"
    }
  ],
  "emma-smith": [
    {
      id: "emma-smith-1",
      title: "Best Finance Books for Beginners and Experts",
      summary: "A comprehensive guide to the most influential finance books that can transform your understanding of money management and investing.",
      source: "Pan Macmillan",
      sourceUrl: "https://www.panmacmillan.com",
      category: "Book Recommendations",
      publishDate: new Date().toISOString(),
      url: "https://www.panmacmillan.com/blogs/general/best-finance-books",
      sentiment: "neutral",
      topics: ["finance", "books", "investing", "personal finance"],
      imageUrl: "https://images.unsplash.com/photo-1553729784-e91953dec042?w=800&auto=format&fit=crop"
    },
    {
      id: "emma-smith-2",
      title: "How to Build a Financial Reading Habit",
      summary: "Learn how to develop a consistent reading habit focused on financial literacy and wealth building through carefully selected books.",
      source: "Pan Macmillan",
      sourceUrl: "https://www.panmacmillan.com",
      category: "Reading Habits",
      publishDate: new Date(Date.now() - 604800000).toISOString(),
      url: "https://www.panmacmillan.com/blogs/general/financial-reading-habits",
      sentiment: "bullish",
      topics: ["finance", "books", "habits", "self-improvement"],
      imageUrl: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&auto=format&fit=crop"
    },
    {
      id: "emma-smith-3",
      title: "Summer Reading List: Financial Freedom Edition",
      summary: "The perfect summer reading list for anyone looking to improve their financial literacy and work toward financial independence.",
      source: "Pan Macmillan",
      sourceUrl: "https://www.panmacmillan.com",
      category: "Reading Lists",
      publishDate: new Date(Date.now() - 1209600000).toISOString(),
      url: "https://www.panmacmillan.com/blogs/general/summer-financial-reading",
      sentiment: "bullish",
      topics: ["finance", "books", "summer reading", "financial freedom"],
      imageUrl: "https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=800&auto=format&fit=crop"
    }
  ]
};

export const getAuthorArticles = (authorId: string): Article[] => {
  return authorArticles[authorId] || [];
};

export const getAuthor = (authorId: string | undefined): Author | undefined => {
  if (!authorId) return undefined;
  return authors.find(author => author.id === authorId);
};
