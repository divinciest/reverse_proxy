
import { Article, Source } from './types';

export const categories = [
  "Investing",
  "Markets & Economy",
  "Mutual Funds & ETFs",
  "Private Banking & Wealth Management",
  "Geopolitical Risk",
  "Insurance & Real Estate",
  "Commodities",
  "Technology & AI",
  "Fraud & Credit Ratings"
];
