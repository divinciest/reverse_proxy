
import React from "react";
import { cn } from "@/lib/utils";
import SentimentBadge from "@/components/SentimentBadge";
import { getBestFaviconUrl } from "@/utils/favicon";

interface ArticleImageProps {
  imageUrl: string | undefined;
  altText?: string;
  title?: string;
  sentiment?: "bullish" | "neutral" | "bearish";
  imageClassName?: string;
  source?: string; // Source name for fallback
  showSentiment?: boolean;
}

const ArticleImage = ({ 
  imageUrl, 
  altText,
  title, 
  sentiment = "neutral", 
  imageClassName, 
  source,
  showSentiment = true
}: ArticleImageProps) => {
  if (!imageUrl) return null;
  
  return (
    <div className={cn("relative h-36 overflow-hidden bg-gray-100", imageClassName)}>
      <img
        src={imageUrl}
        alt={altText || title || "Article image"}
        className="w-full h-full object-cover"
        loading="lazy"
        onError={(e) => {
          // If image fails to load, try to use the source logo as fallback
          if (source) {
            const target = e.target as HTMLImageElement;
            const fallbackUrl = getBestFaviconUrl(source);
            
            // Log for debugging
            console.log(`Image failed to load for: ${title}. Using source logo: ${source}`);
            
            // Only set if we have a valid fallback URL
            if (fallbackUrl) {
              target.src = fallbackUrl;
              target.className = "w-full h-full object-contain p-4"; // Adjust styling for logo
              target.onerror = null; // Prevent infinite error loop
            } else {
              // If no valid fallback, hide the image element
              target.style.display = "none";
            }
          }
        }}
      />
      {showSentiment && sentiment && (
        <div className="absolute top-2 right-2">
          <SentimentBadge sentiment={sentiment} />
        </div>
      )}
    </div>
  );
};

export default ArticleImage;
