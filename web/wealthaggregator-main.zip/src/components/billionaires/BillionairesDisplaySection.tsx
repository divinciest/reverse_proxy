import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { ExternalLink, TrendingUp, TrendingDown, CircleDollarSign } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import FilterToolbar from "@/components/FilterToolbar";
import SortButtons from "@/components/sp500/SortButtons";
import { Billionaire } from "@/data/billionaire";

interface BillionairesDisplaySectionProps {
  billionaires: Billionaire[];
  companyLogos: Record<string, string>;
}

const BillionairesDisplaySection: React.FC<BillionairesDisplaySectionProps> = ({ 
  billionaires, 
  companyLogos 
}) => {
  // UI state
  const [view, setView] = useState<"grid" | "list">("grid");
  const [dateFilter, setDateFilter] = useState<string>("today");
  const [currentSort, setCurrentSort] = useState<string>("default");

  // Handle refresh
  const handleRefresh = () => {
    console.log("Refreshing billionaire data...");
    // In a real app, this would fetch fresh data
  };

  // Handle sort change
  const handleSort = (sortType: string) => {
    setCurrentSort(sortType);
  };

  // Sort billionaires based on currentSort
  const sortedBillionaires = useMemo(() => {
    if (!billionaires) return [];
    
    const sortedData = [...billionaires];
    
    switch (currentSort) {
      case "az":
        return sortedData.sort((a, b) => a.name.localeCompare(b.name));
      case "za":
        return sortedData.sort((a, b) => b.name.localeCompare(a.name));
      case "percentGain":
        return sortedData.sort((a, b) => b.changePercent - a.changePercent);
      case "percentLoss":
        return sortedData.sort((a, b) => a.changePercent - b.changePercent);
      case "marketCap":
        return sortedData.sort((a, b) => b.netWorth - a.netWorth);
      default:
        return sortedData.sort((a, b) => a.rank - b.rank); // Default sort by rank
    }
  }, [billionaires, currentSort]);

  // Format net worth as currency
  const formatNetWorth = (amount: number): string => {
    return `$${amount.toFixed(1)}B`;
  };

  // Format change as currency with sign
  const formatChange = (amount: number): string => {
    const sign = amount >= 0 ? '+' : '';
    return `${sign}$${amount.toFixed(1)}B`;
  };

  return (
    <Card className="mb-6 mt-4">
      <CardHeader className="pb-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <CardTitle className="text-2xl font-serif">
            World's Billionaires
          </CardTitle>
          
          <FilterToolbar
            dateFilter={dateFilter}
            onDateFilterChange={setDateFilter}
            view={view}
            onViewChange={setView}
            onRefresh={handleRefresh}
            sortProps={{
              onSort: handleSort,
              currentSort: currentSort
            }}
          />
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground mb-6">
          Browse the top {billionaires.length} billionaires ranked by real-time net worth
        </p>
        
        <SortButtons 
          currentSort={currentSort}
          setCurrentSort={handleSort}
          disabled={false}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          {sortedBillionaires.map((billionaire) => (
            <Link key={billionaire.id} to={`/billionaire/${billionaire.id}`} 
              className="group block p-4 bg-white rounded-lg border border-gray-200 hover:border-primary hover:shadow-md transition-all">
              <div className="flex items-center gap-3">
                {billionaire.imageUrl ? (
                  <Avatar className="h-16 w-16">
                    <img 
                      src={billionaire.imageUrl} 
                      alt={billionaire.name} 
                      className="h-full w-full object-cover"
                      loading="eager"
                    />
                  </Avatar>
                ) : (
                  <Avatar className="h-16 w-16">
                    <CircleDollarSign className="h-8 w-8 text-muted-foreground" />
                  </Avatar>
                )}
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-lg group-hover:text-primary flex items-center gap-1">
                    {billionaire.name}
                    <ExternalLink className="h-3.5 w-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="text-sm text-muted-foreground flex items-center gap-2">
                    <span>Rank #{billionaire.rank}</span>
                    <span className="text-xs">•</span>
                    <span>{billionaire.mainCompany}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">{billionaire.source}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-lg">{formatNetWorth(billionaire.netWorth)}</div>
                  <div className={`flex items-center justify-end text-sm ${billionaire.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {billionaire.change >= 0 ? (
                      <TrendingUp size={14} className="mr-1" />
                    ) : (
                      <TrendingDown size={14} className="mr-1" />
                    )}
                    <span>
                      {formatChange(billionaire.change)} ({billionaire.changePercent.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              </div>
              
              {/* Company logos */}
              <div className="mt-4 pt-3 border-t flex gap-2 overflow-x-auto">
                {billionaire.companies.slice(0, 3).map((company, idx) => (
                  <div key={company} className="flex items-center gap-1 bg-gray-50 px-2 py-1 rounded text-xs whitespace-nowrap">
                    {companyLogos[billionaire.id] && (
                      <img 
                        src={companyLogos[billionaire.id]} 
                        alt={company}
                        className="h-3 w-3"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                        }}
                      />
                    )}
                    <span>{company}</span>
                  </div>
                ))}
                {billionaire.companies.length > 3 && (
                  <div className="flex items-center bg-gray-50 px-2 py-1 rounded text-xs">
                    +{billionaire.companies.length - 3}
                  </div>
                )}
              </div>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default BillionairesDisplaySection;
