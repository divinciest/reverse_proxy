
import React from "react";
import { Link } from "react-router-dom";
import { ChevronRight, CircleDollarSign } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const BillionairesPageHeader = () => {
  return (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-3xl font-serif flex items-center">
              <CircleDollarSign className="mr-2 h-7 w-7" />
              Forbes Real-Time Billionaires
            </CardTitle>
            <CardDescription className="text-base mt-2">
              Tracking the world's wealthiest individuals and their daily net worth changes
            </CardDescription>
          </div>
          <div className="hidden md:flex gap-2">
            <Button variant="outline" asChild>
              <Link to="/stocks">View Stocks</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/markets">Global Markets</Link>
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-6 text-sm text-muted-foreground">
          <div>
            <span className="font-medium text-primary">Total Billionaires:</span> 2,781
          </div>
          <div>
            <span className="font-medium text-primary">Total Net Worth:</span> $14.2 Trillion
          </div>
          <div>
            <span className="font-medium text-primary">Last Updated:</span> {new Date().toLocaleString()}
          </div>
        </div>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
            <h3 className="font-medium text-blue-700 mb-1">What are the Forbes Real-Time Billionaires Rankings?</h3>
            <p className="text-sm text-blue-600">
              The Forbes Real-Time Billionaires rankings track the daily ups and downs of the world's richest people. The wealth-tracking platform provides ongoing updates on the net worth and ranking of each individual confirmed by Forbes to be a billionaire.
            </p>
          </div>
          <div className="bg-amber-50 p-4 rounded-lg border border-amber-100">
            <h3 className="font-medium text-amber-700 mb-1">Methodology</h3>
            <p className="text-sm text-amber-600">
              The value of public holdings is updated every 5 minutes when respective markets are open. Individuals whose fortunes are significantly tied to private companies have their net worths updated once per day.
            </p>
            <Link to="#" className="text-xs flex items-center text-amber-700 font-medium mt-2 hover:underline">
              Learn more about our methodology <ChevronRight className="h-3 w-3" />
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BillionairesPageHeader;
