
import React from "react";
import { Link } from "react-router-dom";

const BillionairesFooter = () => {
  return (
    <footer className="bg-gray-100 border-t border-gray-200 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-semibold text-lg mb-3">About Forbes Billionaires</h3>
            <p className="text-sm text-gray-600">
              Forbes tracks the wealth of the world's richest people as part of its coverage of billionaires and business leaders. The data is updated regularly to reflect public stock prices and information about private assets.
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-3">Related Pages</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/stocks" className="text-gray-600 hover:text-primary">Stocks</Link>
              </li>
              <li>
                <Link to="/expert/warren-buffett" className="text-gray-600 hover:text-primary">Warren Buffett Profile</Link>
              </li>
              <li>
                <Link to="/markets" className="text-gray-600 hover:text-primary">Global Markets</Link>
              </li>
              <li>
                <Link to="/sp500" className="text-gray-600 hover:text-primary">S&P 500 Companies</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-3">Disclaimer</h3>
            <p className="text-sm text-gray-600">
              The data presented is for informational purposes only. All figures are approximations based on publicly available information. Net worth values fluctuate with market changes.
            </p>
            <p className="text-sm text-gray-600 mt-2">
              © {new Date().getFullYear()} WealthManager. Data sourced from Forbes and public records.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default BillionairesFooter;
