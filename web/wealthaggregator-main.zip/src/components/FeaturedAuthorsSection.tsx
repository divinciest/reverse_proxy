
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import ArticleCard from "@/components/ArticleCard";
import { authorArticles, authors } from "@/data/authors";
import { Article } from "@/data/types";

const FeaturedAuthorsSection = () => {
  // Get Matt Levine's articles
  const mattLevineArticles = authorArticles["matt-levine"] || [];
  const mattLevine = authors.find(a => a.id === "matt-levine");
  
  // Show only the first 3 articles
  const displayedArticles = mattLevineArticles.slice(0, 3);

  if (!mattLevine || displayedArticles.length === 0) {
    return null;
  }

  // Helper function to adapt article data for ArticleCard
  const adaptArticleForCard = (article: any): Article => {
    return {
      id: article.id || "",
      title: article.title || "",
      summary: article.summary || "",
      source: article.source || "",
      sourceUrl: article.sourceUrl || article.url || "#",
      category: article.category || article.source || "",
      sentiment: article.sentiment || "neutral",
      date: article.publishDate || article.date || new Date().toISOString(),
      tags: article.topics || article.tags || [],
      url: article.url || article.sourceUrl || "#",
      imageUrl: article.imageUrl
    };
  };

  return (
    <div className="py-8 border-t border-gray-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
          <h2 className="text-2xl font-serif font-bold">Featured Author: {mattLevine.name}</h2>
          <p className="text-muted-foreground">{mattLevine.title} at {mattLevine.publication}</p>
        </div>
        <Link to={`/author/${mattLevine.id}`} className="mt-2 sm:mt-0">
          <Button variant="outline">View Profile</Button>
        </Link>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {displayedArticles.map((article) => (
          <Link to={`/article/${article.id}`} key={article.id}>
            <ArticleCard 
              key={article.id}
              article={adaptArticleForCard(article)}
              className="h-full border border-gray-200"
              onClick={() => {}}
            />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default FeaturedAuthorsSection;
