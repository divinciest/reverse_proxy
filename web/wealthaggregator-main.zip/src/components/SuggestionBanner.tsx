
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface SuggestionBannerProps {
  title: string;
  description: string;
  buttonText: string;
  buttonLink: string;
  className?: string;
}

const SuggestionBanner = ({
  title,
  description,
  buttonText,
  buttonLink,
  className,
}: SuggestionBannerProps) => {
  return (
    <Card className={cn("bg-blue-50 border-blue-200", className)}>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold text-blue-900 mb-1">{title}</h3>
            <p className="text-blue-700 text-sm">{description}</p>
          </div>
          <Button asChild>
            <Link to={buttonLink}>
              {buttonText}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default SuggestionBanner;
