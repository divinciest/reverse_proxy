
import React from "react";
import { 
  LineChart, 
  Line, 
  ResponsiveContainer, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ReferenceLine 
} from "recharts";
import { 
  ChartContainer, 
  ChartTooltip,
  ChartTooltipContent
} from "./ui/chart";

interface StockChartProps {
  data: Array<{time: string; price: number}>;
  width?: number;
  height?: number;
  showTooltip?: boolean;
  showAxis?: boolean;
  className?: string;
}

// Generate mock data for the chart
const generateMockDailyData = (basePrice: number, dataPoints: number = 60) => {
  const data = [];
  let currentPrice = basePrice;
  const startTime = new Date();
  startTime.setHours(16, 0, 0, 0); // Market opens at 9:30 AM

  for (let i = 0; i < dataPoints; i++) {
    // Add some randomness to the price
    const change = (Math.random() - 0.5) * 0.5;
    currentPrice = Number((currentPrice + change).toFixed(2));
    
    // Calculate time for this data point
    const pointTime = new Date(startTime);
    pointTime.setMinutes(startTime.getMinutes() + i * 1);
    
    const timeStr = pointTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    
    data.push({
      time: timeStr,
      price: currentPrice
    });
  }
  return data;
};

const StockChart = ({ 
  data: propData, 
  width = 300, 
  height = 100, 
  showTooltip = false,
  showAxis = false,
  className = ""
}: StockChartProps) => {
  // Use provided data or generate mock data if not provided or empty
  const chartData = propData?.length ? propData : generateMockDailyData(260.02);
  
  // Make sure we have data before trying to access it
  if (!chartData || chartData.length === 0) {
    return (
      <div className={`${className} flex items-center justify-center`} style={{ width, height }}>
        <p className="text-muted-foreground">No data available</p>
      </div>
    );
  }
  
  // Find min and max for domain
  const prices = chartData.map(item => item.price);
  const minPrice = Math.floor(Math.min(...prices) * 10) / 10 - 0.5;
  const maxPrice = Math.ceil(Math.max(...prices) * 10) / 10 + 0.5;
  
  const startPrice = chartData[0].price;
  const currentPrice = chartData[chartData.length - 1].price;
  const isPositive = currentPrice >= startPrice;
  
  return (
    <div className={`${className}`} style={{ width, height }}>
      <ChartContainer
        config={{
          price: {
            theme: {
              light: isPositive ? "#22c55e" : "#ef4444",
              dark: isPositive ? "#22c55e" : "#ef4444"
            }
          }
        }}
      >
        <LineChart data={chartData}>
          {showAxis && (
            <>
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 10 }} 
                interval="preserveStartEnd" 
                minTickGap={50}
              />
              <YAxis 
                domain={[minPrice, maxPrice]} 
                tick={{ fontSize: 10 }} 
                tickFormatter={(value) => `$${value}`}
              />
            </>
          )}
          
          <Line 
            type="monotone" 
            dataKey="price" 
            dot={false}
            activeDot={{ r: 4 }}
            strokeWidth={2}
            stroke="var(--color-price)"
          />
          
          <ReferenceLine 
            y={startPrice} 
            stroke="#888" 
            strokeDasharray="3 3" 
          />
          
          {showTooltip && (
            <ChartTooltip
              content={({ active, payload }) => {
                if (active && payload?.length) {
                  return (
                    <div className="bg-background border p-2 rounded text-xs">
                      <p>${payload[0].value}</p>
                      <p>{payload[0].payload.time}</p>
                    </div>
                  );
                }
                return null;
              }}
            />
          )}
        </LineChart>
      </ChartContainer>
    </div>
  );
};

export default StockChart;
