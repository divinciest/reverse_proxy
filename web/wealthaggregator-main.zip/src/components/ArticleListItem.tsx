
import React from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import SourceLabel from "@/components/SourceLabel";
import TopicBadge from "@/components/TopicBadge";
import DateHeader from "@/components/DateHeader";
import { Article } from "@/data/types";
import ArticleImage from "@/components/ArticleImage";

interface ArticleListItemProps {
  article: Article;
  onTopicClick?: (topic: string) => void;
  openInNewTab?: boolean;
  className?: string;
  onClick?: () => void;
}

const ArticleListItem = ({ 
  article, 
  onTopicClick,
  openInNewTab = false,
  className = "",
  onClick
}: ArticleListItemProps) => {
  // Prepare target and rel attributes for links
  const linkProps = openInNewTab 
    ? { target: "_blank", rel: "noopener noreferrer" } 
    : {};
  
  const handleItemClick = () => {
    if (onClick) {
      onClick();
    }
  };
  
  const imageUrl = article.imageUrl || "/placeholder.svg";
  
  // IMPORTANT: Do not modify the tag handling logic below, as it's critical for proper tag display
  // This ensures we always have tags to display by using a fallback priority system
  const displayTags = article.tags || article.topics || [];
  
  return (
    <Card 
      className={`hover:shadow-md transition-shadow ${className}`}
      onClick={handleItemClick}
    >
      <CardContent className="p-4">
        <div className="flex flex-col">
          <div className="mb-1">
            <SourceLabel 
              source={article.source} 
              sourceUrl={article.sourceUrl} 
            />
          </div>
          
          <Link 
            to={article.url || "#"} 
            className="group mb-2"
            {...linkProps}
            onClick={(e) => onClick && e.preventDefault()}
          >
            <h3 className="text-lg font-bold font-serif mb-2 group-hover:text-blue-700 transition-colors">
              {article.title}
            </h3>
          </Link>
          
          {article.imageUrl && (
            <div className="mb-3 h-40 w-full">
              <ArticleImage 
                imageUrl={imageUrl} 
                title={article.title}
                altText={article.title}
                sentiment={article.sentiment || "neutral"} 
                imageClassName="object-cover w-full h-full rounded" 
                source={article.source}
                showSentiment={true} // Show sentiment badge in the image
              />
            </div>
          )}
          
          <div className="text-gray-700 text-sm mb-3 line-clamp-2">
            {article.summary}
          </div>
          
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap gap-2">
              {displayTags.length > 0 ? (
                displayTags.map((tag, index) => (
                  <TopicBadge 
                    key={`${tag}-${index}`}
                    topic={tag} 
                    size="sm"
                    onClick={onTopicClick ? () => onTopicClick(tag) : undefined}
                  />
                ))
              ) : (
                <TopicBadge 
                  topic="Uncategorized" 
                  variant="default"
                  size="sm"
                />
              )}
            </div>
            
            <div className="flex items-center text-xs text-gray-500">
              <DateHeader date={article.date} hoursAgo={article.hoursAgo} size="sm" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ArticleListItem;
