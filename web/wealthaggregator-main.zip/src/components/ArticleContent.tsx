
import React from "react";
import { cn } from "@/lib/utils";
import SentimentBadge from "@/components/SentimentBadge";
import SourceLabel from "@/components/SourceLabel";

interface ArticleContentProps {
  title: string;
  summary: string;
  imageUrl: string | undefined;
  sentiment: "bullish" | "neutral" | "bearish";
  source: string;
  category: string;
  publishDate: string;
  sourceCount?: number;
  contentClassName?: string;
}

const ArticleContent = ({ 
  title, 
  summary, 
  imageUrl, 
  sentiment, 
  source, 
  category, 
  publishDate,
  sourceCount,
  contentClassName 
}: ArticleContentProps) => {
  const formattedDate = new Date(publishDate).toLocaleDateString(
    "en-US",
    {
      month: "short",
      day: "numeric",
      year: "numeric",
    }
  );

  return (
    <div className={cn(`p-4 ${imageUrl ? "pt-3" : "pt-4"}`, contentClassName)}>
      {!imageUrl && (
        <div className="mb-2">
          <SentimentBadge sentiment={sentiment} />
        </div>
      )}
      <h3 className="text-lg font-serif font-bold mb-1 leading-tight">{title}</h3>
      <p className="text-muted-foreground text-sm mb-2 line-clamp-3 font-serif leading-snug">
        {summary}
      </p>
      <div className="text-xs text-muted-foreground italic font-serif mb-1">
        {formattedDate}
        {sourceCount && (
          <span className="ml-2">· {sourceCount} sources</span>
        )}
      </div>
      <SourceLabel source={source} category={category} className="text-xs" />
    </div>
  );
};

export default ArticleContent;
