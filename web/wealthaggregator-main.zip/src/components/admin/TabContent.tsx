
import React from "react";

interface TabContentProps {
  title: string;
  description: string;
  children: React.ReactNode;
  icon?: React.ReactNode;
}

const TabContent = ({ title, description, children, icon }: TabContentProps) => {
  return (
    <div className="space-y-6">
      <div className="border-b pb-4 mb-4">
        <div className="flex items-center gap-3 mb-2">
          {icon}
          <h2 className="text-2xl font-serif font-bold">{title}</h2>
        </div>
        <p className="text-muted-foreground">{description}</p>
      </div>
      <div className="space-y-6">
        {children}
      </div>
    </div>
  );
};

export default TabContent;
