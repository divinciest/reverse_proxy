
import React from "react";
import { Tag } from "@/types/admin";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trash2, Edit } from "lucide-react";

interface TagListViewProps {
  tags: Tag[];
  onDelete: (id: string) => void;
  onEdit: (tag: Tag) => void;
}

const TagListView = ({ tags, onDelete, onEdit }: TagListViewProps) => {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Tag Name</TableHead>
          <TableHead>Aliases</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {tags.map((tag) => (
          <TableRow key={tag._id}>
            <TableCell>
              <span className="font-medium">{tag.tagName}</span>
            </TableCell>
            <TableCell>
              <div className="flex flex-wrap gap-1 max-w-md">
                {tag.aliases.map((alias, index) => (
                  <Badge key={`${tag._id}-alias-${index}`} variant="outline" className="bg-gray-100">
                    {alias}
                  </Badge>
                ))}
                {tag.aliases.length === 0 && (
                  <span className="text-xs text-gray-400 italic">No aliases</span>
                )}
              </div>
            </TableCell>
            <TableCell className="text-right">
              <div className="flex justify-end space-x-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                  onClick={() => onEdit(tag)}
                >
                  <Edit size={14} className="mr-1" /> Edit
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  onClick={() => onDelete(tag._id)}
                >
                  <Trash2 size={14} className="mr-1" /> Delete
                </Button>
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default TagListView;
