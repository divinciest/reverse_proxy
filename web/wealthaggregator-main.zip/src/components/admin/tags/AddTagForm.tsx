
import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, X } from "lucide-react";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const formSchema = z.object({
  tagName: z.string().min(1, "Tag name is required"),
  newAlias: z.string().optional()
});

type FormValues = z.infer<typeof formSchema>;

interface AddTagFormProps {
  onAddTag: (tagName: string, aliases: string[]) => void;
  icon?: React.ReactNode;
}

const AddTagForm = ({ onAddTag, icon }: AddTagFormProps) => {
  const [aliases, setAliases] = React.useState<string[]>([]);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      tagName: "",
      newAlias: ""
    }
  });

  const handleAddAlias = () => {
    const newAlias = form.getValues("newAlias")?.trim();
    if (newAlias && !aliases.includes(newAlias)) {
      setAliases([...aliases, newAlias]);
      form.setValue("newAlias", "");
    }
  };

  const handleRemoveAlias = (alias: string) => {
    setAliases(aliases.filter(a => a !== alias));
  };

  const onSubmit = (data: FormValues) => {
    onAddTag(data.tagName, aliases);
    form.reset();
    setAliases([]);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddAlias();
    }
  };

  return (
    <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        {icon}
        Add New Tag
      </h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="tagName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tag Name</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="e.g., technology" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="space-y-2">
            <Label htmlFor="alias">Aliases (Keywords for detection)</Label>
            <div className="flex gap-2">
              <Input 
                id="alias" 
                {...form.register("newAlias")}
                placeholder="Add alias" 
                onKeyDown={handleKeyDown}
              />
              <Button 
                type="button"
                onClick={handleAddAlias}
                className="shrink-0"
              >
                <Plus size={16} className="mr-1" /> Add
              </Button>
            </div>
            
            {aliases.length > 0 && (
              <div className="mt-2">
                <p className="text-sm text-gray-500 mb-1">Added aliases:</p>
                <div className="flex flex-wrap gap-2">
                  {aliases.map((alias, index) => (
                    <div key={index} className="flex items-center bg-gray-100 rounded-full px-3 py-1 text-sm">
                      {alias}
                      <button 
                        type="button"
                        onClick={() => handleRemoveAlias(alias)} 
                        className="ml-1 text-gray-400 hover:text-red-500"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          <Button type="submit" className="w-full md:w-auto">
            <Plus size={16} className="mr-1" /> Add Tag
          </Button>
        </form>
      </Form>
    </div>
  );
};

export default AddTagForm;
