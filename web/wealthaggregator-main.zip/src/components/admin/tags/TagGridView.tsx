
import React from "react";
import { Tag } from "@/types/admin";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Edit } from "lucide-react";

interface TagGridViewProps {
  tags: Tag[];
  onDelete: (id: string) => void;
  onEdit: (tag: Tag) => void;
}

const TagGridView = ({ tags, onDelete, onEdit }: TagGridViewProps) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {tags.map((tag) => (
        <Card key={tag._id} className="overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <div className="bg-amber-100 text-amber-800 rounded-full h-10 w-10 flex items-center justify-center font-medium">
                  {tag.tagName.substring(0, 2)}
                </div>
                <div>
                  <p className="font-medium">{tag.tagName}</p>
                  <p className="text-xs text-gray-500">{tag.aliases.length} aliases</p>
                </div>
              </div>
              <div className="flex space-x-1">
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="h-8 w-8 text-blue-500 hover:text-blue-700 hover:bg-blue-50 p-0"
                  onClick={() => onEdit(tag)}
                >
                  <Edit size={14} />
                </Button>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50 p-0"
                  onClick={() => onDelete(tag._id)}
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
            <div className="mt-2">
              <p className="text-xs font-medium text-gray-500 mb-1">Aliases:</p>
              <div className="flex flex-wrap gap-1">
                {tag.aliases.map((alias, index) => (
                  <span key={`${tag._id}-alias-${index}`} className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">
                    {alias}
                  </span>
                ))}
                {tag.aliases.length === 0 && (
                  <span className="text-xs text-gray-400 italic">No aliases</span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default TagGridView;
