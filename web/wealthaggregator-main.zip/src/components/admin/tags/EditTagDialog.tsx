
import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tag } from "@/types/admin";
import { Plus, X } from "lucide-react";

interface EditTagDialogProps {
  isOpen: boolean;
  onClose: () => void;
  tag: Tag | null;
  onSave: (tagId: string, tagName: string, aliases: string[]) => void;
}

const EditTagDialog = ({ isOpen, onClose, tag, onSave }: EditTagDialogProps) => {
  const [tagName, setTagName] = React.useState("");
  const [aliases, setAliases] = React.useState<string[]>([]);
  const [newAlias, setNewAlias] = React.useState("");

  React.useEffect(() => {
    if (tag) {
      setTagName(tag.tagName);
      setAliases([...tag.aliases]);
    }
  }, [tag]);

  const handleAddAlias = () => {
    if (newAlias.trim() && !aliases.includes(newAlias.trim())) {
      setAliases([...aliases, newAlias.trim()]);
      setNewAlias("");
    }
  };

  const handleRemoveAlias = (alias: string) => {
    setAliases(aliases.filter(a => a !== alias));
  };

  const handleSave = () => {
    if (tag && tagName.trim()) {
      onSave(tag._id, tagName.trim(), aliases);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddAlias();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Tag</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="edit-tag-name">Tag Name</Label>
            <Input
              id="edit-tag-name"
              value={tagName}
              onChange={(e) => setTagName(e.target.value)}
              placeholder="Tag name"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="edit-alias">Aliases (Keywords for detection)</Label>
            <div className="flex gap-2">
              <Input 
                id="edit-alias" 
                value={newAlias}
                onChange={(e) => setNewAlias(e.target.value)}
                placeholder="Add alias" 
                onKeyDown={handleKeyDown}
              />
              <Button 
                type="button"
                onClick={handleAddAlias}
                className="shrink-0"
              >
                <Plus size={16} /> Add
              </Button>
            </div>
            
            {aliases.length > 0 && (
              <div className="mt-2">
                <p className="text-sm text-gray-500 mb-1">Aliases:</p>
                <div className="flex flex-wrap gap-2">
                  {aliases.map((alias, index) => (
                    <div key={index} className="flex items-center bg-gray-100 rounded-full px-3 py-1 text-sm">
                      {alias}
                      <button 
                        type="button"
                        onClick={() => handleRemoveAlias(alias)} 
                        className="ml-1 text-gray-400 hover:text-red-500"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        <DialogFooter className="sm:justify-end">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="button" onClick={handleSave}>
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EditTagDialog;
