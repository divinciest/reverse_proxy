
import React, { useState } from "react";
import { toast } from "sonner";
import { User, Plus, Rss } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Author } from "@/data/authors";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface NewAuthorFormManagerProps {
  onAddAuthor: (author: Omit<Author, "id">) => void;
}

const NewAuthorFormManager: React.FC<NewAuthorFormManagerProps> = ({ onAddAuthor }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState("");
  const [publication, setPublication] = useState("");
  const [title, setTitle] = useState("");
  const [bio, setBio] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [twitterHandle, setTwitterHandle] = useState("");
  const [rssUrl, setRssUrl] = useState("");
  const [articleCount, setArticleCount] = useState(0);

  const handleAddAuthor = () => {
    if (!name) {
      toast.error("Author name is required");
      return;
    }

    if (!publication) {
      toast.error("Publication is required");
      return;
    }

    if (!title) {
      toast.error("Title is required");
      return;
    }

    if (!bio) {
      toast.error("Bio is required");
      return;
    }

    onAddAuthor({
      name,
      publication,
      title,
      bio,
      imageUrl,
      twitterHandle,
      rssUrl
    });

    // Reset form
    setName("");
    setPublication("");
    setTitle("");
    setBio("");
    setImageUrl("");
    setTwitterHandle("");
    setRssUrl("");
    setArticleCount(0);
    setIsOpen(false);
  };

  return (
    <Card className="border shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center">
          <Rss className="h-5 w-5 mr-2 text-primary" />
          Add New Author
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name*</Label>
            <Input 
              id="name" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. John Doe"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="publication">Publication*</Label>
            <Input 
              id="publication" 
              value={publication}
              onChange={(e) => setPublication(e.target.value)}
              placeholder="e.g. The New York Times"
              required
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title*</Label>
            <Input 
              id="title" 
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Opinion Columnist"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="imageUrl">Profile Image URL (optional)</Label>
            <Input 
              id="imageUrl" 
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="e.g. https://example.com/image.jpg"
            />
          </div>
        </div>
        
        <div className="space-y-2 mb-4">
          <Label htmlFor="bio">Biography*</Label>
          <textarea
            id="bio"
            className="min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder="Brief biography of the author..."
            required
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="space-y-2">
            <Label htmlFor="twitterHandle">Twitter Handle (optional)</Label>
            <div className="flex">
              <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-input bg-muted text-muted-foreground text-sm">
                @
              </span>
              <Input 
                id="twitterHandle" 
                value={twitterHandle}
                onChange={(e) => setTwitterHandle(e.target.value)}
                placeholder="johndoe"
                className="rounded-l-none"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="rssUrl">RSS Feed URL (optional)</Label>
            <Input 
              id="rssUrl" 
              value={rssUrl}
              onChange={(e) => setRssUrl(e.target.value)}
              placeholder="e.g. https://example.com/feed.rss"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="space-y-2">
            <Label htmlFor="initialCount">Initial Article Count</Label>
            <Input
              id="initialCount"
              type="number"
              min="0"
              value={articleCount}
              onChange={(e) => setArticleCount(parseInt(e.target.value) || 0)}
            />
          </div>
        </div>
        
        <Button onClick={handleAddAuthor} className="mt-2">
          Add Author
        </Button>
      </CardContent>
    </Card>
  );
};

export default NewAuthorFormManager;
