
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Author } from "@/data/authors";
import { User, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";

interface EditAuthorFormProps {
  author: Author;
  onUpdate: (author: Author) => void;
  onCancel: () => void;
  isProcessing: boolean;
}

const EditAuthorForm: React.FC<EditAuthorFormProps> = ({ 
  author, 
  onUpdate,
  onCancel,
  isProcessing
}) => {
  const [name, setName] = useState(author.name);
  const [publication, setPublication] = useState(author.publication);
  const [title, setTitle] = useState(author.title);
  const [bio, setBio] = useState(author.bio);
  const [imageUrl, setImageUrl] = useState(author.imageUrl || "");
  const [twitterHandle, setTwitterHandle] = useState(author.twitterHandle || "");
  const [rssUrl, setRssUrl] = useState(author.rssUrl || "");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate({
      ...author,
      name,
      publication,
      title,
      bio,
      imageUrl: imageUrl || undefined,
      twitterHandle: twitterHandle || undefined,
      rssUrl: rssUrl || undefined
    });
  };

  return (
    <Card className="mb-6 border border-primary/20 shadow-md">
      <CardHeader className="bg-primary/5">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="h-5 w-5 text-primary" />
            <span>Edit Author: {author.name}</span>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onCancel}
            className="h-8 w-8 p-0 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Author Name*</Label>
                <Input 
                  id="name" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="imageUrl">Profile Image URL</Label>
                <Input 
                  id="imageUrl" 
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="publication">Publication*</Label>
                <Input 
                  id="publication" 
                  value={publication}
                  onChange={(e) => setPublication(e.target.value)}
                  placeholder="The New York Times"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="title">Title*</Label>
                <Input 
                  id="title" 
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Opinion Columnist"
                  required
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="bio">Biography*</Label>
              <textarea
                id="bio"
                className="min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Brief biography of the author..."
                required
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="twitterHandle">Twitter Handle</Label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-input bg-muted text-muted-foreground text-sm">
                    @
                  </span>
                  <Input 
                    id="twitterHandle" 
                    value={twitterHandle}
                    onChange={(e) => setTwitterHandle(e.target.value)}
                    placeholder="johndoe"
                    className="rounded-l-none"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="rssUrl">RSS Feed URL</Label>
                <Input 
                  id="rssUrl" 
                  value={rssUrl}
                  onChange={(e) => setRssUrl(e.target.value)}
                  placeholder="https://example.com/feed.rss"
                />
              </div>
            </div>
          </div>
        
          <div className="mt-4 flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={isProcessing}
            >
              {isProcessing ? "Updating..." : "Update Author"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default EditAuthorForm;
