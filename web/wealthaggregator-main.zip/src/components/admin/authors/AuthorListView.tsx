
import React from "react";
import { Author } from "@/data/authors";
import { Trash2, Rss, Edit, User, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

interface AuthorListViewProps {
  authors: Author[];
  onDeleteAuthor: (id: string) => void;
  onEditAuthor: (id: string) => void;
  getAuthorArticleCount: (id: string) => number;
}

const AuthorListView = ({ authors, onDeleteAuthor, onEditAuthor, getAuthorArticleCount }: AuthorListViewProps) => {
  if (authors.length === 0) {
    return (
      <div className="text-center py-8 bg-gray-50 rounded-lg border border-dashed border-gray-300">
        <p className="text-muted-foreground">No authors found</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <table className="w-full">
        <thead className="bg-gray-50 text-xs font-medium uppercase text-gray-500">
          <tr>
            <th className="px-6 py-3 text-left">Author</th>
            <th className="px-6 py-3 text-left">Publication</th>
            <th className="px-6 py-3 text-left">Title</th>
            <th className="px-6 py-3 text-left">RSS Feed</th>
            <th className="px-6 py-3 text-center">Articles</th>
            <th className="px-6 py-3 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {authors.map((author) => (
            <tr key={author.id} className="hover:bg-gray-50">
              <td className="px-6 py-4">
                <div className="flex items-center space-x-3">
                  {author.imageUrl ? (
                    <div className="h-8 w-8 rounded-full overflow-hidden">
                      <img 
                        src={author.imageUrl} 
                        alt={author.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                      <User className="h-4 w-4 text-gray-500" />
                    </div>
                  )}
                  <div>
                    <div className="font-medium">
                      <Link 
                        to={`/author/${author.id}`}
                        className="hover:text-primary hover:underline inline-flex items-center gap-1"
                      >
                        {author.name}
                        <ExternalLink className="h-3 w-3" />
                      </Link>
                    </div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">{author.publication}</td>
              <td className="px-6 py-4">{author.title}</td>
              <td className="px-6 py-4">
                {author.rssUrl ? (
                  <a 
                    href={author.rssUrl}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-primary hover:underline"
                  >
                    <Rss className="h-3.5 w-3.5 mr-1" />
                    RSS Feed
                  </a>
                ) : (
                  <span className="text-muted-foreground text-sm">No RSS feed</span>
                )}
              </td>
              <td className="px-6 py-4 text-center">
                <span className="text-sm font-medium bg-primary/10 text-primary px-2 py-1 rounded-full">
                  {getAuthorArticleCount(author.id)}
                </span>
              </td>
              <td className="px-6 py-4 text-right">
                <div className="flex justify-end space-x-2">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => onEditAuthor(author.id)}
                    className="text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => onDeleteAuthor(author.id)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AuthorListView;
