
import React from "react";
import { Author } from "@/data/authors";
import { Trash2, Rss, Edit, User, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Link } from "react-router-dom";

interface AuthorGridViewProps {
  authors: Author[];
  onDeleteAuthor: (id: string) => void;
  onEditAuthor: (id: string) => void;
  getAuthorArticleCount: (id: string) => number;
}

const AuthorGridView = ({ authors, onDeleteAuthor, onEditAuthor, getAuthorArticleCount }: AuthorGridViewProps) => {
  if (authors.length === 0) {
    return (
      <div className="text-center py-8 bg-gray-50 rounded-lg border border-dashed border-gray-300">
        <p className="text-muted-foreground">No authors found</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {authors.map((author) => (
        <Card key={author.id} className="overflow-hidden">
          <CardContent className="p-0">
            <div className="p-4">
              <div className="flex items-center space-x-3 mb-2">
                {author.imageUrl ? (
                  <div className="h-12 w-12 rounded-full overflow-hidden">
                    <img 
                      src={author.imageUrl} 
                      alt={author.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="h-12 w-12 rounded-full bg-gray-100 flex items-center justify-center">
                    <User className="h-6 w-6 text-gray-400" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">
                    <Link 
                      to={`/author/${author.id}`}
                      className="hover:text-primary hover:underline inline-flex items-center gap-1"
                    >
                      {author.name}
                      <ExternalLink className="h-3 w-3 flex-shrink-0" />
                    </Link>
                  </div>
                  <div className="text-sm text-muted-foreground truncate">
                    {author.publication} • {author.title}
                  </div>
                </div>
                <div className="bg-primary/10 text-primary px-2 py-1 rounded-full text-sm font-medium flex-shrink-0">
                  {getAuthorArticleCount(author.id)} articles
                </div>
              </div>
              
              <div className="mt-2 text-sm line-clamp-3">
                {author.bio}
              </div>
              
              {author.rssUrl && (
                <div className="mt-2">
                  <a 
                    href={author.rssUrl}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-xs text-primary hover:underline"
                  >
                    <Rss className="h-3 w-3 mr-1" />
                    <span className="truncate">{author.rssUrl}</span>
                  </a>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between items-center bg-gray-50 px-4 py-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => onEditAuthor(author.id)}
              className="text-blue-500 hover:text-blue-700 hover:bg-blue-50"
            >
              <Edit className="h-4 w-4 mr-1" />
              Edit
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => onDeleteAuthor(author.id)}
              className="text-red-500 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Delete
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
};

export default AuthorGridView;
