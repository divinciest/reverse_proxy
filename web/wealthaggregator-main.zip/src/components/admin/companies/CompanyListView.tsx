
import React from "react";
import { CompanySource } from "@/types/admin";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trash2, FileImage } from "lucide-react";
import { Link } from "react-router-dom";
import { getBestFaviconUrl } from "@/utils/favicon";

interface CompanyListViewProps {
  companies: CompanySource[];
  onDelete: (id: string) => void;
  onAddLogo: (id: string) => void;
}

const CompanyListView = ({ companies, onDelete, onAddLogo }: CompanyListViewProps) => {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Company</TableHead>
          <TableHead>Articles</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {companies.map((company) => (
          <TableRow key={company.id}>
            <TableCell>
              <Link to={company.id === "all" ? "/" : `/company/${company.id}`} className="flex items-center gap-3">
                <Avatar className="w-8 h-8">
                  {company.logo ? (
                    <AvatarImage 
                      src={company.logo} 
                      alt={company.name}
                      onError={(e) => {
                        console.log(`Company logo error in list view for ${company.name}:`, company.logo);
                        // If logo fails to load, try to use favicon service
                        const target = e.target as HTMLImageElement;
                        if (!target.src.includes('generateCompanyLogo')) {
                          // Try to get a better logo based on company name
                          let domain = "";
                          const nameLower = company.name.toLowerCase();
                          
                          if (nameLower.includes("apple")) domain = "apple.com";
                          else if (nameLower.includes("tesla")) domain = "tesla.com";
                          else if (nameLower.includes("general electric") || nameLower.includes("ge")) domain = "ge.com";
                          else if (nameLower.includes("intel")) domain = "intel.com";
                          else if (nameLower.includes("twitter") || nameLower === "x") domain = "twitter.com";
                          else if (nameLower.includes("microsoft")) domain = "microsoft.com";
                          else if (nameLower.includes("amazon")) domain = "amazon.com";
                          else if (nameLower.includes("facebook") || nameLower.includes("meta")) domain = "facebook.com";
                          else if (nameLower === "all") domain = ""; // Special case
                          
                          target.src = getBestFaviconUrl(company.name, domain);
                        }
                      }}
                    />
                  ) : (
                    <AvatarFallback className="bg-gray-100 text-gray-800 font-bold text-xs">
                      {company.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  )}
                </Avatar>
                <span className="font-medium">{company.name}</span>
              </Link>
            </TableCell>
            <TableCell>
              <Badge>{company.count}</Badge>
            </TableCell>
            <TableCell className="text-right">
              <div className="flex items-center justify-end gap-2">
                {!company.logo && company.id !== "all" && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-purple-500 hover:text-purple-700 hover:bg-purple-50"
                    title="Generate logo"
                    onClick={() => onAddLogo(company.id)}
                  >
                    <FileImage size={14} className="mr-1" /> Generate Logo
                  </Button>
                )}
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  onClick={() => onDelete(company.id)}
                >
                  <Trash2 size={14} className="mr-1" /> Delete
                </Button>
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default CompanyListView;
