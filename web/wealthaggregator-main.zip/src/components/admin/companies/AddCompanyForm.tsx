
import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";

interface AddCompanyFormProps {
  newCompanyName: string;
  setNewCompanyName: (value: string) => void;
  newCompanyLogo: string;
  setNewCompanyLogo: (value: string) => void;
  newCompanyCount: number;
  setNewCompanyCount: (value: number) => void;
  handleAddCompany: () => void;
  icon?: React.ReactNode;
}

const AddCompanyForm = ({
  newCompanyName,
  setNewCompanyName,
  newCompanyLogo,
  setNewCompanyLogo,
  newCompanyCount,
  setNewCompanyCount,
  handleAddCompany,
  icon,
}: AddCompanyFormProps) => {
  return (
    <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        {icon}
        Add New Company
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="md:col-span-2">
          <Label htmlFor="company-name">Company Name</Label>
          <Input 
            id="company-name" 
            value={newCompanyName} 
            onChange={e => setNewCompanyName(e.target.value)} 
            placeholder="e.g., Apple"
          />
        </div>
        <div>
          <Label htmlFor="company-logo">Logo URL (optional)</Label>
          <Input 
            id="company-logo" 
            value={newCompanyLogo} 
            onChange={e => setNewCompanyLogo(e.target.value)} 
            placeholder="https://..."
          />
        </div>
        <div>
          <Label htmlFor="company-count">Article Count</Label>
          <Input 
            id="company-count" 
            type="number" 
            value={newCompanyCount.toString()} 
            onChange={e => setNewCompanyCount(parseInt(e.target.value) || 0)} 
            placeholder="0"
          />
        </div>
        <div className="md:col-span-4">
          <Button 
            onClick={handleAddCompany} 
            className="w-full md:w-auto"
          >
            <Plus size={16} className="mr-1" /> Add Company
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AddCompanyForm;
