
import React from "react";
import { CompanySource } from "@/types/admin";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Trash2, FileImage } from "lucide-react";
import { Link } from "react-router-dom";
import { getBestFaviconUrl } from "@/utils/favicon";

interface CompanyGridViewProps {
  companies: CompanySource[];
  onDelete: (id: string) => void;
  onAddLogo: (id: string) => void;
}

const CompanyGridView = ({ companies, onDelete, onAddLogo }: CompanyGridViewProps) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {companies.map((company) => (
        <Card key={company.id} className="overflow-hidden">
          <CardContent className="flex items-center justify-between p-4">
            <Link to={company.id === "all" ? "/" : `/company/${company.id}`} className="flex items-center space-x-2">
              <Avatar className="w-10 h-10 border border-gray-200">
                {company.logo ? (
                  <AvatarImage 
                    src={company.logo} 
                    alt={company.name}
                    onError={(e) => {
                      console.log(`Company logo error for ${company.name}:`, company.logo);
                      // If image fails to load, use a fallback
                      const target = e.target as HTMLImageElement;
                      if (!target.src.includes('generateCompanyLogo')) {
                        // For companies, attempt to use their domain name if possible
                        let domain = "";
                        const nameLower = company.name.toLowerCase();
                        
                        if (nameLower.includes("apple")) domain = "apple.com";
                        else if (nameLower.includes("tesla")) domain = "tesla.com";
                        else if (nameLower.includes("general electric") || nameLower.includes("ge")) domain = "ge.com";
                        else if (nameLower.includes("intel")) domain = "intel.com";
                        else if (nameLower.includes("twitter") || nameLower === "x") domain = "twitter.com";
                        else if (nameLower.includes("microsoft")) domain = "microsoft.com";
                        else if (nameLower.includes("amazon")) domain = "amazon.com";
                        else if (nameLower.includes("facebook") || nameLower.includes("meta")) domain = "facebook.com";
                        else if (nameLower.includes("google")) domain = "google.com";
                        else if (nameLower === "all") domain = ""; // Special case
                        
                        target.src = getBestFaviconUrl(company.name, domain);
                      }
                    }} 
                  />
                ) : (
                  <AvatarFallback className="bg-gray-100 text-gray-800 font-medium">
                    {company.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                )}
              </Avatar>
              <div>
                <p className="font-medium">{company.name}</p>
                <p className="text-xs text-gray-500">{company.count} articles</p>
              </div>
            </Link>
            <div className="flex items-center gap-2">
              {!company.logo && company.id !== "all" && (
                <Button
                  variant="outline" 
                  size="icon" 
                  className="h-8 w-8 text-purple-500 hover:text-purple-700 hover:bg-purple-50 p-0"
                  onClick={() => onAddLogo(company.id)}
                  title="Generate logo"
                >
                  <FileImage size={14} />
                </Button>
              )}
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50 p-0"
                onClick={() => onDelete(company.id)}
                title="Delete company"
              >
                <Trash2 size={14} />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default CompanyGridView;
