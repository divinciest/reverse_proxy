
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FeedSource } from "@/types/admin";

interface NewFeedFormManagerProps {
  onAddFeed: (feed: Omit<FeedSource, "id" | "lastFetched">) => Promise<void>;
}

const NewFeedFormManager = ({ onAddFeed }: NewFeedFormManagerProps) => {
  const [showForm, setShowForm] = useState(false);
  const [newFeedName, setNewFeedName] = useState("");
  const [newFeedUrl, setNewFeedUrl] = useState("");
  const [newFeedLogo, setNewFeedLogo] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const toggleForm = () => {
    setShowForm(!showForm);
    // Reset form when hiding
    if (showForm) {
      resetForm();
    }
  };

  const resetForm = () => {
    setNewFeedName("");
    setNewFeedUrl("");
    setNewFeedLogo("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      await onAddFeed({
        name: newFeedName,
        url: newFeedUrl,
        logo: newFeedLogo,
        count: 0,
        selected: false
      });
      
      // Reset form and hide it
      resetForm();
      setShowForm(false);
    } catch (error) {
      // Error is handled in the parent component
      console.error("Error submitting form:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="mb-6">
      <Button
        variant={showForm ? "default" : "outline"}
        onClick={toggleForm}
        className="w-full mb-4"
      >
        <Plus className="mr-2 h-4 w-4" />
        {showForm ? "Cancel" : "Add New Feed Source"}
      </Button>

      {showForm && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Add New Feed Source</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="feed-name">Feed Name</Label>
                  <Input
                    id="feed-name"
                    placeholder="e.g., Bloomberg News"
                    value={newFeedName}
                    onChange={(e) => setNewFeedName(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="feed-url">RSS Feed URL</Label>
                  <Input
                    id="feed-url"
                    placeholder="e.g., https://www.example.com/rss"
                    value={newFeedUrl}
                    onChange={(e) => setNewFeedUrl(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="feed-logo">Logo URL (Optional)</Label>
                <Input
                  id="feed-logo"
                  placeholder="e.g., https://www.example.com/logo.png"
                  value={newFeedLogo}
                  onChange={(e) => setNewFeedLogo(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  If left blank, we'll attempt to find a logo automatically
                </p>
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={toggleForm}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Adding..." : "Add Feed Source"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default NewFeedFormManager;
