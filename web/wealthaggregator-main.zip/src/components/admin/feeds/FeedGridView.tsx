
import React from "react";
import { FeedSource } from "@/types/admin";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Trash2, FileImage, ExternalLink, Newspaper } from "lucide-react";
import { Link } from "react-router-dom";
import { getBestFaviconUrl } from "@/utils/favicon";
import { Badge } from "@/components/ui/badge";

interface FeedGridViewProps {
  feeds: FeedSource[];
  onDelete: (id: string) => void;
  onAddLogo: (id: string) => void;
}

const FeedGridView = ({ feeds, onDelete, onAddLogo }: FeedGridViewProps) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {feeds.map((feed) => (
        <Card key={feed.id} className="overflow-hidden flex flex-col">
          <CardContent className="flex flex-col items-center pt-6 pb-4 text-center">
            <Link 
              to={feed.id === "all" ? "/" : `/source/${feed.id}`} 
              className="flex flex-col items-center space-y-3"
            >
              <Avatar className="w-16 h-16 border border-gray-200">
                {feed.logo ? (
                  <AvatarImage 
                    src={feed.logo} 
                    alt={feed.name}
                    onError={(e) => {
                      console.log(`Feed logo error for ${feed.name}:`, feed.logo);
                      // If image fails to load, try a fallback
                      const target = e.target as HTMLImageElement;
                      if (!target.src.includes('generateCompanyLogo')) {
                        // Try to get a better logo based on feed name
                        const nameLower = feed.name.toLowerCase();
                        let domain = "";
                        
                        if (feed.url) {
                          try {
                            const url = new URL(feed.url);
                            domain = url.hostname;
                          } catch (e) {
                            console.error("Invalid URL:", feed.url);
                          }
                        }
                        
                        target.src = getBestFaviconUrl(feed.name, domain);
                      }
                    }}
                  />
                ) : (
                  <AvatarFallback className="bg-gray-100 text-gray-800 font-medium">
                    {feed.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                )}
              </Avatar>
              <div>
                <p className="font-medium text-lg">{feed.name}</p>
                <div className="flex items-center justify-center gap-2 mt-1">
                  <Newspaper className="h-4 w-4 text-blue-500" />
                  <Badge variant="secondary" className="font-medium">
                    {feed.count || 0} articles
                  </Badge>
                </div>
              </div>
            </Link>
            
            {feed.url && (
              <a 
                href={feed.url} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="mt-3 text-sm text-blue-500 hover:text-blue-700 flex items-center gap-1"
              >
                Visit website <ExternalLink size={12} />
              </a>
            )}
          </CardContent>
          
          <CardFooter className="flex items-center justify-center gap-2 pt-0 border-t mt-auto">
            {!feed.logo && (
              <Button
                variant="outline"
                size="sm"
                className="text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                title="Generate logo"
                onClick={() => onAddLogo(feed.id)}
              >
                <FileImage size={14} className="mr-1" /> Logo
              </Button>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              className="text-red-500 hover:text-red-700 hover:bg-red-50"
              onClick={() => onDelete(feed.id)}
              title="Delete feed"
              disabled={feed.id === "all"}
            >
              <Trash2 size={14} className="mr-1" /> Delete
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
};

export default FeedGridView;
