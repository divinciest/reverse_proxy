import React from "react";
import { FeedSource } from "@/types/admin";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trash2, FileImage, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { getBestFaviconUrl } from "@/utils/favicon";

interface FeedListViewProps {
  feeds: FeedSource[];
  onDelete: (id: string) => void;
  onAddLogo: (id: string) => void;
}

const FeedListView = ({ feeds, onDelete, onAddLogo }: FeedListViewProps) => {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Source</TableHead>
          <TableHead>Articles</TableHead>
          <TableHead>Website</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {feeds.map((feed) => (
          <TableRow key={feed.id}>
            <TableCell>
              <Link 
                to={feed.id === "all" ? "/" : `/source/${feed.id}`} 
                className="flex items-center gap-3"
              >
                <Avatar className="w-8 h-8">
                  {feed.logo ? (
                    <AvatarImage 
                      src={feed.logo} 
                      alt={feed.name}
                      onError={(e) => {
                        console.log(`Feed logo error in list view for ${feed.name}:`, feed.logo);
                        // If logo fails to load, try to use favicon service
                        const target = e.target as HTMLImageElement;
                        if (!target.src.includes('generateCompanyLogo')) {
                          // Try to get a better logo based on feed name
                          let domain = "";
                          if (feed.url) {
                            try {
                              const url = new URL(feed.url);
                              domain = url.hostname;
                            } catch (e) {
                              console.error("Invalid URL:", feed.url);
                            }
                          }
                          
                          target.src = getBestFaviconUrl(feed.name, domain);
                        }
                      }}
                    />
                  ) : (
                    <AvatarFallback className="bg-gray-100 text-gray-800 font-bold text-xs">
                      {feed.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  )}
                </Avatar>
                <span className="font-medium">{feed.name}</span>
              </Link>
            </TableCell>
            <TableCell>
              <Badge variant="secondary" className="font-medium">
                {feed.count || 0}
              </Badge>
            </TableCell>
            <TableCell>
              {feed.url ? (
                <a 
                  href={feed.url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-blue-500 hover:text-blue-700 flex items-center gap-1 text-sm"
                >
                  Visit <ExternalLink size={12} />
                </a>
              ) : (
                <span className="text-muted-foreground text-sm">N/A</span>
              )}
            </TableCell>
            <TableCell className="text-right">
              <div className="flex items-center justify-end gap-2">
                {!feed.logo && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                    title="Generate logo"
                    onClick={() => onAddLogo(feed.id)}
                  >
                    <FileImage size={14} className="mr-1" /> Generate Logo
                  </Button>
                )}
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  onClick={() => onDelete(feed.id)}
                  disabled={feed.id === "all"}
                >
                  <Trash2 size={14} className="mr-1" /> Delete
                </Button>
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default FeedListView;
