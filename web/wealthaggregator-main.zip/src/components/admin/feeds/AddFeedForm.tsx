
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

interface AddFeedFormProps {
  newFeedName: string;
  setNewFeedName: (name: string) => void;
  newFeedLogo: string;
  setNewFeedLogo: (logo: string) => void;
  newFeedCount: number;
  setNewFeedCount: (count: number) => void;
  newFeedUrl: string;
  setNewFeedUrl: (url: string) => void;
  handleAddFeed: () => void;
  icon: React.ReactNode;
}

const AddFeedForm = ({
  newFeedName,
  setNewFeedName,
  newFeedLogo,
  setNewFeedLogo,
  newFeedCount,
  setNewFeedCount,
  newFeedUrl,
  setNewFeedUrl,
  handleAddFeed,
  icon,
}: AddFeedFormProps) => {
  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          {icon}
          <span className="ml-2">Add New Feed Source</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="feed-name">Name</Label>
            <Input
              id="feed-name"
              placeholder="e.g. Bloomberg"
              value={newFeedName}
              onChange={(e) => setNewFeedName(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="feed-url">Website URL</Label>
            <Input
              id="feed-url"
              placeholder="e.g. https://www.bloomberg.com"
              value={newFeedUrl}
              onChange={(e) => setNewFeedUrl(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="feed-logo">Logo URL (optional)</Label>
            <Input
              id="feed-logo"
              placeholder="e.g. https://example.com/logo.png"
              value={newFeedLogo}
              onChange={(e) => setNewFeedLogo(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Leave blank to auto-generate from website
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="feed-count">Initial Article Count</Label>
            <Input
              id="feed-count"
              type="number"
              min="0"
              value={newFeedCount}
              onChange={(e) => setNewFeedCount(parseInt(e.target.value) || 0)}
            />
          </div>
        </div>
        <Button onClick={handleAddFeed} className="mt-4">
          Add Feed Source
        </Button>
      </CardContent>
    </Card>
  );
};

export default AddFeedForm;
