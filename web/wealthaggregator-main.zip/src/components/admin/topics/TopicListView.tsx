
import React from "react";
import { Topic } from "@/types/admin";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

interface TopicListViewProps {
  topics: Topic[];
  onDelete: (name: string) => void;
}

const TopicListView = ({ topics, onDelete }: TopicListViewProps) => {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Topic</TableHead>
          <TableHead>Articles</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {topics.map((topic) => (
          <TableRow key={topic.name}>
            <TableCell>
              <span className="font-medium">{topic.name}</span>
            </TableCell>
            <TableCell>
              <Badge>{topic.count}</Badge>
            </TableCell>
            <TableCell className="text-right">
              <Button 
                variant="outline" 
                size="sm" 
                className="text-red-500 hover:text-red-700 hover:bg-red-50"
                onClick={() => onDelete(topic.name)}
              >
                <Trash2 size={14} className="mr-1" /> Delete
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default TopicListView;
