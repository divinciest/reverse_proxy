
import React from "react";
import { Topic } from "@/types/admin";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

interface TopicGridViewProps {
  topics: Topic[];
  onDelete: (name: string) => void;
}

const TopicGridView = ({ topics, onDelete }: TopicGridViewProps) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {topics.map((topic) => (
        <Card key={topic.name} className="overflow-hidden">
          <CardContent className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-2">
              <div className="bg-gray-100 text-gray-800 rounded-full h-10 w-10 flex items-center justify-center font-medium">
                {topic.name.substring(0, 2)}
              </div>
              <div>
                <p className="font-medium">{topic.name}</p>
                <p className="text-xs text-gray-500">{topic.count} articles</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="icon" 
              className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50 p-0"
              onClick={() => onDelete(topic.name)}
            >
              <Trash2 size={14} />
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default TopicGridView;
