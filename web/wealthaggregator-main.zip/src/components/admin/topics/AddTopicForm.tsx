
import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";

interface AddTopicFormProps {
  newTopicName: string;
  setNewTopicName: (value: string) => void;
  newTopicCount: number;
  setNewTopicCount: (value: number) => void;
  handleAddTopic: () => void;
  icon?: React.ReactNode;
}

const AddTopicForm = ({
  newTopicName,
  setNewTopicName,
  newTopicCount,
  setNewTopicCount,
  handleAddTopic,
  icon,
}: AddTopicFormProps) => {
  return (
    <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        {icon}
        Add New Topic
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2">
          <Label htmlFor="topic-name">Topic Name</Label>
          <Input 
            id="topic-name" 
            value={newTopicName} 
            onChange={e => setNewTopicName(e.target.value)} 
            placeholder="e.g., technology"
          />
        </div>
        <div>
          <Label htmlFor="topic-count">Article Count</Label>
          <Input 
            id="topic-count" 
            type="number" 
            value={newTopicCount.toString()} 
            onChange={e => setNewTopicCount(parseInt(e.target.value) || 0)} 
            placeholder="0"
          />
        </div>
        <div className="md:col-span-3">
          <Button 
            onClick={handleAddTopic} 
            className="w-full md:w-auto"
          >
            <Plus size={16} className="mr-1" /> Add Topic
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AddTopicForm;
