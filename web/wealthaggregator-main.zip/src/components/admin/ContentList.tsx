
import React from "react";
import SortFilter from "@/components/SortFilter";
import ViewToggle from "@/components/ViewToggle";

interface ContentListProps {
  title: string;
  searchValue: string;
  onSearchChange: (value: string) => void;
  sortValue: "default" | "az" | "za";
  onSortChange: (value: "default" | "az" | "za") => void;
  viewType: "grid" | "list";
  onViewChange: (view: "grid" | "list") => void;
  renderGridView: () => React.ReactNode;
  renderListView: () => React.ReactNode;
  icon?: React.ReactNode;
}

const ContentList = ({
  title,
  searchValue,
  onSearchChange,
  sortValue,
  onSortChange,
  viewType,
  onViewChange,
  renderGridView,
  renderListView,
  icon,
}: ContentListProps) => {
  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
        <h3 className="text-lg font-medium flex items-center gap-2">
          {icon && <span className="text-primary">{icon}</span>}
          {title}
        </h3>
        <div className="flex items-center space-x-2 w-full md:w-auto">
          <SortFilter onSort={onSortChange} currentSort={sortValue} />
          <ViewToggle activeView={viewType} onChange={onViewChange} />
        </div>
      </div>
      
      {viewType === "grid" ? renderGridView() : renderListView()}
    </div>
  );
};

export default ContentList;
