
import React from "react";
import { cn } from "@/lib/utils";

interface TopicBadgeProps {
  topic: string;
  className?: string;
  onClick?: () => void;
  active?: boolean;
  variant?: "topic" | "author" | "expert" | "default";
  children?: React.ReactNode;
  size?: "sm" | "md" | "lg";
}

const TopicBadge = ({
  topic,
  className,
  onClick,
  active = false,
  variant = "default",
  children,
  size = "md",
}: TopicBadgeProps) => {
  return (
    <button
      onClick={onClick}
      className={cn(
        "inline-flex items-center rounded-full text-xs font-medium border transition-colors",
        size === "sm" ? "px-2 py-0.5 text-xs" : 
        size === "lg" ? "px-4 py-1.5 text-sm" : 
        "px-3 py-1 text-xs",
        active
          ? "bg-primary text-primary-foreground border-primary"
          : variant === "topic" 
            ? "bg-amber-100 text-amber-800 border-amber-200 hover:bg-amber-200" 
            : variant === "author"
            ? "bg-blue-50 text-blue-800 border-blue-100 hover:bg-blue-100"
            : variant === "expert"
            ? "bg-green-50 text-green-800 border-green-100 hover:bg-green-100"
            : "bg-secondary text-secondary-foreground border-secondary hover:bg-secondary/80",
        onClick && "cursor-pointer",
        className
      )}
    >
      {children || topic}
    </button>
  );
};

export default TopicBadge;
