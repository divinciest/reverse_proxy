
import React from "react";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { List, Grid } from "lucide-react";

interface ViewToggleProps {
  activeView: "list" | "grid";
  onChange: (view: "list" | "grid") => void;
}

const ViewToggle = ({ activeView, onChange }: ViewToggleProps) => {
  return (
    <ToggleGroup type="single" value={activeView} onValueChange={(value) => value && onChange(value as "list" | "grid")}>
      <ToggleGroupItem value="list" aria-label="List view">
        <List className="h-4 w-4" />
      </ToggleGroupItem>
      <ToggleGroupItem value="grid" aria-label="Grid view">
        <Grid className="h-4 w-4" />
      </ToggleGroupItem>
    </ToggleGroup>
  );
};

export default ViewToggle;
