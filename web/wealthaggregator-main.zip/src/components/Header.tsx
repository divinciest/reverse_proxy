
import React from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Tags, BookUser, LineChart, BookOpen, TrendingUp, User, Layout } from "lucide-react";
import TopicBar from "@/components/TopicBar";

const Header = () => {
  return (
    <header className="bg-white border-b border-gray-200">
      <div className="container mx-auto py-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
          <Link to="/" className="mb-2 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold font-display tracking-tight text-gray-900 text-center md:text-left">
              WealthManager.com
            </h1>
          </Link>
          
          <div className="flex items-center gap-2 justify-center md:justify-end">
            <Link to="/about-premium">
              <Button variant="outline" className="border-gray-400">ABOUT PREMIUM</Button>
            </Link>
            <Button asChild className="bg-orange-500 hover:bg-orange-600">
              <Link to="/subscription">Get Started</Link>
            </Button>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row items-center justify-between mt-4 border-t border-b border-gray-300 py-2">
          <div className="flex items-center space-x-2">
            {/* All Topics Link */}
            <Link to="/topics">
              <Button variant="ghost" className="font-serif flex items-center">
                <Tags size={16} className="mr-1" />
                All Topics
              </Button>
            </Link>
            
            {/* Authors Link */}
            <Link to="/authors">
              <Button variant="ghost" className="font-serif flex items-center">
                <BookUser size={16} className="mr-1" />
                Authors
              </Button>
            </Link>
            
            {/* Stocks Link */}
            <Link to="/stocks">
              <Button variant="ghost" className="font-serif flex items-center">
                <LineChart size={16} className="mr-1" />
                Stocks
              </Button>
            </Link>

            <Link to="/markets">
              <Button variant="ghost" className="font-serif flex items-center">
                <LineChart size={16} className="mr-1" />
                Markets
              </Button>
            </Link>

            {/* Billionaires Link */}
            <Link to="/billionaires">
              <Button variant="ghost" className="font-serif flex items-center">
                <User size={16} className="mr-1" />
                Billionaires
              </Button>
            </Link>

            {/* Charts Link */}
            <Link to="/charts">
              <Button variant="ghost" className="font-serif flex items-center">
                <TrendingUp size={16} className="mr-1" />
                Charts
              </Button>
            </Link>

            {/* Books Link */}
            <Link to="/books">
              <Button variant="ghost" className="font-serif flex items-center">
                <BookOpen size={16} className="mr-1" />
                Books
              </Button>
            </Link>
            
            {/* Widgets Link */}
            <Link to="/widgets">
              <Button variant="ghost" className="font-serif flex items-center">
                <Layout size={16} className="mr-1" />
                Widgets
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Topic navigation bar */}
      <TopicBar />
    </header>
  );
};

export default Header;
