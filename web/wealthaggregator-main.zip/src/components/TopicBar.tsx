
import React from "react";
import { Button } from "@/components/ui/button";
import { LineChart, BookUser, User } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Link } from "react-router-dom";
import TopicBadge from "@/components/TopicBadge";
import { topics, topicsStrings } from "@/data/topics";

const TopicBar = () => {
  // Get a subset of topics to display
  // Use topicsStrings array which contains the string values of topics
  const displayTopics = topicsStrings.slice(0, 7); // Reduced by 1 to accommodate Billionaires
  
  return (
    <div className="bg-[#e9dbbd] py-3">
      <div className="container mx-auto">
        <ScrollArea className="w-full">
          <div className="flex items-center space-x-3">
            {/* S&P 500 Index Link */}
            <Link to="/sp500">
              <Button 
                variant="outline" 
                className="rounded-full border-gray-300 bg-green-50 text-green-800 flex gap-1 items-center whitespace-nowrap"
              >
                <LineChart size={16} />
                S&P 500 Index
              </Button>
            </Link>
            
            {/* Billionaires Link */}
            <Link to="/billionaires">
              <TopicBadge 
                topic="Billionaires" 
                variant="topic"
                className="flex gap-1 items-center whitespace-nowrap"
              >
                <User size={16} className="mr-1" />
                Billionaires
              </TopicBadge>
            </Link>
            
            {/* Matt Levine Author Link */}
            <Link to="/author/matt-levine">
              <TopicBadge 
                topic="Matt Levine" 
                variant="author"
                className="flex gap-1 items-center whitespace-nowrap"
              >
                <BookUser size={16} className="mr-1" />
                Matt Levine
              </TopicBadge>
            </Link>
            
            {/* Warren Buffett Expert Link */}
            <Link to="/expert/warren-buffett">
              <TopicBadge
                topic="Warren Buffett"
                variant="expert"
                className="flex gap-1 items-center whitespace-nowrap"
              />
            </Link>
            
            {/* Regular topics */}
            {displayTopics.map((topic) => (
              <Link key={topic} to={`/topic/${encodeURIComponent(topic.toLowerCase().replace(/ /g, '-'))}`}>
                <TopicBadge 
                  topic={topic}
                  variant="topic"
                  className="flex gap-1 items-center whitespace-nowrap"
                />
              </Link>
            ))}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
};

export default TopicBar;
