import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import CompanyFilter from "@/components/filters/CompanyFilter";
import TagFilter from "@/components/filters/TopicFilter";
import FeedSourceFilter from "@/components/filters/FeedSourceFilter";
import { Separator } from "@/components/ui/separator";
import { feedService } from "@/utils/feedService";
import { tagService } from "@/utils/tagService";
import { Topic, CompanySource, FeedSource } from "@/types/admin";
import { CompanyMetadata } from "@/utils/feedService";

interface FeedFiltersProps {
  onFeedSourcesChange?: (sources: string[]) => void;
  onCompaniesChange?: (companies: string[]) => void;
  onTopicsChange?: (topics: string[]) => void;
  sourcesArticleCounts?: {[id: string]: number};
  companiesArticleCounts?: {[id: string]: number};
  companiesData?: CompanyMetadata[];
}

const FeedFilters = ({ 
  onFeedSourcesChange, 
  onCompaniesChange,
  onTopicsChange,
  sourcesArticleCounts = {},
  companiesArticleCounts = {},
  companiesData = []
}: FeedFiltersProps) => {
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);
  const [selectedFeedSources, setSelectedFeedSources] = useState<string[]>([]);
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>([]);
  const [feedSources, setFeedSources] = useState<FeedSource[]>([]);
  const [companies, setCompanies] = useState<CompanySource[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState({
    feeds: true,
    companies: true,
    topics: true
  });
  const [topicSectionOpen, setTopicSectionOpen] = useState(true);
  const [companySectionOpen, setCompanySectionOpen] = useState(true);
  const [feedSectionOpen, setFeedSectionOpen] = useState(true);
  const [showAllTopics, setShowAllTopics] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch feed sources from API
  useEffect(() => {
    const fetchFeedSources = async () => {
      try {
        const sources = await feedService.getPopularFeeds();
        
        // Create "All" feed source
        const allFeedSource: FeedSource = {
          id: "all",
          name: "All Sources",
          logo: null,
          count: 0, // Will be updated below
          selected: true, // Start with "All" selected
          url: "", 
          lastFetched: new Date().toISOString()
        };
        
        // Format other sources
        const formattedSources: FeedSource[] = sources.map(feed => ({
          id: feed._id,
          name: feed.name,
          logo: feed.favicon || null,
          count: sourcesArticleCounts[feed._id] || 0,
          selected: true, // Start with all sources selected
          url: feed.urls[0] || "", 
          lastFetched: new Date().toISOString()
        }));
        
        // Update "All" count
        allFeedSource.count = formattedSources.reduce((sum, feed) => sum + feed.count, 0);
        
        // Combine "All" with other sources
        const allSources = [allFeedSource, ...formattedSources];
        setFeedSources(allSources);
        
        // Initially select all feed sources
        const allSourceIds = allSources.map(source => source.id);
        setSelectedFeedSources(allSourceIds);
        if (onFeedSourcesChange) {
          onFeedSourcesChange(allSourceIds);
        }
      } catch (error) {
        console.error("Error fetching feed sources:", error);
        setError("Failed to load feed sources");
      } finally {
        setLoading(prev => ({ ...prev, feeds: false }));
      }
    };

    fetchFeedSources();
  }, [sourcesArticleCounts]);

  // Process companies data (either from API or default)
  useEffect(() => {
    const processCompanies = async () => {
      try {
        // Create "All" company
        const allCompany: CompanySource = {
          id: "all",
          name: "All Companies",
          logo: null,
          count: 0, // Will be updated below
          selected: true, // Start with "All" selected
          url: ""
        };
        
        let formattedCompanies: CompanySource[] = [];
        
        // If we have companies data from API, use that first
        if (companiesData && companiesData.length > 0) {
          formattedCompanies = companiesData.map(company => ({
            id: company._id,
            name: company.name,
            logo: company.favicon || null,
            count: companiesArticleCounts[company._id] || company.article_count || 0,
            selected: false, // Individual companies start unselected when "All" is active
            url: company.domain || ""
          }));
        } else {
          // Fallback to fetching companies
          const companiesData = await feedService.getPlatformCompanies();
          formattedCompanies = companiesData.map(company => ({
            id: company._id,
            name: company.name,
            logo: company.favicon || null,
            count: companiesArticleCounts[company._id] || 0,
            selected: false, // Individual companies start unselected when "All" is active
            url: company.domain || ""
          }));
        }
        
        // Update "All" count
        allCompany.count = formattedCompanies.reduce((sum, company) => sum + company.count, 0);
        
        // Combine "All" with other companies
        const allCompanies = [allCompany, ...formattedCompanies];
        setCompanies(allCompanies);
        
        // Initially select "All" company
        setSelectedCompanies(["all"]);
        if (onCompaniesChange) {
          onCompaniesChange(["all"]);
        }
      } catch (error) {
        console.error("Error processing companies:", error);
        setError("Failed to load companies");
      } finally {
        setLoading(prev => ({ ...prev, companies: false }));
      }
    };

    processCompanies();
  }, [companiesArticleCounts, companiesData]);

  // Fetch tags from API using the public endpoint
  useEffect(() => {
    const fetchTags = async () => {
      try {
        const tagsData = await tagService.getAllTags();
        const formattedTags: Topic[] = tagsData.map(tag => ({
          name: tag.tagName, // Use tagName from the Tag interface
          count: 0, // We don't have count from the API
          selected: selectedTopics.includes(tag.tagName)
        }));
        setTopics(formattedTags);
      } catch (error) {
        console.error("Error fetching tags:", error);
        setError("Failed to load tags");
      } finally {
        setLoading(prev => ({ ...prev, topics: false }));
      }
    };

    fetchTags();
  }, [selectedTopics]);

  // Handle topic changes
  const handleTopicChange = (topicId: string) => {
    setSelectedTopics(prev => 
      prev.includes(topicId) 
        ? prev.filter(id => id !== topicId) 
        : [...prev, topicId]
    );
  };

  // Handle feed source selection with direct toggle model
  const handleFeedSourceChange = (sourceId: string) => {
    if (sourceId === "all") {
      if (feedSources.find(source => source.id === "all")?.selected) {
        setFeedSources(prev => prev.map(source => ({
          ...source,
          selected: false
        })));
        setSelectedFeedSources([]);
      } else {
        setFeedSources(prev => prev.map(source => ({
          ...source,
          selected: true
        })));
        setSelectedFeedSources(feedSources.map(source => source.id));
      }
    } else {
      const updatedSources = feedSources.map(source => {
        if (source.id === sourceId) {
          return { ...source, selected: !source.selected };
        }
        if (source.id === "all") {
          const otherSourcesWillBeSelected = feedSources
            .filter(s => s.id !== "all" && s.id !== sourceId)
            .every(s => s.selected) && !feedSources.find(s => s.id === sourceId)?.selected;
          
          return { ...source, selected: otherSourcesWillBeSelected };
        }
        return source;
      });
      
      setFeedSources(updatedSources);
      
      const newSelectedSources = updatedSources
        .filter(source => source.selected)
        .map(source => source.id);
      
      setSelectedFeedSources(newSelectedSources);
    }
  };

  // Handle company selection with hierarchical model
  const handleCompanyChange = (companyId: string) => {
    let updatedCompanies: CompanySource[];
    let newSelectedCompanies: string[];
    
    if (companyId === "all") {
      const allCurrentlySelected = companies.find(c => c.id === "all")?.selected || false;
      
      updatedCompanies = companies.map(company => ({
        ...company,
        selected: company.id === "all" ? !allCurrentlySelected : false
      }));
      
      newSelectedCompanies = !allCurrentlySelected ? ["all"] : [];
    } else {
      updatedCompanies = companies.map(company => {
        if (company.id === "all") {
          return { ...company, selected: false };
        }
        if (company.id === companyId) {
          return { ...company, selected: !company.selected };
        }
        return company;
      });
      
      newSelectedCompanies = updatedCompanies
        .filter(company => company.selected && company.id !== "all")
        .map(company => company.id);
    }
    
    setCompanies(updatedCompanies);
    setSelectedCompanies(newSelectedCompanies);
  };

  // Notify parent component when selections change
  useEffect(() => {
    if (onFeedSourcesChange) {
      onFeedSourcesChange(selectedFeedSources);
    }
  }, [selectedFeedSources, onFeedSourcesChange]);

  useEffect(() => {
    if (onCompaniesChange) {
      const isAllSelected = selectedCompanies.includes("all");
      onCompaniesChange(isAllSelected ? ["all"] : selectedCompanies);
    }
  }, [selectedCompanies, onCompaniesChange]);

  useEffect(() => {
    if (onTopicsChange) {
      onTopicsChange(selectedTopics);
    }
  }, [selectedTopics, onTopicsChange]);

  return (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-serif">Filter News</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <div className="bg-red-50 text-red-800 p-3 rounded-md text-sm mb-4">
            {error}
          </div>
        )}
        
        <div>
          <TagFilter 
            topics={topics} 
            onToggleTopic={handleTopicChange}
            isOpen={topicSectionOpen}
            onToggleSection={() => setTopicSectionOpen(!topicSectionOpen)}
            showAllTopics={showAllTopics}
            onToggleShowAllTopics={() => setShowAllTopics(!showAllTopics)}
          />
        </div>

        <Separator />

        <div>
          <CompanyFilter 
            companies={companies}
            onToggleCompany={handleCompanyChange}
            isOpen={companySectionOpen}
            onToggleSection={() => setCompanySectionOpen(!companySectionOpen)}
          />
        </div>

        <Separator />

        <div>
          <FeedSourceFilter 
            feeds={feedSources}
            onToggleFeedSource={handleFeedSourceChange}
            isOpen={feedSectionOpen}
            onToggleSection={() => setFeedSectionOpen(!feedSectionOpen)}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default FeedFilters;
