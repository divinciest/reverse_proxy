
import React from "react";
import { Clock } from "lucide-react";

interface DateFilterProps {
  activeFilter: string;
  onChange: (value: string) => void;
}

const DateFilter = ({ activeFilter, onChange }: DateFilterProps) => {
  const filters = [
    { value: "all", label: "All" },
    { value: "1day", label: "1 day" },
    { value: "3days", label: "3 days" },
    { value: "1week", label: "1 week" },
    { value: "15days", label: "15 days" },
    { value: "1month", label: "1 month" },
  ];
  
  // Simplified display version
  const displayFilters = [
    { value: "1day", label: "Day" },
    { value: "1week", label: "Week" },
    { value: "1month", label: "Month" },
  ];

  return (
    <div className="flex items-center">
      <div className="border rounded-md bg-background flex text-sm">
        <div className="p-2 flex items-center border-r">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <span className="ml-2 text-muted-foreground">All</span>
        </div>
        <div className="flex">
          {displayFilters.map((filter) => (
            <button
              key={filter.value} 
              onClick={() => onChange(filter.value)}
              className={`px-4 py-2 ${
                activeFilter === filter.value 
                  ? 'bg-primary text-primary-foreground' 
                  : 'hover:bg-accent hover:text-accent-foreground'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DateFilter;
