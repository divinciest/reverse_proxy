
import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { getBestFaviconUrl } from "@/utils/favicon";
import { feedService, FeedSource } from "@/utils/feedService";

const SourcesSection = () => {
  const [sources, setSources] = useState<FeedSource[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch sources from API
  useEffect(() => {
    const fetchSources = async () => {
      try {
        setIsLoading(true);
        const feedSources = await feedService.getPopularFeeds();
        setSources(feedSources);
      } catch (err) {
        console.error("Error fetching sources:", err);
        setError("Failed to load sources");
        // Fall back to mock data if API fails
        import("@/data").then(({ sources: mockSources }) => {
          setSources(mockSources as unknown as FeedSource[]);
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchSources();
  }, []);

  if (isLoading) {
    return (
      <div className="container mx-auto py-8 text-center">
        <h2 className="text-2xl font-serif font-bold mb-4 pb-2 border-b border-gray-800">Featured Sources</h2>
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (error && sources.length === 0) {
    return (
      <div className="container mx-auto py-8 text-center">
        <h2 className="text-2xl font-serif font-bold mb-4 pb-2 border-b border-gray-800">Featured Sources</h2>
        <div className="py-8 text-destructive">
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <h2 className="text-2xl font-serif font-bold mb-4 pb-2 border-b border-gray-800">Featured Sources</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {sources.map((source) => (
          <Card key={source._id} className="overflow-hidden border border-gray-300 hover:shadow-md transition-shadow">
            <Link to={`/source/${source._id}`}>
              <CardContent className="p-4 flex flex-col items-center justify-center h-full">
                {source.favicon ? (
                  <img 
                    src={source.favicon} 
                    alt={source.name} 
                    className="h-12 object-contain mb-4" 
                    onError={(e) => {
                      console.log(`Source logo error for ${source.name}:`, source.favicon);
                      // If image fails to load, try a fallback
                      const target = e.target as HTMLImageElement;
                      if (!target.src.includes('generateCompanyLogo')) {
                        // Try to get a more specific logo based on source name
                        target.src = getBestFaviconUrl(source.name, source.domain);
                      }
                    }}
                  />
                ) : (
                  <div className="h-12 flex items-center justify-center mb-4">
                    <span className="text-lg font-bold font-serif">{source.name}</span>
                  </div>
                )}
                <div className="text-center">
                  <h3 className="text-base font-medium font-serif">{source.name}</h3>
                  <p className="text-xs text-muted-foreground mb-2 font-serif italic">{source.domain}</p>
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-primary hover:underline text-xs">View articles</span>
                    <a 
                      href={source.link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:underline text-xs flex items-center justify-center gap-1"
                      onClick={(e) => e.stopPropagation()}
                    >
                      Visit <ExternalLink size={12} />
                    </a>
                  </div>
                </div>
              </CardContent>
            </Link>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default SourcesSection;
