
import React from "react";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import DateFilter from "@/components/DateFilter";
import ViewToggle from "@/components/ViewToggle";
import SortFilter, { SortFilterProps } from "@/components/SortFilter";
import DateRangeFilter from "@/components/DateRangeFilter";

interface FilterToolbarProps {
  dateFilter: string;
  onDateFilterChange: (filter: string) => void;
  view: "grid" | "list";
  onViewChange: (view: "grid" | "list") => void;
  onRefresh: () => void;
  sortProps: SortFilterProps;
  dateRange?: { start: Date; end: Date } | null;
  onDateRangeChange?: (dateRange: { start: Date; end: Date } | null) => void;
}

const FilterToolbar = ({ 
  dateFilter, 
  onDateFilterChange, 
  view, 
  onViewChange, 
  onRefresh,
  sortProps,
  dateRange,
  onDateRangeChange
}: FilterToolbarProps) => {
  return (
    <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
      <DateFilter activeFilter={dateFilter} onChange={onDateFilterChange} />
      
      {onDateRangeChange && (
        <DateRangeFilter 
          dateRange={dateRange} 
          onDateRangeChange={onDateRangeChange} 
        />
      )}
      
      <Button 
        variant="outline" 
        size="icon" 
        onClick={onRefresh}
        className="ml-2"
      >
        <RefreshCw className="h-4 w-4" />
      </Button>
      
      <ViewToggle activeView={view} onChange={onViewChange} />
      
      <div className="ml-2">
        <SortFilter onSort={sortProps.onSort} currentSort={sortProps.currentSort} />
      </div>
    </div>
  );
};

export default FilterToolbar;
