
import React from "react";

const StocksFooter: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white py-6 border-t-4 border-gray-900">
      <div className="container mx-auto">
        <div className="text-center">
          <p className="font-serif text-lg">&copy; 2023 WealthManager.com - Financial News Aggregator</p>
          <p className="mt-1 text-gray-300">
            Providing aggregated financial content with AI-powered sentiment analysis
          </p>
        </div>
      </div>
    </footer>
  );
};

export default StocksFooter;
