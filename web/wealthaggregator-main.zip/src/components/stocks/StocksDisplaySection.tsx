
import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { ExternalLink, TrendingUp, TrendingDown } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import FilterToolbar from "@/components/FilterToolbar";
import SortButtons from "@/components/sp500/SortButtons";

interface CompanyData {
  id: string;
  name: string;
  ticker: string;
  exchange: string;
  price: number;
  change: number;
  changePercent: number;
  industry: string;
}

interface StocksDisplaySectionProps {
  companies: CompanyData[];
  companyLogos: Record<string, string>;
}

const StocksDisplaySection: React.FC<StocksDisplaySectionProps> = ({ companies, companyLogos }) => {
  // UI state
  const [view, setView] = useState<"grid" | "list">("grid");
  const [dateFilter, setDateFilter] = useState<string>("today");
  const [currentSort, setCurrentSort] = useState<string>("default");

  // Handle refresh
  const handleRefresh = () => {
    console.log("Refreshing company data...");
    // In a real app, this would fetch fresh data
  };

  // Handle sort change
  const handleSort = (sortType: string) => {
    setCurrentSort(sortType);
  };

  // Sort companies based on currentSort
  const sortedCompanies = useMemo(() => {
    if (!companies) return [];
    
    const sortedData = [...companies];
    
    switch (currentSort) {
      case "az":
        return sortedData.sort((a, b) => a.name.localeCompare(b.name));
      case "za":
        return sortedData.sort((a, b) => b.name.localeCompare(a.name));
      case "percentGain":
        return sortedData.sort((a, b) => b.change - a.change);
      case "percentLoss":
        return sortedData.sort((a, b) => a.change - b.change);
      case "marketCap":
        // Mock market cap calculation (in a real app, this would come from API)
        return sortedData.sort((a, b) => {
          const aPrice = a.price || 0;
          const bPrice = b.price || 0;
          return bPrice - aPrice; // Using price as a proxy for market cap
        });
      default:
        return sortedData;
    }
  }, [companies, currentSort]);

  return (
    <Card className="mb-6 mt-4">
      <CardHeader className="pb-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <CardTitle className="text-2xl font-serif">
            All Companies
          </CardTitle>
          
          {/* Add filter toolbar */}
          <FilterToolbar
            dateFilter={dateFilter}
            onDateFilterChange={setDateFilter}
            view={view}
            onViewChange={setView}
            onRefresh={handleRefresh}
            sortProps={{
              onSort: handleSort,
              currentSort: currentSort
            }}
          />
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground mb-6">
          Browse all {companies.length} companies available on WealthManager.com
        </p>
        
        {/* Add sort buttons */}
        <SortButtons 
          currentSort={currentSort}
          setCurrentSort={handleSort}
          disabled={false}
        />
        
        {/* Companies grid/list */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          {sortedCompanies.map((company) => (
            <Link key={company.id} to={`/company/${company.id}`} 
              className="group block p-4 bg-white rounded-lg border border-gray-200 hover:border-primary hover:shadow-md transition-all">
              <div className="flex items-center gap-3">
                <Avatar className="h-12 w-12">
                  {companyLogos[company.id] ? (
                    <img 
                      src={companyLogos[company.id]} 
                      alt={company.name} 
                      className="h-full w-full object-contain p-1"
                      loading="eager"
                      onError={(e) => {
                        console.log(`Failed to load logo for ${company.name}`);
                        const target = e.target as HTMLImageElement;
                        // Fallback to initials if logo fails to load
                        target.style.display = 'none';
                        target.parentElement!.textContent = company.name.substring(0, 1);
                      }}
                    />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center bg-primary/10 font-medium">
                      {company.ticker.substring(0, 1)}
                    </div>
                  )}
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="font-medium group-hover:text-primary flex items-center gap-1">
                    {company.name}
                    <ExternalLink className="h-3.5 w-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="text-sm text-muted-foreground">{company.ticker} • {company.exchange}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-lg">${company.price.toFixed(2)}</div>
                  <div className={`flex items-center justify-end text-sm ${company.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {company.change >= 0 ? (
                      <TrendingUp size={14} className="mr-1" />
                    ) : (
                      <TrendingDown size={14} className="mr-1" />
                    )}
                    <span>
                      {company.change >= 0 ? '+' : ''}{company.change} ({company.changePercent}%)
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default StocksDisplaySection;
