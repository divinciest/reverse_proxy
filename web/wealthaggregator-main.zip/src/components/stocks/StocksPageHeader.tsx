
import React from "react";
import BreadcrumbNav from "@/components/BreadcrumbNav";

const StocksPageHeader: React.FC = () => {
  return (
    <>
      {/* Breadcrumb Navigation */}
      <BreadcrumbNav items={[{ label: "Stocks" }]} />
    </>
  );
};

export default StocksPageHeader;
