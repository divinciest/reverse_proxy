
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { CalendarIcon } from "lucide-react";

interface NewsItem {
  date: string;
  title: string;
  link?: string;
  requiresSubscription?: boolean;
}

interface LatestNewsProps {
  expertName: string;
  news: NewsItem[];
}

const LatestNews: React.FC<LatestNewsProps> = ({ expertName, news }) => {
  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-xl font-serif">Latest News</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-4">
          {news.map((item, index) => (
            <li key={index} className="border-b border-gray-100 last:border-0 pb-3 last:pb-0">
              <div className="flex items-center text-xs text-gray-500 mb-1">
                <CalendarIcon className="h-3 w-3 mr-1" />
                <span>{item.date}</span>
              </div>
              <div>
                {item.link ? (
                  <a 
                    href={item.link} 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-medium hover:underline"
                  >
                    {item.title}
                    {item.requiresSubscription && (
                      <span className="text-xs text-gray-500 ml-1">(subscription)</span>
                    )}
                  </a>
                ) : (
                  <span className="text-sm font-medium">{item.title}</span>
                )}
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};

export default LatestNews;
