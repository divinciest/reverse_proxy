
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";

interface InvestmentStrategyProps {
  name: string;
}

const InvestmentStrategy: React.FC<InvestmentStrategyProps> = ({ name }) => {
  // Determine if expert is one of our main experts
  const isBuffett = name === "Warren Buffett";
  const isIcahn = name === "Carl Icahn";
  const isWood = name === "Cathie Wood";

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-xl font-serif">Investment Strategy</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="list-disc pl-5 space-y-2">
          {isBuffett && (
            <>
              <li>Focus on long-term value</li>
              <li>Circle of competence investing</li>
              <li>Margin of safety principle</li>
              <li>Business-focused analysis</li>
            </>
          )}
          {isIcahn && (
            <>
              <li>Activist investing approach</li>
              <li>Corporate governance reform</li>
              <li>Distressed asset opportunities</li>
              <li>Strategic restructuring</li>
            </>
          )}
          {isWood && (
            <>
              <li>Disruptive innovation focus</li>
              <li>Long-term growth potential</li>
              <li>Technology convergence thesis</li>
              <li>Theme-based investing</li>
            </>
          )}
          {!isBuffett && !isIcahn && !isWood && (
            <>
              <li>Focus on long-term value</li>
              <li>Long-term value creation</li>
              <li>Industry trend analysis</li>
              <li>Risk management techniques</li>
            </>
          )}
        </ul>
      </CardContent>
    </Card>
  );
};

export default InvestmentStrategy;
