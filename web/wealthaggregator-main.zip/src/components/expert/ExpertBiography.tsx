
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { formatToBillions } from '@/utils/formatUtils';

interface ExpertBiographyProps {
  name: string;
  title: string;
  bio: string;
  specialty: string;
  performance: string;
  imageUrl: string;
}

const ExpertBiography: React.FC<ExpertBiographyProps> = ({
  name,
  title,
  bio,
  specialty,
  performance,
  imageUrl,
}) => {
  // Expert-specific data
  const expertSpecificData = {
    "Warren Buffett": {
      aum: 924000000000, // $924 billion in assets under management
      aumSource: "SEC filing",
      aumSourceUrl: "https://www.sec.gov/Archives/edgar/data/1067983/000119312525069429/d852297d424b5.htm"
    },
    "Carl Icahn": {
      aum: 23000000000, // $23 billion estimated net worth/AUM
      aumSource: "Icahn Enterprises public filings",
      aumSourceUrl: "#"
    },
    "Cathie Wood": {
      aum: 16000000000, // $16 billion in AUM across ARK funds
      aumSource: "ARK Investment Management LLC",
      aumSourceUrl: "#"
    }
  };

  // Get data for current expert
  const expertData = expertSpecificData[name as keyof typeof expertSpecificData];
  const hasExtraData = !!expertData;

  return (
    <Card className="mb-6">
      <CardHeader className="flex flex-row items-center gap-4">
        <Avatar className="h-24 w-24">
          <img
            src={imageUrl}
            alt={name}
            className="h-full w-full object-cover"
            loading="eager"
          />
        </Avatar>
        <div>
          <CardTitle className="text-3xl font-serif">{name}</CardTitle>
          <p className="text-lg text-muted-foreground">{title}</p>
          {hasExtraData && (
            <p className="text-sm text-muted-foreground mt-1">
              Total Assets Under Management: <span className="font-medium">{formatToBillions(expertData.aum)}</span>
              <span className="text-xs block text-muted-foreground">
                Source: {" "}
                <a 
                  href={expertData.aumSourceUrl} 
                  className="text-blue-600 hover:underline"
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  {expertData.aumSource}
                </a>
              </span>
            </p>
          )}
          <div className="mt-2 inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
            {specialty}
          </div>
          <div className="mt-2 inline-block ml-2 bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium">
            Performance: {performance}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <h3 className="text-xl font-medium mb-2">Biography</h3>
        <p className="text-gray-700 mb-6">{bio}</p>
      </CardContent>
    </Card>
  );
};

export default ExpertBiography;
