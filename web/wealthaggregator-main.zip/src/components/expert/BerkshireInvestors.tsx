
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableRow, 
  TableHead, 
  TableCell 
} from "@/components/ui/table";
import { formatCurrency, formatNumber } from "@/lib/utils";
import { ArrowUpIcon, ArrowDownIcon, MinusIcon } from "lucide-react";
import { berkshireInvestors } from "@/data/berkshireInvestors";
import { formatToBillions } from "@/utils/formatUtils";

interface BerkshireInvestorsProps {
  className?: string;
}

const BerkshireInvestors: React.FC<BerkshireInvestorsProps> = ({ className }) => {
  // Filter out Berkshire Hathaway from the list
  const filteredInvestors = berkshireInvestors.filter(investor => investor.firm !== "Berkshire Hathaway");

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-xl font-serif">Institutions Holding Berkshire Stock</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Firm</TableHead>
                <TableHead className="text-right">Shares (M)</TableHead>
                <TableHead className="text-right">Value ($M)</TableHead>
                <TableHead className="text-right">Portfolio %</TableHead>
                <TableHead className="text-right">Change</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInvestors.map((investor, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{investor.firm}</TableCell>
                  <TableCell className="text-right">{(investor.sharesHeld / 1000000).toFixed(1)}</TableCell>
                  <TableCell className="text-right">${formatNumber(investor.value)}</TableCell>
                  <TableCell className="text-right">{investor.portfolioPercent}%</TableCell>
                  <TableCell className="text-right flex items-center justify-end">
                    {investor.change > 0 ? (
                      <>
                        <span className="text-green-600">{(investor.change / 1000000).toFixed(1)}</span>
                        <ArrowUpIcon className="h-4 w-4 ml-1 text-green-600" />
                      </>
                    ) : investor.change < 0 ? (
                      <>
                        <span className="text-red-600">{(Math.abs(investor.change) / 1000000).toFixed(1)}</span>
                        <ArrowDownIcon className="h-4 w-4 ml-1 text-red-600" />
                      </>
                    ) : (
                      <>
                        <span>0</span>
                        <MinusIcon className="h-4 w-4 ml-1 text-gray-400" />
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <p className="text-xs text-muted-foreground mt-4">
          Source: <a 
            href="https://www.dataroma.com/m/stock.php?sym=BRK.B" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-blue-600 hover:underline"
          >
            Dataroma
          </a>
        </p>
      </CardContent>
    </Card>
  );
};

export default BerkshireInvestors;
