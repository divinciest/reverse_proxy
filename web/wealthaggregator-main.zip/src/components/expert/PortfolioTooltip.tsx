
import React from 'react';
import { formatToBillions } from '@/utils/formatUtils';

interface PortfolioTooltipProps {
  active?: boolean;
  payload?: any[];
}

const PortfolioTooltip: React.FC<PortfolioTooltipProps> = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white p-3 shadow-lg border rounded-md">
        <p className="font-semibold">{data.name}</p>
        <p className="text-sm text-gray-600">{formatToBillions(data.amount)}</p>
        <p className="text-sm text-gray-600">{(data.value).toFixed(2)}% of portfolio</p>
      </div>
    );
  }
  return null;
};

export default PortfolioTooltip;
