
import React from 'react';
import { ArrowUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatToBillions } from '@/utils/formatUtils';
import { getBestFaviconUrl } from '@/utils/favicon';
import { PortfolioItem } from './PortfolioTypes';

interface PortfolioItemsListProps {
  items: PortfolioItem[];
}

const PortfolioItemsList: React.FC<PortfolioItemsListProps> = ({ items }) => {
  return (
    <div className="mt-6 space-y-2">
      <div className="grid grid-cols-3 gap-4">
        {items.map((item, index) => {
          const favicon = getBestFaviconUrl(item.name);
          return (
            <div 
              key={index} 
              className="flex items-center gap-2"
            >
              <div className="flex-shrink-0 w-5 h-5 bg-gray-100 rounded-sm flex items-center justify-center overflow-hidden">
                <img 
                  src={favicon} 
                  alt={item.name} 
                  className="w-5 h-5 object-contain"
                  loading="eager"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.onerror = null;
                    const div = document.createElement('div');
                    div.className = 'w-5 h-5 rounded-sm';
                    div.style.backgroundColor = item.color;
                    target.parentNode?.replaceChild(div, target);
                  }}
                />
              </div>
              <div className="text-sm truncate">
                <span className="font-medium">{item.name}</span>
                <span className="text-gray-500 ml-2">{item.value.toFixed(1)}%</span>
              </div>
              <div className="flex items-center text-xs ml-auto">
                <span className={cn(
                  "flex items-center", 
                  item.value > 5 ? "text-emerald-500" : "text-gray-400"
                )}>
                  {item.value > 5 && <ArrowUp className="h-3 w-3 mr-1" />}
                  {formatToBillions(item.amount)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PortfolioItemsList;
