
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";

interface RecommendedReadingProps {
  name: string;
}

const RecommendedReading: React.FC<RecommendedReadingProps> = ({ name }) => {
  // Determine which expert's reading list to show
  const isBuffett = name === "Warren Buffett";
  const isIcahn = name === "Carl Icahn";
  const isWood = name === "Cathie Wood";
  const isEmmaSmith = name === "Emma Smith";

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-serif">Recommended Reading</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isBuffett && (
          <ul className="space-y-2 text-sm">
            <li>"The Intelligent Investor" by Benjamin Graham</li>
            <li>"Poor Charlie's Almanack" by Charles T. Munger</li>
            <li>"The Essays of Warren Buffett" by Lawrence Cunningham</li>
          </ul>
        )}
        {isIcahn && (
          <ul className="space-y-2 text-sm">
            <li>"King Icahn" by Mark Stevens</li>
            <li>"The Alpha Masters" by Maneet Ahuja</li>
            <li>"Corporate Governance and Value Creation" by Jean-Michel Sahut</li>
          </ul>
        )}
        {isWood && (
          <ul className="space-y-2 text-sm">
            <li>"The Innovator's Dilemma" by Clayton Christensen</li>
            <li>"The Technological Revolution and Financial Capital" by Carlota Perez</li>
            <li>"ARK Disruptive Innovation" (White Paper Series)</li>
          </ul>
        )}
        {isEmmaSmith && (
          <ul className="space-y-2 text-sm">
            <li>"The Psychology of Money" by Morgan Housel</li>
            <li>"Rich Dad Poor Dad" by Robert Kiyosaki</li>
            <li>"Your Money or Your Life" by Vicki Robin</li>
            <li>"The Simple Path to Wealth" by J. L. Collins</li>
            <li>"Thinking, Fast and Slow" by Daniel Kahneman</li>
          </ul>
        )}
        {!isBuffett && !isIcahn && !isWood && !isEmmaSmith && (
          <p className="text-sm">Books and articles recommended by {name}</p>
        )}
      </CardContent>
    </Card>
  );
};

export default RecommendedReading;
