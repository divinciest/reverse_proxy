import React, { useMemo } from 'react';
import { CardContent } from "@/components/ui/card";
import StockPickCard from './StockPickCard';
import { Skeleton } from '../ui/skeleton';
import { StockPickData } from '@/utils/stockPickService';
import { getBestFaviconUrl } from '@/utils/favicon';

interface ExpertStockPicksProps {
  isLoading: boolean;
  stockPicksData: StockPickData[];
}

const ExpertStockPicks: React.FC<ExpertStockPicksProps> = ({ isLoading, stockPicksData }) => {
  // Pre-calculate card dimensions to prevent layout shifts
  const cardPlaceholders = useMemo(() => 
    Array(4).fill(0).map((_, index) => (
      <div key={index} className="bg-gray-50 h-[180px] min-h-[180px] rounded-2xl border border-gray-100 shadow-sm">
        <div className="h-full flex items-center justify-center p-4">
          <div className="animate-pulse flex flex-col gap-4 w-full">
            <div className="flex gap-2 items-center">
              <div className="rounded-md bg-gray-200 h-10 w-10"></div>
            </div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-6 bg-gray-200 rounded w-1/2"></div>
            <div className="flex justify-between mt-auto">
              <div className="h-8 bg-gray-200 rounded-full w-24"></div>
              <div className="h-6 bg-gray-200 rounded-full w-6"></div>
            </div>
          </div>
        </div>
      </div>
    )), 
    [] // Empty dependency array ensures it's only created once
  );

  // Memoize the stock pick cards to prevent unnecessary re-renders
  const stockPickCards = useMemo(() => 
    stockPicksData.map((stock, index) => (
      <StockPickCard
        key={stock.symbol}
        symbol={stock.symbol}
        name={stock.name}
        price={stock.price}
        changePercent={stock.changePercent}
        imageUrl={getBestFaviconUrl(stock.name)}
      />
    )),
    [stockPicksData] // Only re-render when stockPicksData changes
  );

  return (
    <CardContent>
      <h3 className="text-xl font-medium mb-3">Top Stock Picks</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {isLoading ? cardPlaceholders : stockPickCards}
      </div>
    </CardContent>
  );
};

// Memoize the entire component to prevent unnecessary re-renders
export default React.memo(ExpertStockPicks);
