
import React, { useState } from 'react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip
} from 'recharts';
import { ChartContainer } from '../ui/chart';
import { cn } from '@/lib/utils';
import { formatToBillions } from '@/utils/formatUtils';
import PortfolioTooltip from './PortfolioTooltip';
import PortfolioItemsList from './PortfolioItemsList';
import PortfolioChartActions from './PortfolioChartActions';
import { PortfolioItem, PortfolioChartProps } from './PortfolioTypes';

const PortfolioChart: React.FC<PortfolioChartProps> = ({ 
  data, 
  portfolioDate = "2024-12-31",
  expertName,
  expertImage,
  className 
}) => {
  // Use all data immediately to prevent layout shifts
  const visibleItems = data.length;
  
  // Sort data by value in descending order
  const sortedData = [...data].sort((a, b) => b.value - a.value);
  
  // Calculate total portfolio value
  const totalValue = sortedData.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className={cn("w-full rounded-lg border bg-card shadow-sm", className)}>
      <div className="flex justify-between items-center p-4 border-b">
        <h3 className="text-xl font-serif">Portfolio Allocation</h3>
        <div className="text-sm text-muted-foreground">Portfolio Date: {portfolioDate}</div>
      </div>
      
      <div className="p-4">
        <PortfolioChartActions />
        
        <div className="h-[500px]">
          <ChartContainer
            className="h-full"
            config={Object.fromEntries(
              sortedData.map(item => [item.name, { color: item.color }])
            )}
          >
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sortedData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={100}
                  outerRadius={160}
                  paddingAngle={1}
                  isAnimationActive={false}
                  animationBegin={0}
                  animationDuration={0}
                  label={({ name, value, cx, cy, midAngle, innerRadius, outerRadius, amount }) => {
                    const RADIAN = Math.PI / 180;
                    const radius = 25 + innerRadius + (outerRadius - innerRadius);
                    const x = cx + radius * Math.cos(-midAngle * RADIAN);
                    const y = cy + radius * Math.sin(-midAngle * RADIAN);
                    
                    // Short version of name for labels
                    const shortName = name.length > 10 ? name.substring(0, 10) + "..." : name;
                    
                    return (
                      <g>
                        <text
                          x={x}
                          y={y - 15}
                          fill="#666"
                          textAnchor={x > cx ? 'start' : 'end'}
                          dominantBaseline="central"
                          fontSize="12px"
                        >
                          {formatToBillions(amount)}
                        </text>
                        <text
                          x={x}
                          y={y + 5}
                          fill="#666"
                          textAnchor={x > cx ? 'start' : 'end'}
                          dominantBaseline="central"
                          fontSize="12px"
                        >
                          {shortName}
                        </text>
                        <text
                          x={x}
                          y={y + 25}
                          fill="#000"
                          fontWeight="bold"
                          textAnchor={x > cx ? 'start' : 'end'}
                          dominantBaseline="central"
                          fontSize="12px"
                        >
                          {`${value.toFixed(2)}%`}
                        </text>
                      </g>
                    );
                  }}
                >
                  {sortedData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.color} 
                      opacity={0.9}
                    />
                  ))}
                </Pie>
                <Tooltip content={<PortfolioTooltip />} />
                
                {/* Center image with placeholder to prevent layout shift */}
                {expertImage && (
                  <image 
                    href={expertImage} 
                    x="50%" 
                    y="50%" 
                    height="140" 
                    width="140" 
                    transform="translate(-70, -70)"
                    clipPath="circle(70px at center)"
                  />
                )}
                
                {/* Total value text */}
                {!expertImage && (
                  <>
                    <text x="50%" y="45%" textAnchor="middle" fontSize="12px" className="fill-gray-900 font-bold">
                      {formatToBillions(totalValue)}
                    </text>
                    <text x="50%" y="55%" textAnchor="middle" fontSize="12px" className="fill-gray-600">
                      Total Portfolio Value
                    </text>
                  </>
                )}
              </PieChart>
            </ResponsiveContainer>
          </ChartContainer>
        </div>
        
        <PortfolioItemsList items={sortedData} />
      </div>
    </div>
  );
};

export default PortfolioChart;
