
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { SectorData } from '@/data/expertSectors';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { ChartContainer } from '@/components/ui/chart';
import { BarLegend } from './BarLegend';

interface SectorChartProps {
  expertName: string;
  sectorData: SectorData[];
  className?: string;
}

const SectorChart = ({ expertName, sectorData, className = '' }: SectorChartProps) => {
  // Sort sectors by weighting in descending order for better visualization
  const sortedData = [...sectorData].sort((a, b) => b.weighting - a.weighting);
  
  // Generate colors for the pie chart segments
  const COLORS = [
    '#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', 
    '#82CA9D', '#8DD1E1', '#A4DE6C', '#D0ED57', '#FAAAA3'
  ];
  
  // Prepare data for the pie chart
  const pieData = sortedData.map(item => ({
    name: item.sector,
    value: item.weighting,
    sellImpact: item.sellImpact,
    buyImpact: item.buyImpact,
  }));

  // Custom tooltip to show additional information
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-2 border border-gray-200 shadow-sm rounded-md text-xs">
          <p className="font-medium">{data.name}</p>
          <p className="text-blue-600">Weight: {data.value.toFixed(2)}%</p>
          {data.sellImpact && <p className="text-red-600">Sell: {data.sellImpact.toFixed(2)}%</p>}
          {data.buyImpact && <p className="text-green-600">Buy: +{data.buyImpact.toFixed(2)}%</p>}
        </div>
      );
    }
    return null;
  };

  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-serif">{expertName}'s Portfolio</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-4">
          <BarLegend />
          
          <div className="h-64 w-full">
            <ChartContainer
              className="h-full"
              config={Object.fromEntries(
                sortedData.map((item, index) => [item.sector, { color: COLORS[index % COLORS.length] }])
              )}
            >
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={30}
                    outerRadius={80}
                    paddingAngle={1}
                    dataKey="value"
                    label={({ name, value, cx, cy, midAngle, innerRadius, outerRadius }) => {
                      const RADIAN = Math.PI / 180;
                      const radius = 25 + innerRadius + (outerRadius - innerRadius);
                      const x = cx + radius * Math.cos(-midAngle * RADIAN);
                      const y = cy + radius * Math.sin(-midAngle * RADIAN);
                      
                      // For very small segments, don't render labels
                      if (value < 5) return null;
                      
                      const shortName = name.length > 10 ? name.substring(0, 8) + "..." : name;
                      return (
                        <text 
                          x={x} 
                          y={y} 
                          fill="#333" 
                          textAnchor={x > cx ? 'start' : 'end'} 
                          dominantBaseline="central"
                          fontSize="11px"
                        >
                          {shortName} ({value.toFixed(1)}%)
                        </text>
                      );
                    }}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
          
          <div className="grid grid-cols-2 gap-2 text-xs">
            {sortedData.map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: COLORS[index % COLORS.length] }}
                />
                <div className="flex-1 truncate pr-1">
                  <span className="truncate">{item.sector}</span>
                </div>
                <div className="flex items-center gap-1 whitespace-nowrap">
                  <span className="font-mono font-medium">{item.weighting.toFixed(1)}%</span>
                  {item.sellImpact && (
                    <span className="text-xs font-mono text-red-600">
                      {item.sellImpact.toFixed(1)}%
                    </span>
                  )}
                  {item.buyImpact && (
                    <span className="text-xs font-mono text-green-600">
                      +{item.buyImpact.toFixed(1)}%
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SectorChart;
