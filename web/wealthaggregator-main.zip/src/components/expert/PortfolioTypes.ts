
export interface PortfolioItem {
  name: string;
  value: number;
  amount: number;
  color: string;
}

export interface PortfolioChartProps {
  data: PortfolioItem[];
  portfolioDate?: string;
  expertName: string;
  expertImage?: string;
  className?: string;
}
