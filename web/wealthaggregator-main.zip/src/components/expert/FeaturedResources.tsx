
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { ExternalLink } from "lucide-react";

interface FeaturedResourcesProps {
  name: string;
}

const FeaturedResources: React.FC<FeaturedResourcesProps> = ({ name }) => {
  // Check which expert's resources to display
  const isBuffett = name === "Warren Buffett";
  const isIcahn = name === "Carl Icahn";
  const isWood = name === "Cathie Wood";
  
  // If not one of our featured experts, don't show anything
  if (!isBuffett && !isIcahn && !isWood) {
    return null;
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-xl font-serif">Featured Resources</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {isBuffett && (
            <>
              <div>
                <h3 className="text-sm font-medium mb-1">Latest Interview</h3>
                <a 
                  href="https://www.youtube.com/watch?v=BTITh5qfR8A" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-sm text-blue-600 hover:underline"
                >
                  Watch on YouTube <ExternalLink size={14} />
                </a>
              </div>
              
              <div>
                <h3 className="text-sm font-medium mb-1">2024 Annual Letter</h3>
                <a 
                  href="https://www.berkshirehathaway.com/letters/2024ltr.pdf" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-sm text-blue-600 hover:underline"
                >
                  Download PDF <ExternalLink size={14} />
                </a>
              </div>
            </>
          )}

          {isIcahn && (
            <>
              <div>
                <h3 className="text-sm font-medium mb-1">Latest Interview</h3>
                <a 
                  href="https://example.com/icahn-interview-2025" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-sm text-blue-600 hover:underline"
                >
                  Watch on CNBC <ExternalLink size={14} />
                </a>
              </div>
              
              <div>
                <h3 className="text-sm font-medium mb-1">2024 Shareholder Letter</h3>
                <a 
                  href="https://example.com/icahn-shareholder-letter-2024" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-sm text-blue-600 hover:underline"
                >
                  Download PDF <ExternalLink size={14} />
                </a>
              </div>
            </>
          )}

          {isWood && (
            <>
              <div>
                <h3 className="text-sm font-medium mb-1">Latest Research</h3>
                <a 
                  href="https://example.com/ark-big-ideas-2025" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-sm text-blue-600 hover:underline"
                >
                  ARK's Big Ideas 2025 <ExternalLink size={14} />
                </a>
              </div>
              
              <div>
                <h3 className="text-sm font-medium mb-1">Innovation Podcast</h3>
                <a 
                  href="https://example.com/ark-podcast" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-sm text-blue-600 hover:underline"
                >
                  Listen Now <ExternalLink size={14} />
                </a>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default FeaturedResources;
