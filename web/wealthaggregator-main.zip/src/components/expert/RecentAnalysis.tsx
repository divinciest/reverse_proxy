
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

interface RecentAnalysisProps {
  expertName: string;
}

const RecentAnalysis: React.FC<RecentAnalysisProps> = ({ expertName }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl font-serif">Recent Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground mb-6">
          Recent market analysis and investment insights from {expertName} will appear here.
        </p>
      </CardContent>
    </Card>
  );
};

export default RecentAnalysis;
