
import React from 'react';
import { ArrowUp, ArrowDown, PlusCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';

interface StockPickCardProps {
  symbol: string;
  name: string;
  price: number;
  changePercent: number;
  imageUrl?: string;
}

const StockPickCard: React.FC<StockPickCardProps> = ({ 
  symbol,
  name,
  price, 
  changePercent,
  imageUrl
}) => {
  const isPositive = changePercent >= 0;
  
  // Convert stock symbol to lowercase for the URL path
  const companyPath = `/company/${symbol.toLowerCase()}`;

  return (
    <Link to={companyPath} className="block">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 flex flex-col gap-2 min-h-[180px] hover:shadow-md transition-shadow">
        {/* Company logo */}
        <div className="flex items-center gap-2">
          {imageUrl ? (
            <img 
              src={imageUrl} 
              alt={name} 
              className="w-8 h-8 object-contain"
              loading="eager"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                target.parentNode.textContent = symbol.slice(0, 4);
              }}
            />
          ) : (
            <span className="text-sm font-semibold text-blue-500">
              {symbol.slice(0, 4)}
            </span>
          )}
        </div>
        
        {/* Company name */}
        <h3 className="text-lg font-medium line-clamp-1">{name}</h3>
        
        {/* Stock price */}
        <div className="text-2xl font-semibold">${price.toFixed(2)}</div>
        
        {/* Change percentage and action button */}
        <div className="flex justify-between items-center mt-auto">
          <div 
            className={cn(
              "py-1 px-3 rounded-full flex items-center gap-1",
              isPositive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
            )}
          >
            {isPositive ? (
              <ArrowUp className="h-4 w-4" />
            ) : (
              <ArrowDown className="h-4 w-4" />
            )}
            <span className="font-medium">{Math.abs(changePercent).toFixed(2)}%</span>
          </div>
          
          <button 
            className="text-gray-400 hover:text-gray-600 transition-colors" 
            aria-label="Add to watchlist"
            onClick={(e) => {
              e.preventDefault(); // Prevent navigation when clicking the button
            }}
          >
            <PlusCircle className="h-6 w-6" />
          </button>
        </div>
      </div>
    </Link>
  );
};

export default StockPickCard;
