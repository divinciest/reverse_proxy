
import React from 'react';
import { Download, Share, Maximize } from 'lucide-react';
import { Button } from '../ui/button';

const PortfolioChartActions: React.FC = () => {
  return (
    <div className="flex justify-end gap-2 mb-4">
      <Button variant="outline" size="sm">
        <Download className="h-4 w-4 mr-2" />
        Download
      </Button>
      <Button variant="outline" size="sm">
        <Share className="h-4 w-4 mr-2" />
        Share
      </Button>
      <Button variant="outline" size="sm">
        <Maximize className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default PortfolioChartActions;
