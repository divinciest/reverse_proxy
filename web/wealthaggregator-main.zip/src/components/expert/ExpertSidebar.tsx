
import React from 'react';
import InvestmentStrategy from './InvestmentStrategy';
import LatestNews from './LatestNews';
import FeaturedResources from './FeaturedResources';
import RecommendedReading from './RecommendedReading';
import { getExpertNews } from '@/data/expertNews';

interface ExpertSidebarProps {
  name: string;
}

const ExpertSidebar: React.FC<ExpertSidebarProps> = ({ name }) => {
  // Get news for the current expert
  const expertNews = getExpertNews(name);

  return (
    <>
      <InvestmentStrategy name={name} />
      
      {expertNews.length > 0 && (
        <LatestNews 
          expertName={name}
          news={expertNews}
        />
      )}
      
      <FeaturedResources name={name} />
      
      <RecommendedReading name={name} />
    </>
  );
};

export default ExpertSidebar;
