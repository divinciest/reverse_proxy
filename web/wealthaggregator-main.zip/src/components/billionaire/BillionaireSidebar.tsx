import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Billionaire, BillionaireNews } from '@/data/billionaire';
import { CalendarIcon, Newspaper, Link, ExternalLink } from "lucide-react";
import { formatDistanceToNow } from 'date-fns';

interface BillionaireSidebarProps {
  billionaire: Billionaire;
  newsItems: BillionaireNews[];
}

const BillionaireSidebar: React.FC<BillionaireSidebarProps> = ({ billionaire, newsItems }) => {
  return (
    <>
      <BillionaireNetWorthCard billionaire={billionaire} />
      {newsItems.length > 0 && (
        <BillionaireNewsCard billionaire={billionaire} newsItems={newsItems} />
      )}
      <BillionaireResourcesCard billionaire={billionaire} />
    </>
  );
};

// Card showing net worth statistics
const BillionaireNetWorthCard: React.FC<{ billionaire: Billionaire }> = ({ billionaire }) => {
  // Format net worth for display
  const formatLargeNumber = (num: number): string => {
    return num.toLocaleString('en-US', { maximumFractionDigits: 1 });
  };

  // Calculate how much money earned per day, hour, minute
  const earningsPerDay = (billionaire.change > 0) ? billionaire.change * 1000000000 : 0;
  const earningsPerHour = earningsPerDay / 24;
  const earningsPerMinute = earningsPerHour / 60;
  const earningsPerSecond = earningsPerMinute / 60;

  return (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-serif">Net Worth Statistics</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
            <div className="text-sm text-gray-500 mb-1">Total Net Worth</div>
            <div className="text-2xl font-bold">${formatLargeNumber(billionaire.netWorth)} Billion</div>
            <div className="text-sm text-gray-500 mt-1">${formatLargeNumber(billionaire.netWorth * 1000)} Million</div>
          </div>

          {billionaire.change > 0 && (
            <div className="bg-green-50 p-3 rounded-lg border border-green-200">
              <div className="text-sm text-green-700 mb-1">Income Rate (Today)</div>
              <div className="space-y-2 text-green-800">
                <div className="flex justify-between">
                  <span>Per Day:</span>
                  <span className="font-semibold">${formatLargeNumber(earningsPerDay)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Per Hour:</span>
                  <span className="font-semibold">${formatLargeNumber(earningsPerHour)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Per Minute:</span>
                  <span className="font-semibold">${formatLargeNumber(earningsPerMinute)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Per Second:</span>
                  <span className="font-semibold">${formatLargeNumber(earningsPerSecond)}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

// News card showing recent articles
const BillionaireNewsCard: React.FC<{ billionaire: Billionaire; newsItems: BillionaireNews[] }> = ({ 
  billionaire, 
  newsItems 
}) => {
  // Format date to relative time (e.g. "2 days ago")
  const formatRelativeDate = (dateString: string): string => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      return dateString;
    }
  };

  return (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-serif flex items-center">
          <Newspaper className="mr-2 h-5 w-5" />
          Latest News
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-4">
          {newsItems.map((item) => (
            <li key={item.id} className="border-b border-gray-100 last:border-0 pb-3 last:pb-0">
              <div className="flex items-center text-xs text-gray-500 mb-1">
                <CalendarIcon className="h-3 w-3 mr-1" />
                <span>{formatRelativeDate(item.date)}</span>
                <span className="mx-1">•</span>
                <span>{item.source}</span>
              </div>
              <a 
                href={item.url} 
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm font-medium hover:underline group flex items-start"
              >
                {item.title}
                <ExternalLink className="h-3 w-3 ml-1 opacity-0 group-hover:opacity-100 shrink-0 mt-0.5" />
              </a>
              <div className="text-xs text-gray-600 mt-1">{item.summary}</div>
              
              {item.relatedCompanies.length > 0 && (
                <div className="mt-2 flex gap-1 flex-wrap">
                  {item.relatedCompanies.map(company => (
                    <span 
                      key={company} 
                      className="text-xs bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded"
                    >
                      {company}
                    </span>
                  ))}
                </div>
              )}
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};

// Resources card with relevant links
const BillionaireResourcesCard: React.FC<{ billionaire: Billionaire }> = ({ billionaire }) => {
  // Generate Forbes profile URL
  const getForbesUrl = (name: string): string => {
    const slug = name.toLowerCase().replace(/\s+/g, '-');
    return `https://www.forbes.com/profile/${slug}/`;
  };

  return (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-serif flex items-center">
          <Link className="mr-2 h-5 w-5" />
          Related Resources
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          <li>
            <a 
              href={getForbesUrl(billionaire.name)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-2 bg-gray-50 rounded hover:bg-gray-100 transition-colors"
            >
              <div className="mr-3 bg-blue-100 h-8 w-8 rounded-full flex items-center justify-center">
                <span className="font-bold text-blue-800">F</span>
              </div>
              <div className="flex-1">
                <div className="text-sm font-medium">Forbes Profile</div>
                <div className="text-xs text-gray-500">Official Forbes billionaire profile</div>
              </div>
              <ExternalLink className="h-4 w-4 text-gray-400" />
            </a>
          </li>
          
          <li>
            <a 
              href={`https://www.google.com/search?q=${encodeURIComponent(billionaire.name)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-2 bg-gray-50 rounded hover:bg-gray-100 transition-colors"
            >
              <div className="mr-3 bg-red-100 h-8 w-8 rounded-full flex items-center justify-center">
                <span className="font-bold text-red-800">G</span>
              </div>
              <div className="flex-1">
                <div className="text-sm font-medium">Google Search</div>
                <div className="text-xs text-gray-500">Latest news and information</div>
              </div>
              <ExternalLink className="h-4 w-4 text-gray-400" />
            </a>
          </li>
          
          <li>
            <a 
              href={`https://en.wikipedia.org/wiki/${encodeURIComponent(billionaire.name)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-2 bg-gray-50 rounded hover:bg-gray-100 transition-colors"
            >
              <div className="mr-3 bg-gray-100 h-8 w-8 rounded-full flex items-center justify-center">
                <span className="font-bold text-gray-800">W</span>
              </div>
              <div className="flex-1">
                <div className="text-sm font-medium">Wikipedia</div>
                <div className="text-xs text-gray-500">Detailed biography and background</div>
              </div>
              <ExternalLink className="h-4 w-4 text-gray-400" />
            </a>
          </li>
        </ul>
      </CardContent>
    </Card>
  );
};

export default BillionaireSidebar;
