import React from "react";
import { Link } from "react-router-dom";
import { ExternalLink, Building } from "lucide-react";
import { CardContent } from "@/components/ui/card";
import { Billionaire } from "@/data/billionaire";

interface BillionaireCompaniesProps {
  billionaire: Billionaire;
  companyLogos: Record<string, string>;
}

const BillionaireCompanies: React.FC<BillionaireCompaniesProps> = ({ 
  billionaire, 
  companyLogos 
}) => {
  return (
    <CardContent className="border-t pt-6">
      <h3 className="text-lg font-medium mb-4">Major Companies & Investments</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {billionaire.companies.map((company, index) => {
          const companyId = billionaire.companyIds[index] || undefined;
          const logo = companyLogos[companyId || ''] || undefined;
          
          return (
            <div key={company} className="flex items-center p-3 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center justify-center h-10 w-10 bg-white rounded-md shadow-sm border border-gray-200 mr-3">
                {logo ? (
                  <img 
                    src={logo} 
                    alt={company} 
                    className="h-6 w-6 object-contain"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      target.parentElement!.innerHTML = company.substring(0, 1);
                    }}
                  />
                ) : (
                  <Building className="h-5 w-5 text-gray-400" />
                )}
              </div>
              
              <div className="flex-1">
                <div className="font-medium">{company}</div>
                <div className="text-xs text-muted-foreground">
                  {billionaire.industries[Math.min(index, billionaire.industries.length - 1)]}
                </div>
              </div>
              
              {companyId && (
                <Link 
                  to={`/company/${companyId}`} 
                  className="text-sm text-blue-600 flex items-center hover:text-blue-800 hover:underline"
                >
                  View <ExternalLink className="h-3 w-3 ml-1" />
                </Link>
              )}
            </div>
          );
        })}
      </div>
      
      <div className="mt-4 text-sm text-muted-foreground">
        <p>
          Note: This list includes major companies associated with {billionaire.name} through ownership, 
          founding, or significant investment.
        </p>
      </div>
    </CardContent>
  );
};

export default BillionaireCompanies;
