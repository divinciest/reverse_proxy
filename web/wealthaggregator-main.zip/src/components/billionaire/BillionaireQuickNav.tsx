
import React from "react";
import { Link } from "react-router-dom";
import { billionaires } from "@/data/billionaire";
import { Avatar } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { CircleDollarSign, Search } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface BillionaireQuickNavProps {
  currentBillionaireId: string;
}

const BillionaireQuickNav: React.FC<BillionaireQuickNavProps> = ({ currentBillionaireId }) => {
  return (
    <Card className="mb-6 overflow-hidden">
      <ScrollArea className="w-full">
        <div className="flex py-3 px-1 gap-3 min-w-full overflow-x-auto">
          {/* Search button */}
          <Link 
            to="/billionaires" 
            className="flex flex-col items-center min-w-[80px] group"
          >
            <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-1 group-hover:bg-primary/20 transition-colors">
              <Search className="h-5 w-5 text-primary" />
            </div>
            <span className="text-xs text-center font-medium">Search</span>
          </Link>

          {/* Billionaire navigation icons */}
          {billionaires.map((billionaire) => (
            <Link 
              key={billionaire.id}
              to={`/billionaire/${billionaire.id}`}
              className={`flex flex-col items-center min-w-[80px] ${billionaire.id === currentBillionaireId ? 'opacity-100' : 'group hover:opacity-100'} ${billionaire.id === currentBillionaireId ? '' : 'opacity-80'}`}
            >
              <Avatar className={`h-12 w-12 rounded-full mb-1 border-2 ${billionaire.id === currentBillionaireId ? 'border-primary' : 'border-transparent group-hover:border-primary/50'}`}>
                {billionaire.imageUrl ? (
                  <img 
                    src={billionaire.imageUrl} 
                    alt={billionaire.name} 
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <CircleDollarSign className="h-6 w-6 text-muted-foreground" />
                )}
              </Avatar>
              <span className="text-xs text-center font-medium line-clamp-2">{billionaire.name}</span>
            </Link>
          ))}
        </div>
      </ScrollArea>
    </Card>
  );
};

export default BillionaireQuickNav;
