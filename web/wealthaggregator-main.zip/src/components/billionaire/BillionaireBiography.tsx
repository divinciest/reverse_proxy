
import React from "react";
import { TrendingUp, TrendingDown, CircleDollarSign } from "lucide-react";
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";

interface BillionaireBiographyProps {
  name: string;
  rank: number;
  netWorth: number;
  change: number;
  changePercent: number;
  source: string;
  country: string;
  age: number;
  bio: string;
  imageUrl?: string;
}

const BillionaireBiography: React.FC<BillionaireBiographyProps> = ({
  name,
  rank,
  netWorth,
  change,
  changePercent,
  source,
  country,
  age,
  bio,
  imageUrl
}) => {
  // Format net worth as currency
  const formatNetWorth = (amount: number): string => {
    return `$${amount.toFixed(1)} billion`;
  };

  // Format change as currency with sign
  const formatChange = (amount: number): string => {
    const sign = amount >= 0 ? '+' : '';
    return `${sign}$${amount.toFixed(1)} billion`;
  };

  return (
    <>
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
          <Avatar className="h-24 w-24 rounded-md shadow-sm border border-gray-200">
            {imageUrl ? (
              <img src={imageUrl} alt={name} className="h-full w-full object-cover" />
            ) : (
              <CircleDollarSign className="h-12 w-12 text-gray-400" />
            )}
          </Avatar>
          
          <div className="flex-1">
            <div className="flex flex-col md:flex-row md:items-baseline gap-2 md:gap-4">
              <CardTitle className="text-3xl font-serif">{name}</CardTitle>
              <div className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm font-medium inline-flex">
                Rank #{rank}
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4 mt-2">
              <div className="text-xl font-bold">{formatNetWorth(netWorth)}</div>
              <div className={`flex items-center text-base ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {change >= 0 ? (
                  <TrendingUp size={18} className="mr-1" />
                ) : (
                  <TrendingDown size={18} className="mr-1" />
                )}
                <span>
                  {formatChange(change)} ({changePercent.toFixed(2)}%)
                </span>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-3 mt-2 text-sm text-muted-foreground">
              <div>Source: {source}</div>
              <div>•</div>
              <div>Country: {country}</div>
              <div>•</div>
              <div>Age: {age}</div>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-6">
        <h3 className="text-lg font-medium mb-2">Biography</h3>
        <p className="text-gray-700 leading-relaxed">{bio}</p>
      </CardContent>
    </>
  );
};

export default BillionaireBiography;
