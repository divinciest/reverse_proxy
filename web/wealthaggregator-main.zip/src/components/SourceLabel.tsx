
import React from "react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface SourceLabelProps {
  source: string;
  sourceUrl?: string;
  category?: string;
  className?: string;
  sourceIcon?: string;
}

const SourceLabel = ({ source, sourceUrl, category, className, sourceIcon }: SourceLabelProps) => {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      {sourceIcon && (
        <Avatar className="h-6 w-6">
          <AvatarImage src={sourceIcon} alt={source} />
          <AvatarFallback className="text-xs bg-gray-100">
            {source.substring(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
      )}
      {sourceUrl ? (
        <a href={sourceUrl} target="_blank" rel="noopener noreferrer" className="font-medium text-sm hover:underline">
          {source}
        </a>
      ) : (
        <span className="font-medium text-sm">{source}</span>
      )}
      {category && (
        <>
          <span className="text-muted-foreground">·</span>
          <span className="text-sm text-muted-foreground">{category}</span>
        </>
      )}
    </div>
  );
};

export default SourceLabel;
