
import React from "react";
import { Button } from "@/components/ui/button";
import { Calendar, Clock } from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuGroup,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";

interface DateRangeFilterProps {
  dateRange?: { start: Date; end: Date } | null;
  onDateRangeChange?: (dateRange: { start: Date; end: Date } | null) => void;
}

const DateRangeFilter = ({ dateRange, onDateRangeChange }: DateRangeFilterProps) => {
  // Preset date ranges
  const setLast7Days = () => {
    const end = new Date();
    const start = new Date();
    start.setDate(start.getDate() - 7);
    onDateRangeChange?.({ start, end });
  };

  const setLast30Days = () => {
    const end = new Date();
    const start = new Date();
    start.setDate(start.getDate() - 30);
    onDateRangeChange?.({ start, end });
  };

  const setThisMonth = () => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    const end = new Date();
    onDateRangeChange?.({ start, end });
  };

  const clearDateRange = () => {
    onDateRangeChange?.(null);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="ml-2 flex gap-2 items-center">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          {dateRange ? (
            <span className="text-sm">
              {format(dateRange.start, "MMM d")} - {format(dateRange.end, "MMM d, yyyy")}
            </span>
          ) : (
            <span className="text-sm text-muted-foreground">Custom Range</span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuGroup>
          <DropdownMenuItem onClick={setLast7Days}>Last 7 days</DropdownMenuItem>
          <DropdownMenuItem onClick={setLast30Days}>Last 30 days</DropdownMenuItem>
          <DropdownMenuItem onClick={setThisMonth}>This month</DropdownMenuItem>
          {dateRange && <DropdownMenuItem onClick={clearDateRange}>Clear selection</DropdownMenuItem>}
        </DropdownMenuGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default DateRangeFilter;
