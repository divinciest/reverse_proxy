
import React from "react";
import { cn } from "@/lib/utils";
import { TrendingDown, Minus, TrendingUp } from "lucide-react";

interface SentimentBadgeProps {
  sentiment: "bullish" | "neutral" | "bearish";
  className?: string;
  showIcon?: boolean;
  showLabel?: boolean;
  size?: "sm" | "md" | "lg";
}

const SentimentBadge = ({
  sentiment,
  className,
  showIcon = true,
  showLabel = true,
  size = "md",
}: SentimentBadgeProps) => {
  const getSentimentColor = () => {
    switch (sentiment) {
      case "bullish":
        return "bg-green-100 text-bullish border-bullish";
      case "neutral":
        return "bg-gray-100 text-neutral border-neutral-600";
      case "bearish":
        return "bg-red-100 text-bearish border-bearish";
      default:
        return "bg-gray-100 text-gray-700 border-gray-300";
    }
  };

  const getIcon = () => {
    const iconSize = size === "sm" ? 14 : size === "lg" ? 18 : 16;
    
    switch (sentiment) {
      case "bullish":
        return <TrendingUp size={iconSize} className="mr-1" />;
      case "neutral":
        return <Minus size={iconSize} className="mr-1" />;
      case "bearish":
        return <TrendingDown size={iconSize} className="mr-1" />;
      default:
        return null;
    }
  };

  const getLabel = () => {
    return sentiment.charAt(0).toUpperCase() + sentiment.slice(1);
  };

  return (
    <div
      className={cn(
        "inline-flex items-center rounded-full text-xs font-medium border",
        size === "sm" ? "px-1.5 py-0.5 text-xs" : 
        size === "lg" ? "px-2.5 py-1.5 text-sm" : 
        "px-2 py-1 text-xs",
        getSentimentColor(),
        className
      )}
    >
      {showIcon && getIcon()}
      {showLabel && getLabel()}
    </div>
  );
};

export default SentimentBadge;
