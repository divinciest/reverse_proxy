
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ChartData } from "@/utils/economicChartsService";
import EconomicChart from "./EconomicChart";

interface ChartCardProps {
  chart: ChartData;
}

const ChartCard = ({ chart }: ChartCardProps) => {
  return (
    <Link to={`/charts/${chart.id}`}>
      <Card className="overflow-hidden transition-all hover:shadow-md cursor-pointer h-full">
        <CardContent className="p-0">
          <div className="p-4 pb-2">
            <h3 className="text-lg font-semibold mb-1">{chart.name}</h3>
            <p className="text-sm text-muted-foreground mb-1">
              {chart.category} • {chart.timeframe}
            </p>
          </div>
          <div className="px-3">
            <EconomicChart 
              data={chart.dataPoints} 
              height={160} 
              showGrid={false}
            />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};

export default ChartCard;
