
import React from "react";
import { Button } from "@/components/ui/button";

interface CategoryFilterProps {
  categories: string[];
  activeCategory: string;
  onCategoryChange: (category: string) => void;
}

const CategoryFilter = ({
  categories,
  activeCategory,
  onCategoryChange
}: CategoryFilterProps) => {
  return (
    <div className="flex flex-wrap gap-2 my-4">
      <Button
        variant={activeCategory === "All" ? "default" : "outline"}
        size="sm"
        onClick={() => onCategoryChange("All")}
        className="border-gray-300"
      >
        All Charts
      </Button>
      
      {categories.map((category) => (
        <Button
          key={category}
          variant={activeCategory === category ? "default" : "outline"}
          size="sm"
          onClick={() => onCategoryChange(category)}
          className="border-gray-300"
        >
          {category}
        </Button>
      ))}
    </div>
  );
};

export default CategoryFilter;
