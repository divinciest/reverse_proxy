
import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from "recharts";
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart";

interface EconomicChartProps {
  data: Array<{ date: string; value: number }>;
  title?: string;
  height?: number;
  showGrid?: boolean;
  showRecessions?: boolean;
  color?: string;
  className?: string;
}

const EconomicChart = ({
  data,
  title,
  height = 300,
  showGrid = true,
  showRecessions = false,
  color = "#2563eb",
  className = ""
}: EconomicChartProps) => {
  // Format date for display
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  // Format value for y-axis
  const formatYAxis = (value: number) => {
    // If value is greater than 1000, show as K
    if (value >= 1000) {
      return `${(value / 1000).toFixed(1)}K`;
    }
    return value.toFixed(1);
  };

  // Find recession periods (years divisible by 10)
  const recessionPeriods = data
    .filter((point, index) => {
      const year = new Date(point.date).getFullYear();
      return year % 10 >= 8 && year % 10 <= 9;
    })
    .map(point => point.date);

  return (
    <div className={`w-full ${className}`}>
      {title && <h3 className="text-lg font-medium mb-2">{title}</h3>}
      <div style={{ width: '100%', height: `${height}px` }}>
        <ChartContainer
          config={{
            value: {
              theme: {
                light: color,
                dark: color
              }
            }
          }}
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{ top: 10, right: 30, left: 20, bottom: 30 }}
            >
              {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />}
              <XAxis
                dataKey="date"
                tickFormatter={(dateStr) => {
                  const date = new Date(dateStr);
                  return date.getFullYear().toString();
                }}
                tick={{ fontSize: 12 }}
                interval="preserveStartEnd"
                minTickGap={50}
              />
              <YAxis 
                tickFormatter={formatYAxis}
                tick={{ fontSize: 12 }}
                domain={['auto', 'auto']}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white border border-gray-200 p-2 rounded shadow-sm text-xs">
                        <p className="font-semibold">{formatDate(label)}</p>
                        <p className="text-[var(--color-value)]">
                          Value: {payload[0].value}
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Line
                type="monotone"
                dataKey="value"
                stroke="var(--color-value)"
                dot={false}
                strokeWidth={2}
              />
              
              {showRecessions && recessionPeriods.map((date, index) => (
                <ReferenceLine
                  key={`recession-${index}`}
                  x={date}
                  stroke="#d1d5db"
                  strokeWidth={8}
                  strokeOpacity={0.2}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
      </div>
    </div>
  );
};

export default EconomicChart;
