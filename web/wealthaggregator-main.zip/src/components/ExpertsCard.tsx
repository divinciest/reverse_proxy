
import React from "react";
import { Avatar } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

// Define the expert data structure
interface Expert {
  id: string;
  name: string;
  imageUrl: string;
  changePercentage: number;
  specialty: string;
}

// Sample experts data
const experts: Expert[] = [
  {
    id: "warren-buffett",
    name: "Warren Buffett",
    imageUrl: "/lovable-uploads/ecd851fe-cc7e-4e84-8a01-516b2b3fad96.png",
    changePercentage: 1.25,
    specialty: "Value Investing"
  },
  {
    id: "carl-icahn",
    name: "Carl Icahn",
    imageUrl: "/lovable-uploads/6cac2ef1-c8a4-4b34-91a5-e39350000214.png",
    changePercentage: 0.75,
    specialty: "Activist Investing"
  },
  {
    id: "cathie-wood",
    name: "Cathie Wood",
    imageUrl: "/lovable-uploads/25661a83-dd08-471b-8b53-df4c8bd950b1.png",
    changePercentage: -0.50,
    specialty: "Innovation Investing"
  }
];

const ExpertsCard = () => {
  return (
    <Card>
      <CardHeader className="pb-2 pt-4">
        <CardTitle className="text-xl font-serif">Top Experts</CardTitle>
      </CardHeader>
      <CardContent className="pt-2 p-0">
        <div className="grid grid-cols-1 divide-y">
          {experts.map((expert) => (
            <Link key={expert.id} to={`/expert/${expert.id}`} className="px-4 py-3 hover:bg-gray-50 transition-colors block relative">
              <div className="relative">
                <div className={`absolute right-0 top-0 text-sm font-semibold px-2 py-1 rounded-md ${
                  expert.changePercentage < 0 ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"
                }`}>
                  {expert.changePercentage > 0 ? "+" : ""}
                  {expert.changePercentage.toFixed(2)}%
                </div>
                
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-16 w-16 mb-2">
                    <img
                      src={expert.imageUrl}
                      alt={expert.name}
                      className="h-full w-full object-cover"
                    />
                  </Avatar>
                  <h3 className="font-medium text-base">{expert.name}</h3>
                  <p className="text-sm text-muted-foreground">{expert.specialty}</p>
                </div>
              </div>
              
              <ArrowUpRight className="h-4 w-4 text-gray-400 absolute top-3 right-3 group-hover:text-primary transition-colors" />
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ExpertsCard;
