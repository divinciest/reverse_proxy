
import React from "react";
import { Author } from "@/data/authors";

interface AboutAuthorProps {
  author: Author;
}

const AboutAuthor = ({ author }: AboutAuthorProps) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h2 className="text-xl font-serif font-bold mb-4 border-b pb-2">
        About {author.name}
      </h2>
      
      {author.imageUrl && (
        <div className="mb-4">
          <img 
            src={author.imageUrl} 
            alt={author.name} 
            className="w-full h-auto rounded-md object-cover aspect-video"
          />
        </div>
      )}
      
      <p className="text-gray-700 text-sm">{author.bio}</p>
      
      {author.twitterHandle && (
        <div className="mt-3">
          <a 
            href={`https://twitter.com/${author.twitterHandle}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary hover:underline text-sm"
          >
            @{author.twitterHandle}
          </a>
        </div>
      )}
    </div>
  );
};

export default AboutAuthor;
