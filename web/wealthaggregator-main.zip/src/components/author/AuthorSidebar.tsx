
import React from "react";
import { Author } from "@/data/authors";
import { Article } from "@/data/types";
import { Button } from "@/components/ui/button";
import RecentArticles from "./RecentArticles";
import AboutAuthor from "./AboutAuthor";

interface AuthorSidebarProps {
  author: Author;
  articles: Article[];
}

const AuthorSidebar = ({ author, articles }: AuthorSidebarProps) => {
  // Use the top 5 articles for the sidebar
  const recentArticles = articles.slice(0, 5);
  
  return (
    <div className="space-y-6">
      <AboutAuthor author={author} />
      
      <div className="bg-[#e9dbbd] p-4 rounded-lg shadow-sm">
        <h2 className="text-lg font-semibold mb-2">Subscribe to {author.name}'s newsletter</h2>
        <p className="text-sm text-muted-foreground mb-3">
          Get the latest articles delivered straight to your inbox.
        </p>
        <Button className="w-full bg-black hover:bg-gray-800">Subscribe Now</Button>
      </div>
      
      <RecentArticles articles={recentArticles} />
      
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h2 className="text-xl font-serif font-bold mb-4 pb-2 border-b">Featured Content</h2>
        <div className="aspect-video overflow-hidden rounded-md">
          <img
            src="/lovable-uploads/58231bdf-3e98-4fed-8ad5-cbe9a90dc19d.png"
            alt="Bloomberg Invest"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </div>
  );
};

export default AuthorSidebar;
