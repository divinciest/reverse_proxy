
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Article } from "@/data/types";
import ArticleCard from "@/components/ArticleCard";
import { cn } from "@/lib/utils";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import ViewToggle from "@/components/ViewToggle";

interface AuthorArticlesListProps {
  articles: Article[];
  authorName: string;
}

const AuthorArticlesList = ({ articles, authorName }: AuthorArticlesListProps) => {
  const [view, setView] = useState<"list" | "grid">("list");
  const [currentPage, setCurrentPage] = useState(1);
  const articlesPerPage = 10;

  if (articles.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground font-serif">
        No articles found for {authorName}.
      </div>
    );
  }

  // Calculate pagination
  const totalPages = Math.ceil(articles.length / articlesPerPage);
  const startIndex = (currentPage - 1) * articlesPerPage;
  const endIndex = startIndex + articlesPerPage;
  const currentArticles = articles.slice(startIndex, endIndex);

  // Helper function to adapt article data for ArticleCard
  const adaptArticleForCard = (article: any): Article => {
    return {
      id: article.id || "",
      title: article.title || "",
      summary: article.summary || "",
      source: article.source || "",
      sourceUrl: article.sourceUrl || article.url || "#",
      category: article.category || article.source || "",
      sentiment: article.sentiment || "neutral",
      date: article.publishDate || article.date || new Date().toISOString(),
      tags: article.topics || article.tags || [],
      url: article.url || article.sourceUrl || "#",
      imageUrl: article.imageUrl
    };
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Scroll to top when page changes
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Generate page numbers for pagination
  const getPageNumbers = () => {
    let pages: (number | string)[] = [];
    
    if (totalPages <= 7) {
      pages = Array.from({ length: totalPages }, (_, i) => i + 1);
    } else {
      if (currentPage <= 3) {
        pages = [1, 2, 3, 4, 'ellipsis', totalPages - 1, totalPages];
      } else if (currentPage >= totalPages - 2) {
        pages = [1, 2, 'ellipsis', totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
      } else {
        pages = [1, 'ellipsis', currentPage - 1, currentPage, currentPage + 1, 'ellipsis', totalPages];
      }
    }
    
    return pages;
  };

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-serif font-bold">Articles by {authorName}</h2>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">{articles.length} articles</span>
          <ViewToggle activeView={view} onChange={(newView) => setView(newView)} />
        </div>
      </div>
      
      <div className={cn(
        view === "grid" 
          ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6" 
          : "space-y-6 divide-y divide-gray-200"
      )}>
        {currentArticles.map((article) => (
          <Link key={article.id} to={`/article/${article.id}`}>
            <ArticleCard 
              article={adaptArticleForCard(article)}
              className={view === "list" ? "flex flex-row gap-4 items-start border-0 shadow-none pt-6" : ""}
              imageClassName={view === "list" ? "w-1/3 h-32" : "h-48"}
              contentClassName={view === "list" ? "w-2/3" : ""}
            />
          </Link>
        ))}
      </div>

      {totalPages > 1 && (
        <div className="mt-8">
          <Pagination>
            <PaginationContent>
              {currentPage > 1 && (
                <PaginationItem>
                  <PaginationPrevious 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      handlePageChange(currentPage - 1);
                    }} 
                  />
                </PaginationItem>
              )}
              
              {getPageNumbers().map((page, i) => (
                <PaginationItem key={i}>
                  {page === 'ellipsis' ? (
                    <PaginationEllipsis />
                  ) : (
                    <PaginationLink 
                      href="#" 
                      isActive={page === currentPage}
                      onClick={(e) => {
                        e.preventDefault();
                        handlePageChange(page as number);
                      }}
                    >
                      {page}
                    </PaginationLink>
                  )}
                </PaginationItem>
              ))}
              
              {currentPage < totalPages && (
                <PaginationItem>
                  <PaginationNext 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      handlePageChange(currentPage + 1);
                    }} 
                  />
                </PaginationItem>
              )}
            </PaginationContent>
          </Pagination>
        </div>
      )}
    </>
  );
};

export default AuthorArticlesList;
