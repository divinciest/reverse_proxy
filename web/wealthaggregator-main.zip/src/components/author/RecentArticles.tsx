
import React from "react";
import { Link } from "react-router-dom";
import { Article } from "@/data/types";
import { Button } from "@/components/ui/button";
import ArticleCard from "@/components/ArticleCard";

interface RecentArticlesProps {
  articles: Article[];
}

const RecentArticles = ({ articles }: RecentArticlesProps) => {
  // Helper function to adapt article data for ArticleCard
  const adaptArticleForCard = (article: any): Article => {
    return {
      id: article.id || "",
      title: article.title || "",
      summary: article.summary || "",
      source: article.source || "",
      sourceUrl: article.sourceUrl || article.url || "#",
      category: article.category || article.source || "",
      sentiment: article.sentiment || "neutral",
      date: article.publishDate || article.date || new Date().toISOString(),
      tags: article.topics || article.tags || [],
      url: article.url || article.sourceUrl || "#",
      imageUrl: article.imageUrl
    };
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h2 className="text-xl font-serif font-bold mb-4 border-b pb-2">
        Recent Articles
      </h2>
      
      {articles.length > 0 ? (
        <div className="space-y-4">
          {articles.map(article => (
            <Link to={`/article/${article.id}`} key={article.id} className="block">
              <ArticleCard 
                article={adaptArticleForCard(article)}
                className="border-0 shadow-none"
                imageClassName="h-20"
                contentClassName="p-2 pt-2"
              />
            </Link>
          ))}
        </div>
      ) : (
        <p className="text-muted-foreground text-sm">
          No recent articles found.
        </p>
      )}

      <div className="mt-4 pt-2 border-t">
        <Link to="#all-articles">
          <Button variant="outline" className="w-full">
            View all articles
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default RecentArticles;
