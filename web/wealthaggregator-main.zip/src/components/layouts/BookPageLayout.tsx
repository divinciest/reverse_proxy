
import React from "react";
import Header from "@/components/Header";
import StockTickerTape from "@/components/StockTickerTape";
import DateHeader from "@/components/DateHeader";

interface BookPageLayoutProps {
  children: React.ReactNode;
}

const BookPageLayout = ({ children }: BookPageLayoutProps) => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      <DateHeader />
      
      <main className="container mx-auto py-8 flex-1">
        {children}
      </main>

      <footer className="bg-gray-800 text-white py-6 border-t-4 border-gray-900">
        <div className="container mx-auto">
          <div className="text-center">
            <p className="font-serif text-lg">&copy; 2023 WealthManager.com - Financial News Aggregator</p>
            <p className="mt-1 text-gray-300">
              Providing aggregated financial content with AI-powered sentiment analysis
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default BookPageLayout;
