
import React from "react";
import NewsFeed from "@/components/NewsFeed";
import SourcesSection from "@/components/SourcesSection";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import SuggestionBanner from "@/components/SuggestionBanner";
import { getBestFaviconUrl } from "@/utils/favicon";
import StatsChart from "@/components/StatsChart";
import { ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { sources } from "@/data";
import ExpertsCard from "@/components/ExpertsCard";
import FeaturedAuthors from "@/components/FeaturedAuthors";
import FeaturedAuthorsSection from "@/components/FeaturedAuthorsSection";

// Featured sources to display in sidebar (using actual sources from data)
const featuredSources = [
  sources.find(s => s.id === "wsj") || sources[0],
  sources.find(s => s.id === "forbes") || sources[1], 
  sources.find(s => s.id === "market") || sources[2]
];

const MainLayout = () => {
  return (
    <main className="flex-1">
      <div className="container mx-auto py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="w-full lg:w-3/4">
            <NewsFeed />
            <FeaturedAuthorsSection />
          </div>
          
          <div className="w-full lg:w-1/4 space-y-6">
            {/* Market Overview Chart */}
            <Card>
              <CardHeader className="pb-2 pt-4">
                <CardTitle className="text-xl font-serif">Market Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <StatsChart />
              </CardContent>
            </Card>
            
            {/* Featured Authors - New Component */}
            <FeaturedAuthors />
            
            {/* Experts Card */}
            <ExpertsCard />
            
            {/* Featured Sources */}
            <Card>
              <CardHeader className="pb-2 pt-4">
                <CardTitle className="text-xl font-serif">Featured Sources</CardTitle>
              </CardHeader>
              <CardContent className="pt-2 p-0">
                <div className="grid grid-cols-1 gap-0">
                  {featuredSources.map((source, index) => (
                    <div key={index} className="p-4 border-b last:border-b-0">
                      <div className="flex flex-col items-center text-center">
                        <Avatar className="h-16 w-16 mb-2">
                          <img 
                            src={getBestFaviconUrl(source.name, source.url)} 
                            alt={source.name} 
                            className="h-full w-full object-contain"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = getBestFaviconUrl(source.name);
                            }}
                          />
                        </Avatar>
                        <h3 className="font-medium text-base">{source.name}</h3>
                        <p className="text-sm text-muted-foreground italic mb-2">{source.category}</p>
                        <div className="flex items-center justify-center gap-4 text-sm">
                          <Link to={`/source/${source.id}`} className="text-primary hover:underline">
                            View articles
                          </Link>
                          <a 
                            href={source.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-primary hover:underline flex items-center gap-1"
                          >
                            Visit <ExternalLink size={12} />
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Suggest Source Widget */}
            <Card className="bg-[#e9dbbd] border-none">
              <CardContent className="p-6">
                <h2 className="text-xl font-bold mb-2">Suggest a source</h2>
                <p className="text-gray-700 mb-1">
                  Looking for a source we don't already have? Suggest one <a href="#" className="underline font-medium">here</a>.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      <div className="border-t-2 border-gray-300">
        <SourcesSection />
      </div>
      
      <footer className="bg-gray-800 text-white py-6 border-t-4 border-gray-900">
        <div className="container mx-auto">
          <div className="text-center">
            <p className="font-serif text-lg">&copy; 2023 WealthManager.com - Financial News Aggregator</p>
            <p className="mt-1 text-gray-300">
              Providing aggregated financial content with AI-powered sentiment analysis
            </p>
          </div>
        </div>
      </footer>
    </main>
  );
};

export default MainLayout;
