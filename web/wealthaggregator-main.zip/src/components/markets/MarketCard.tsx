
import React from "react";
import { ArrowUp, ArrowDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { MarketIndex } from "@/utils/marketDataService";
import { Link } from "react-router-dom";

interface MarketCardProps {
  market: MarketIndex;
}

const MarketCard = ({ market }: MarketCardProps) => {
  const isPositive = market.changePercent >= 0;

  // Helper function to determine link destination based on market name
  const getDestination = (marketName: string) => {
    if (marketName === "S&P 500") return "/sp500";
    if (marketName === "Dow Jones") return "/dowjones";
    return "#";
  };

  return (
    <Link 
      to={getDestination(market.name)}
      className={cn(
        "block p-4 rounded-lg shadow-sm transition-all hover:shadow-md",
        isPositive ? "bg-green-50 border-green-300" : "bg-red-50 border-red-300",
        "border"
      )}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div>
            <h3 className="font-bold text-lg">{market.name}</h3>
            <div className="text-2xl font-mono truncate">{market.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
          </div>
        </div>
        <div className="text-right">
          <div className={cn(
            "text-lg font-medium flex items-center justify-end",
            isPositive ? "text-green-600" : "text-red-600"
          )}>
            {isPositive ? (
              <ArrowUp className="h-4 w-4 mr-1" />
            ) : (
              <ArrowDown className="h-4 w-4 mr-1" />
            )}
            {isPositive ? '+' : ''}{market.changePercent.toFixed(2)}%
          </div>
          <div className="font-mono text-sm text-gray-600 whitespace-nowrap">
            {isPositive ? '+' : ''}{market.change.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>
      </div>
      
      {market.weight !== undefined && (
        <div className="mt-2 text-xs text-gray-500 flex justify-between">
          <span className="font-medium">#</span>
          <span>Weight: {market.weight.toFixed(2)}%</span>
        </div>
      )}
    </Link>
  );
};

export default MarketCard;
