
import React from "react";
import { cn } from "@/lib/utils";
import { MarketRegion } from "@/utils/marketDataService";

interface RegionSelectorProps {
  regions: MarketRegion[];
  activeRegion: string;
  onRegionChange: (region: string) => void;
}

const RegionSelector = ({ regions, activeRegion, onRegionChange }: RegionSelectorProps) => {
  return (
    <div className="flex flex-wrap gap-2 mb-6">
      {regions.map((region) => (
        <button
          key={region.name}
          onClick={() => onRegionChange(region.name)}
          className={cn(
            "px-4 py-2 rounded-md text-base font-medium transition-colors whitespace-nowrap",
            activeRegion === region.name
              ? "bg-blue-100 text-blue-800"
              : "bg-gray-100 text-gray-800 hover:bg-gray-200"
          )}
        >
          {region.name}
        </button>
      ))}
    </div>
  );
};

export default RegionSelector;
