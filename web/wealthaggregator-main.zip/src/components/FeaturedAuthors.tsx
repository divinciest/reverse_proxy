
import React from "react";
import { Avatar } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { authors } from "@/data/authors";

const FeaturedAuthors = () => {
  return (
    <Card>
      <CardHeader className="pb-2 pt-4">
        <CardTitle className="text-xl font-serif">Featured Authors</CardTitle>
      </CardHeader>
      <CardContent className="pt-2 p-0">
        <div className="grid grid-cols-1 divide-y">
          {authors.map((author) => (
            <Link key={author.id} to={`/author/${author.id}`} className="px-4 py-3 hover:bg-gray-50 transition-colors block relative">
              <div className="relative">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-16 w-16 mb-2">
                    {author.imageUrl ? (
                      <img
                        src={author.imageUrl}
                        alt={author.name}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center bg-primary/10 text-primary font-medium">
                        {author.name.charAt(0)}
                      </div>
                    )}
                  </Avatar>
                  <h3 className="font-medium text-base">{author.name}</h3>
                  <p className="text-sm text-muted-foreground">{author.title}</p>
                  <p className="text-xs text-muted-foreground">{author.publication}</p>
                </div>
              </div>
              
              <ArrowUpRight className="h-4 w-4 text-gray-400 absolute top-3 right-3 group-hover:text-primary transition-colors" />
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default FeaturedAuthors;
