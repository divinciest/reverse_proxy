
import React, { useState } from "react";
import ArticleCard from "./ArticleCard";
import ArticleListItem from "./ArticleListItem";
import { cn } from "@/lib/utils";
import { Article } from "@/data/types";

interface ArticlesListProps {
  articles: any[];
  view?: "grid" | "list";
  className?: string;
  onTopicClick?: (topic: string) => void;
  emptyMessage?: string;
  openInNewTab?: boolean;
  articlesPerPage?: number;
  featuredCount?: number;
}

const ArticlesList = ({
  articles,
  view = "grid",
  className,
  onTopicClick,
  emptyMessage = "No articles found",
  openInNewTab = false,
  articlesPerPage,
  featuredCount = 0,
}: ArticlesListProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  
  if (!articles || articles.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <p>{emptyMessage}</p>
      </div>
    );
  }

  // Get a safe array of articles (filter out any that are null/undefined)
  const safeArticles = Array.isArray(articles) ? articles.filter(Boolean) : [];
  
  // Handle pagination if articlesPerPage is provided
  const displayedArticles = articlesPerPage 
    ? safeArticles.slice(0, articlesPerPage) 
    : safeArticles;

  return (
    <div
      className={cn(
        view === "grid"
          ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          : "space-y-6",
        className
      )}
    >
      {displayedArticles.map((article, idx) => {
        // IMPORTANT: Do not modify the tag processing logic below, as it's critical for proper tag display
        // Convert article format if needed - in case the data has inconsistent format
        const processedArticle: Article = {
          id: article.id || idx.toString(),
          title: article.title,
          summary: article.summary,
          source: article.source,
          sourceUrl: article.sourceUrl || article.url || "",
          category: article.category || article.source,
          author: article.author,
          date: article.date || article.publishDate,
          hoursAgo: article.hoursAgo,
          tags: article.tags || article.topics || [],
          url: article.url || article.sourceUrl || "",
          sentiment: article.sentiment || "neutral",
          companies: article.companies || [],
          sourceLogo: article.sourceLogo || "",
          sourceColor: article.sourceColor || "#000000",
          imageUrl: article.imageUrl
        };

        return view === "grid" ? (
          <ArticleCard
            key={processedArticle.id}
            article={processedArticle}
            onTopicClick={onTopicClick}
            openInNewTab={openInNewTab}
          />
        ) : (
          <ArticleListItem
            key={processedArticle.id}
            article={processedArticle}
            onTopicClick={onTopicClick}
            openInNewTab={openInNewTab}
          />
        );
      })}
    </div>
  );
};

export default ArticlesList;
