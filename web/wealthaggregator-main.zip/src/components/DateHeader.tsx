import React from "react";
import { format, formatDistanceToNowStrict } from "date-fns";
import { Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface DateHeaderProps {
  date?: string;
  hoursAgo?: number;
  className?: string;
  size?: "sm" | "md" | "lg";
}

const DateHeader = ({ date, hoursAgo, className, size = "md" }: DateHeaderProps) => {
  let dateDisplay = "";
  
  // If we have hoursAgo, use that
  if (typeof hoursAgo === 'number') {
    if (hoursAgo < 1) {
      dateDisplay = "Just now";
    } else if (hoursAgo < 24) {
      dateDisplay = `${Math.floor(hoursAgo)}h ago`;
    } else {
      // For anything older than 24 hours, use the date
      dateDisplay = date ? format(new Date(date), "MMM d, yyyy") : "";
    }
  } 
  // Otherwise, if we have a date, use relative time
  else if (date) {
    try {
      const dateObj = new Date(date);
      const now = new Date();
      const diffHours = (now.getTime() - dateObj.getTime()) / (1000 * 60 * 60);
      
      if (diffHours < 1) {
        dateDisplay = "Just now";
      } else if (diffHours < 24) {
        dateDisplay = formatDistanceToNowStrict(dateObj, { addSuffix: true });
      } else {
        dateDisplay = format(dateObj, "MMM d, yyyy");
      }
    } catch (e) {
      console.error("Invalid date:", date);
      dateDisplay = date; // Fallback to raw date string
    }
  }
  
  // No date information provided
  if (!dateDisplay) {
    return null;
  }
  
  return (
    <div className={cn(
      "flex items-center", 
      size === "sm" ? "text-xs" : size === "lg" ? "text-sm" : "text-xs",
      className
    )}>
      <Clock 
        className={cn("mr-1", size === "sm" ? "h-3 w-3" : size === "lg" ? "h-4 w-4" : "h-3.5 w-3.5")} 
      />
      <span>{dateDisplay}</span>
    </div>
  );
};

export default DateHeader;
