
import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible";
import { ChevronUp, Plus, ChevronDown } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { getBestFaviconUrl } from "@/utils/favicon";
import { FeedSource } from "@/types/admin";

interface FeedSourceFilterProps {
  feeds: FeedSource[];
  onToggleFeedSource: (id: string) => void;
  isOpen: boolean;
  onToggleSection: () => void;
}

const FeedSourceFilter = ({ 
  feeds, 
  onToggleFeedSource, 
  isOpen, 
  onToggleSection 
}: FeedSourceFilterProps) => {
  const [feedsWithLogos, setFeedsWithLogos] = useState<FeedSource[]>(feeds);

  // Check if we have an "All" feed source
  const hasAllFeed = feeds.some(feed => feed.id === "all");
  const allSelected = feeds.some(feed => feed.id === "all" && feed.selected);
  
  useEffect(() => {
    const updatedFeeds = feeds.map(feed => {
      if (!feed.logo) {
        let domain = "";
        const nameLower = feed.name.toLowerCase();
        
        if (nameLower.includes("forbes")) domain = "forbes.com";
        else if (nameLower.includes("cnbc")) domain = "cnbc.com";
        else if (nameLower.includes("financial times")) domain = "ft.com";
        else if (nameLower.includes("wall street journal")) domain = "wsj.com";
        else if (nameLower.includes("yahoo")) domain = "finance.yahoo.com";
        else if (nameLower.includes("marketwatch")) domain = "marketwatch.com";
        else if (nameLower.includes("nbc")) domain = "nbcnews.com";
        
        return {
          ...feed,
          logo: getBestFaviconUrl(feed.name, domain)
        };
      }
      return feed;
    });
    
    setFeedsWithLogos(updatedFeeds);
  }, [feeds]);

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Sources</h2>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onToggleSection}
              className="h-8 px-2"
            >
              {isOpen ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
              <span className="ml-1">{isOpen ? 'Hide' : 'Show'}</span>
            </Button>
            <Button variant="ghost" className="text-purple-500">
              <span className="mr-1">Show Statistics</span>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                <path d="M3 3v18h18"></path>
                <path d="M18 11V3"></path>
                <path d="M11 18V9"></path>
                <path d="M18 11l-7-2"></path>
              </svg>
            </Button>
          </div>
        </div>
        
        <Collapsible open={isOpen}>
          <CollapsibleContent>
            <div className="flex flex-wrap gap-2">
              {feedsWithLogos.map((feed) => (
                <div 
                  key={feed.id} 
                  className={`relative cursor-pointer ${feed.id === "all" ? "mr-2" : ""}`}
                  onClick={() => onToggleFeedSource(feed.id)}
                >
                  <Avatar className={`w-12 h-12 border-2 ${feed.selected ? 'border-purple-500' : 'border-gray-200'}`}>
                    <AvatarImage 
                      src={feed.logo} 
                      alt={feed.name}
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        if (!target.src.includes('generateCompanyLogo')) {
                          target.src = getBestFaviconUrl(feed.name);
                        }
                      }}
                    />
                    <AvatarFallback className="bg-gray-100 text-gray-800 font-bold">
                      {feed.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  {feed.selected && (
                    <div className="absolute -top-1 -right-1 w-5 h-5 bg-purple-500 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-3 h-3 text-white">
                        <path d="M20 6L9 17l-5-5"></path>
                      </svg>
                    </div>
                  )}
                  {feed.id === "all" && (
                    <Badge className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 text-xs bg-blue-500">
                      All
                    </Badge>
                  )}
                  {feed.id !== "all" && (
                    <Badge className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 text-xs">
                      {feed.count}
                    </Badge>
                  )}
                </div>
              ))}
              <div className="relative cursor-pointer">
                <Avatar className="w-12 h-12 border-2 border-dashed border-purple-500 bg-transparent flex items-center justify-center">
                  <Plus className="h-6 w-6 text-purple-500" />
                </Avatar>
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
};

export default FeedSourceFilter;
