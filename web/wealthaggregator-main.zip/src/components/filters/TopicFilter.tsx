
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible";
import { ChevronUp, Plus, ChevronDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Topic } from "@/types/admin";

interface TagFilterProps {
  topics: Topic[];
  onToggleTopic: (id: string) => void;
  isOpen: boolean;
  onToggleSection: () => void;
  showAllTopics: boolean;
  onToggleShowAllTopics: () => void;
}

const TagFilter = ({ 
  topics, 
  onToggleTopic, 
  isOpen, 
  onToggleSection,
  showAllTopics,
  onToggleShowAllTopics
}: TagFilterProps) => {
  // Display a limited number of topics if showAllTopics is false
  const displayedTopics = showAllTopics ? topics : topics.slice(0, 10);

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Tags</h2>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onToggleSection}
              className="h-8 px-2"
            >
              {isOpen ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
              <span className="ml-1">{isOpen ? 'Hide' : 'Show'}</span>
            </Button>
          </div>
        </div>
        
        <Collapsible open={isOpen}>
          <CollapsibleContent>
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {displayedTopics.map((topic) => (
                  <Badge
                    key={topic.name}
                    variant={topic.selected ? "default" : "outline"}
                    className={`cursor-pointer ${
                      topic.selected ? "bg-primary text-primary-foreground" : "bg-background hover:bg-muted"
                    }`}
                    onClick={() => onToggleTopic(topic.name)}
                  >
                    {topic.name}
                    {topic.count > 0 && (
                      <span className="ml-1 text-xs">({topic.count})</span>
                    )}
                  </Badge>
                ))}
                
                {/* Show more/less button if we have more than 10 topics */}
                {topics.length > 10 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onToggleShowAllTopics}
                    className="text-xs"
                  >
                    {showAllTopics ? "Show Less" : `+${topics.length - 10} More`}
                  </Button>
                )}
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
};

export default TagFilter;
