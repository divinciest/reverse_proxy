
import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible";
import { ChevronUp, ChevronDown } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { getBestFaviconUrl } from "@/utils/favicon";
import { CompanySource } from "@/types/admin";

interface CompanyFilterProps {
  companies: CompanySource[];
  onToggleCompany: (id: string) => void;
  isOpen: boolean;
  onToggleSection: () => void;
}

const CompanyFilter = ({ 
  companies, 
  onToggleCompany, 
  isOpen, 
  onToggleSection 
}: CompanyFilterProps) => {
  const [companiesWithLogos, setCompaniesWithLogos] = useState<CompanySource[]>(companies);

  // Check if "All" is selected (assuming it's the first company)
  const allSelected = companies.length > 0 && companies[0].id === "all" && companies[0].selected;

  useEffect(() => {
    const updatedCompanies = companies.map(company => {
      if (!company.logo) {
        let domain = "";
        const nameLower = company.name.toLowerCase();
        
        if (nameLower.includes("apple")) domain = "apple.com";
        else if (nameLower.includes("tesla")) domain = "tesla.com";
        else if (nameLower.includes("general electric") || nameLower.includes("ge")) domain = "ge.com";
        else if (nameLower.includes("intel")) domain = "intel.com";
        else if (nameLower.includes("microsoft")) domain = "microsoft.com";
        else if (nameLower.includes("amazon")) domain = "amazon.com";
        else if (nameLower.includes("twitter") || nameLower === "x") domain = "twitter.com";
        else if (nameLower.includes("google")) domain = "google.com";
        else if (nameLower.includes("facebook") || nameLower.includes("meta")) domain = "facebook.com";
        
        return {
          ...company,
          logo: getBestFaviconUrl(company.name, domain)
        };
      }
      return company;
    });
    
    setCompaniesWithLogos(updatedCompanies);
  }, [companies]);

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Companies</h2>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onToggleSection}
            className="h-8 px-2"
          >
            {isOpen ? (
              <ChevronUp className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
            <span className="ml-1">{isOpen ? 'Hide' : 'Show'}</span>
          </Button>
        </div>
        
        <Collapsible open={isOpen}>
          <CollapsibleContent>
            <div className="flex flex-wrap gap-2">
              {companiesWithLogos.map((company) => (
                <div 
                  key={company.id} 
                  className={`relative cursor-pointer ${company.id === "all" ? "mr-2" : ""}`}
                  onClick={() => onToggleCompany(company.id)}
                >
                  <Avatar className={`w-12 h-12 border-2 ${
                    company.id === "all" 
                      ? (company.selected ? 'border-purple-500' : 'border-gray-200')
                      : (company.selected && !allSelected ? 'border-purple-500' : 'border-gray-200')
                  }`}>
                    <AvatarImage 
                      src={company.logo} 
                      alt={company.name}
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        if (!target.src.includes('generateCompanyLogo')) {
                          target.src = getBestFaviconUrl(company.name);
                        }
                      }}
                    />
                    <AvatarFallback className="bg-gray-100 text-gray-800 font-bold">
                      {company.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  {company.selected && (company.id === "all" || !allSelected) && (
                    <div className="absolute -top-1 -right-1 w-5 h-5 bg-purple-500 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-3 h-3 text-white">
                        <path d="M20 6L9 17l-5-5"></path>
                      </svg>
                    </div>
                  )}
                  {company.id === "all" && (
                    <Badge className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 text-xs bg-blue-500">
                      All
                    </Badge>
                  )}
                  {company.id !== "all" && (
                    <Badge className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 text-xs">
                      {company.count}
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
};

export default CompanyFilter;
