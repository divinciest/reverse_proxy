
import React from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import TopicBadge from "@/components/TopicBadge";
import { Link } from "react-router-dom";

interface TopicFilterProps {
  topics: string[];
  selectedTopic: string | null;
  onTopicSelect: (topic: string | null) => void;
}

const TopicFilter = ({ topics, selectedTopic, onTopicSelect }: TopicFilterProps) => {
  return (
    <div className="w-full mb-6">
      <h2 className="text-xl font-semibold mb-3">Breaking News Topics</h2>
      <ScrollArea className="w-full whitespace-nowrap pb-4">
        <div className="flex gap-2">
          <TopicBadge
            topic="All Topics"
            active={selectedTopic === null}
            onClick={() => onTopicSelect(null)}
            variant="topic"
          />
          {topics.map((topic) => (
            <Link 
              key={topic} 
              to={`/topic/${encodeURIComponent(topic.replace(/ /g, '-'))}`}
              onClick={(e) => {
                if (onTopicSelect) {
                  e.preventDefault();
                  onTopicSelect(topic);
                }
              }}
            >
              <TopicBadge
                topic={topic}
                active={selectedTopic === topic}
                variant="topic"
              />
            </Link>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default TopicFilter;
