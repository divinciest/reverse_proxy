import React, { useState, useMemo, useEffect } from "react";
import FilterToolbar from "@/components/FilterToolbar";
import ArticlesList from "@/components/ArticlesList";
import { cn } from "@/lib/utils";
import { useArticles } from "@/hooks/useArticles";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertCircle, RefreshCw, Info } from "lucide-react";
import { toast } from "sonner";
import { convertApiArticleToUiArticle } from "@/utils/articleUtils";

interface NewsFeedProps {
  className?: string;
  selectedFeedSources?: string[];
  selectedCompanies?: string[];
  selectedTags?: string[];
}

const NewsFeed = ({ 
  className,
  selectedFeedSources = [],
  selectedCompanies = [],
  selectedTags = []
}: NewsFeedProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [view, setView] = useState<"grid" | "list">("grid");
  const [dateFilter, setDateFilter] = useState("7");
  const [dateRange, setDateRange] = useState<{ start: Date; end: Date } | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOrder, setSortOrder] = useState<"default" | "az" | "za">("default");

  const { 
    articles: apiArticles, 
    isLoading, 
    error, 
    refreshArticles, 
    sourcesArticleCounts, 
    companiesArticleCounts,
    isApiAvailable 
  } = useArticles({ 
    sourceIds: selectedFeedSources.length > 0 ? selectedFeedSources : undefined,
    companyIds: selectedCompanies.includes("all") ? undefined : 
              (selectedCompanies.length > 0 ? selectedCompanies : undefined),
    initialDays: getDateFilterDays() 
  });

  const articles = apiArticles.map(article => convertApiArticleToUiArticle(article));

  useEffect(() => {
    if (!isApiAvailable) {
      toast.warning("API connection unavailable. Using fallback data.", {
        duration: 5000,
        position: "top-center",
      });
    }
  }, [isApiAvailable]);

  useEffect(() => {
  }, [selectedFeedSources, selectedCompanies]);

  function getDateFilterDays(): number {
    switch(dateFilter) {
      case "1day": return 1;
      case "3days": return 3;
      case "1week": case "7": return 7;
      case "15days": return 15;
      case "1month": return 30;
      default: return 7; // default to 7 days
    }
  }

  const filteredArticles = useMemo(() => {
    if (!articles || !Array.isArray(articles)) return [];
    
    return articles.filter((article) => {
      if (!article) return false;
      
      const matchesTags = 
        selectedTags.length === 0 || 
        (article.tags && Array.isArray(article.tags) && 
         article.tags.some(tag => selectedTags.includes(tag)));
      
      const matchesCategory = 
        !selectedCategory || 
        (article.source && article.source.toLowerCase().includes(selectedCategory.toLowerCase()));
      
      const matchesSearch = 
        !searchQuery || 
        (article.title && article.title.toLowerCase().includes(searchQuery.toLowerCase())) || 
        (article.summary && article.summary.toLowerCase().includes(searchQuery.toLowerCase()));
      
      let matchesDate = true;
      if (dateRange && article.date) {
        const articleDate = new Date(article.date);
        matchesDate = articleDate >= dateRange.start && articleDate <= dateRange.end;
      }
      
      return matchesTags && matchesCategory && matchesSearch && matchesDate;
    });
  }, [articles, selectedTags, selectedCategory, searchQuery, dateRange]);

  const handleCategorySelect = (category: string | null) => {
    setSelectedCategory(category);
  };

  const handleTagClick = (tag: string) => {
  };

  const handleViewChange = (newView: "list" | "grid") => {
    setView(newView);
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
  };
  
  const handleSortChange = (sort: "default" | "az" | "za") => {
    setSortOrder(sort);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error && !articles.length) {
    return (
      <Alert variant="destructive" className="mb-6">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription className="flex flex-col gap-4">
          <p>Unable to load articles: {error}</p>
          <Button 
            onClick={refreshArticles}
            variant="outline"
            className="w-fit"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Try Again
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  const safeArticles = Array.isArray(filteredArticles) ? filteredArticles : [];

  if (safeArticles.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <p className="mb-4">No articles found matching your criteria.</p>
        <Button 
          onClick={refreshArticles}
          variant="outline"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh Articles
        </Button>
      </div>
    );
  }

  return (
    <div className={cn("", className)}>
      {!isApiAvailable && (
        <Alert className="mb-6 bg-amber-50 border-amber-200">
          <Info className="h-4 w-4" />
          <AlertTitle>Using Demo Data</AlertTitle>
          <AlertDescription>
            API connection is unavailable. Showing demo articles instead of live data.
          </AlertDescription>
        </Alert>
      )}
      
      <div className="mt-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
          <FilterToolbar 
            dateFilter={dateFilter}
            onDateFilterChange={setDateFilter}
            view={view}
            onViewChange={handleViewChange}
            onRefresh={refreshArticles}
            sortProps={{
              onSort: handleSortChange,
              currentSort: sortOrder
            }}
            dateRange={dateRange}
            onDateRangeChange={setDateRange}
          />
        </div>
        
        <ArticlesList 
          articles={safeArticles}
          view={view}
          onTopicClick={handleTagClick}
          openInNewTab={true}
        />
      </div>
    </div>
  );
};

export default NewsFeed;
