
import React, { useState, useEffect } from "react";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

/**
 * CRITICAL WARNING - ZERO TOLERANCE POLICY FOR MOCK DATA
 * 
 * ABSOLUTELY NO MOCK DATA IS ALLOWED IN THIS COMPONENT, UNDER ANY CIRCUMSTANCES.
 * 
 * Even in the case of errors, testing, or development, NO HARDCODED DATA
 * or FALLBACK VALUES are permitted. If market data cannot be fetched from
 * a real API, this component must display an error message instead.
 * 
 * NO EXCEPTIONS. NO TEMPORARY SOLUTIONS.
 */

interface StockData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
}

const StockTickerTape = () => {
  const [stocks, setStocks] = useState<StockData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // This effect must be implemented to fetch real data from an actual market API
  useEffect(() => {
    const fetchRealMarketData = async () => {
      try {
        // This should be replaced with a real market data API call
        // Example: const response = await fetch('https://market-api.example.com/stocks');
        // setStocks(await response.json());
        
        // Until real API integration is done, we'll show error state
        setError("Market data API not implemented yet");
        setIsLoading(false);
      } catch (err) {
        console.error("Failed to fetch market data:", err);
        setError("Unable to fetch market data");
        setIsLoading(false);
      }
    };
    
    fetchRealMarketData();
  }, []);

  // Function to render stock item
  const renderStockItem = (stock: StockData) => {
    const isPositive = stock.changePercent >= 0;
    
    return (
      <div key={stock.symbol} className="flex items-center gap-4 py-1 px-4 whitespace-nowrap">
        <div className="flex flex-col items-start min-w-[7rem]">
          <span className="font-bold">{stock.name}</span>
          <span className="text-sm text-muted-foreground">{stock.symbol}</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="font-mono font-semibold">
            ${stock.price.toFixed(2)}
          </span>
          <div 
            className={cn(
              "flex items-center gap-1",
              isPositive ? "text-bullish" : "text-bearish"
            )}
          >
            {isPositive ? (
              <ArrowUpRight className="h-4 w-4" />
            ) : (
              <ArrowDownRight className="h-4 w-4" />
            )}
            <span className="font-mono">
              {stock.change > 0 ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePercent > 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%)
            </span>
          </div>
        </div>
      </div>
    );
  };
  
  if (isLoading) {
    return (
      <div className="bg-gray-100 py-3 border-t border-b border-gray-300 flex justify-center items-center">
        <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-gray-700 mr-2"></div>
        <span>Loading market data...</span>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-gray-100 py-2 border-t border-b border-gray-300">
        <Alert variant="destructive" className="max-w-3xl mx-auto">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Market Data Unavailable</AlertTitle>
          <AlertDescription>
            {error}. This component requires a real market data API integration.
          </AlertDescription>
        </Alert>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-100 py-2 border-t border-b border-gray-300 overflow-x-auto">
      {stocks.length > 0 ? (
        <div className="flex">
          {stocks.map(stock => renderStockItem(stock))}
        </div>
      ) : (
        <div className="text-center py-2 text-gray-500">
          No market data available
        </div>
      )}
    </div>
  );
};

export default StockTickerTape;
