
import React, { useState } from "react";
import { getBestFaviconUrl } from "@/utils/favicon";

interface ArticleImageProps {
  imageUrl?: string;
  title: string;
  source?: string; // Added source for fallback
}

const ArticleImage = ({ imageUrl, title, source }: ArticleImageProps) => {
  const [imageError, setImageError] = useState(false);
  
  // Fallback images for when the primary image is missing or fails to load
  const fallbackImages = [
    "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=800&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=800&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&auto=format&fit=crop"
  ];
  
  // Choose a deterministic fallback based on article title
  const getFallbackImage = (title: string) => {
    // Simple hash function for the title
    const hash = title.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return fallbackImages[hash % fallbackImages.length];
  };
  
  if (!imageUrl && !imageError) {
    // Use a fallback image if no image URL is provided
    imageUrl = getFallbackImage(title);
  }
  
  return (
    <div className="mb-6">
      <img 
        src={imageError ? getFallbackImage(title) : imageUrl}
        alt={title} 
        className="w-full h-auto max-h-[400px] object-cover rounded-lg shadow-sm"
        onError={(e) => {
          // If image fails to load, try to use a fallback
          setImageError(true);
          console.log(`Image failed to load for: ${title}. Using fallback image.`);
          
          // If source is provided, we could also try using a source logo
          if (source && false) { // Disabled for now in detail view
            const target = e.target as HTMLImageElement;
            const fallbackUrl = getBestFaviconUrl(source);
            
            if (fallbackUrl) {
              target.src = fallbackUrl;
              target.className = "w-full h-64 object-contain p-4 bg-gray-100"; 
            } else {
              target.src = getFallbackImage(title);
            }
          }
        }}
      />
    </div>
  );
};

export default ArticleImage;
