
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Share2, Facebook, Twitter, Linkedin, Link2 } from "lucide-react";
import SentimentBadge from "@/components/SentimentBadge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";

interface ArticleHeaderProps {
  formattedDate: string;
  title: string;
  source: string;
  sourceUrl: string;
  category: string;
  sentiment: "bullish" | "neutral" | "bearish";
}

const ArticleHeader = ({
  formattedDate,
  title,
  source,
  sourceUrl,
  category,
  sentiment,
}: ArticleHeaderProps) => {
  const { toast } = useToast();
  
  const handleShare = (platform: string) => {
    const currentUrl = window.location.href;
    let shareUrl = "";
    
    switch (platform) {
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}`;
        break;
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(currentUrl)}&text=${encodeURIComponent(title)}`;
        break;
      case "linkedin":
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(currentUrl)}`;
        break;
      case "copy":
        navigator.clipboard.writeText(currentUrl).then(() => {
          toast({
            title: "Link copied",
            description: "The article URL has been copied to your clipboard.",
            duration: 3000,
          });
        });
        return;
      default:
        return;
    }
    
    window.open(shareUrl, "_blank", "width=600,height=400");
  };

  return (
    <>
      <div className="mb-6 flex justify-between items-center">
        <Link to="/">
          <Button variant="ghost" className="pl-0">
            <ArrowLeft size={16} className="mr-2" /> Back to Articles
          </Button>
        </Link>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              <Share2 size={16} className="mr-2" /> Share
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-white">
            <DropdownMenuItem onClick={() => handleShare("facebook")}>
              <Facebook size={16} className="mr-2 text-blue-600" />
              Facebook
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleShare("twitter")}>
              <Twitter size={16} className="mr-2 text-blue-400" />
              Twitter
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleShare("linkedin")}>
              <Linkedin size={16} className="mr-2 text-blue-700" />
              LinkedIn
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleShare("copy")}>
              <Link2 size={16} className="mr-2" />
              Copy link
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="mb-4 flex items-center">
        <SentimentBadge sentiment={sentiment} className="mr-2" />
        <span className="text-sm text-muted-foreground">
          Published on {formattedDate}
        </span>
      </div>

      <h1 className="text-3xl font-bold mb-4">{title}</h1>
      
      <div className="flex items-center mb-6">
        <span className="font-semibold mr-2">Source:</span>
        <a 
          href={sourceUrl} 
          target="_blank" 
          rel="noopener noreferrer" 
          className="text-primary hover:underline"
        >
          {source}
        </a>
        <span className="mx-2 text-muted-foreground">•</span>
        <span className="text-muted-foreground">{category}</span>
      </div>
    </>
  );
};

export default ArticleHeader;
