
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import ArticleCard from "@/components/ArticleCard";
import { Article } from "@/data/types";

interface RelatedArticlesProps {
  source: string;
  relatedArticles: Article[];
}

const RelatedArticles = ({ source, relatedArticles }: RelatedArticlesProps) => {
  // Helper function to adapt article data for ArticleCard
  const adaptArticleForCard = (article: any): Article => {
    return {
      id: article.id || "",
      title: article.title || "",
      summary: article.summary || "",
      source: article.source || "",
      sourceUrl: article.sourceUrl || article.url || "#",
      category: article.category || article.source || "",
      sentiment: article.sentiment || "neutral",
      date: article.publishDate || article.date || new Date().toISOString(),
      tags: article.topics || article.tags || [],
      url: article.url || article.sourceUrl || "#",
      imageUrl: article.imageUrl
    };
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
      <h2 className="text-xl font-serif font-bold mb-4 border-b pb-2">
        More from {source}
      </h2>
      
      {relatedArticles.length > 0 ? (
        <div className="space-y-4">
          {relatedArticles.map(relatedArticle => (
            <ArticleCard 
              key={relatedArticle.id}
              article={adaptArticleForCard(relatedArticle)}
              className="border-0 shadow-none"
              imageClassName="h-24"
              contentClassName="p-2 pt-2"
            />
          ))}
        </div>
      ) : (
        <p className="text-muted-foreground text-sm">
          No related articles found from this source.
        </p>
      )}

      <div className="mt-4 pt-2 border-t">
        <Link to={`/source/${source.toLowerCase().replace(/\s+/g, '-')}`}>
          <Button variant="outline" className="w-full">
            View all articles from {source}
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default RelatedArticles;
