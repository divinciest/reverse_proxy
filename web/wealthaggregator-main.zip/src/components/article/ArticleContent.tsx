
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import TopicBadge from "@/components/TopicBadge";

interface ArticleContentProps {
  summary: string;
  topics: string[];
  url: string;
  source: string;
}

const ArticleContent = ({ summary, topics, url, source }: ArticleContentProps) => {
  return (
    <>
      <div className="prose max-w-none mb-6">
        <p className="text-lg mb-4">{summary}</p>
        <p className="text-muted-foreground">
          This is a placeholder for the full article content. In a complete implementation,
          the full article content or an AI-generated extended summary would be displayed here.
        </p>
      </div>

      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Topics</h2>
        <div className="flex flex-wrap gap-2">
          {topics.map(topic => (
            <Link to={`/?topic=${encodeURIComponent(topic)}`} key={topic}>
              <TopicBadge topic={topic} />
            </Link>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-2">Read Full Article</h2>
        <p className="mb-4 text-muted-foreground">
          Continue reading the full article on the original source.
        </p>
        <a 
          href={url} 
          target="_blank" 
          rel="noopener noreferrer"
        >
          <Button>Read on {source}</Button>
        </a>
      </div>
    </>
  );
};

export default ArticleContent;
