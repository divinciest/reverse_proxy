
import React from "react";

interface SentimentCoverageProps {
  sourceCount: number;
  sentimentCoverage: {
    bullish: number;
    bearish: number;
    neutral: number;
  };
}

const SentimentCoverage = ({ sourceCount, sentimentCoverage }: SentimentCoverageProps) => {
  // Calculate the weighted average to determine indicator position
  // Bearish = 0, Neutral = 50, Bullish = 100
  const calculatePosition = () => {
    const { bullish, bearish, neutral } = sentimentCoverage;
    // Weight bullish positive, bearish negative, and neutral in the middle
    const weightedSum = (bullish * 100) + (neutral * 50) + (bearish * 0);
    const total = bullish + bearish + neutral;
    return total > 0 ? weightedSum / total : 50;
  };

  // Position on a scale of 0-100
  const position = calculatePosition();
  
  // Determine which label to highlight
  const getSentimentLabel = () => {
    if (position < 33) return "Bear";
    if (position > 66) return "Bull";
    return "Neutral";
  };

  const sentimentLabel = getSentimentLabel();

  return (
    <div className="mb-6">
      <h2 className="text-xl font-semibold mb-2">Market Sentiment</h2>
      <div className="bg-white p-4 rounded-lg shadow-sm border">
        <div className="flex items-center mb-4">
          <span className="font-medium">Based on: </span>
          <span className="ml-1">{sourceCount} sources</span>
        </div>
        
        {/* Sentiment bar with indicator */}
        <div className="relative mb-6">
          {/* Bar background with gradient */}
          <div className="h-12 w-full rounded-md overflow-hidden">
            <div 
              className="h-full w-full"
              style={{
                background: "linear-gradient(90deg, #dc2626 0%, #dc2626 20%, #f97316 20%, #f97316 40%, #facc15 40%, #facc15 60%, #a3e635 60%, #a3e635 80%, #16a34a 80%, #16a34a 100%)"
              }}
            />
          </div>
          
          {/* Indicator arrow - now above the bar */}
          <div 
            className="absolute bottom-full transform -translate-x-1/2"
            style={{
              left: `${position}%`,
              marginBottom: "-1px"
            }}
          >
            <div className="flex flex-col items-center">
              <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-b-[10px] border-b-gray-800"></div>
            </div>
          </div>
          
          {/* Sentiment label centered on the indicator */}
          <div 
            className="absolute bottom-full mb-2 transform -translate-x-1/2 font-bold text-black text-lg"
            style={{
              left: `${position}%`,
            }}
          >
            {sentimentLabel}
          </div>
        </div>
        
        {/* MARKET SENTIMENT label */}
        <div className="text-center text-gray-500 text-sm mb-2">
          MARKET SENTIMENT
        </div>
        
        {/* Labels below bar */}
        <div className="flex justify-between px-1">
          <div className={`font-medium ${sentimentLabel === "Bear" ? "text-red-600" : "text-gray-700"}`}>Bear</div>
          <div className={`font-medium ${sentimentLabel === "Neutral" ? "text-amber-500" : "text-gray-700"}`}>Neutral</div>
          <div className="font-medium text-black">Bull</div>
        </div>
      </div>
    </div>
  );
};

export default SentimentCoverage;
