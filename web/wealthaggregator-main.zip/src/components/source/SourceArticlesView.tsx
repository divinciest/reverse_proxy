import React, { useState } from "react";
import ArticlesList from "@/components/ArticlesList";
import NoArticlesView from "@/components/source/NoArticlesView";
import { Source } from "@/data/types";
import { Article } from "@/data/types";
import { convertDataArticleToApiArticle, convertApiArticleToUiArticle } from "@/utils/articleUtils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from "lucide-react";

interface SourceArticlesViewProps {
  source: Source;
  articles: Article[] | any[];
  isLoading: boolean;
  onRefresh: () => void;
  isApiAvailable?: boolean;
}

const SourceArticlesView = ({ 
  source, 
  articles, 
  isLoading, 
  onRefresh,
  isApiAvailable = true
}: SourceArticlesViewProps) => {
  const [view, setView] = useState<"grid" | "list">("grid");
  
  // Make sure articles have consistent format
  const processedArticles = articles.map(article => {
    // If article already has the right format, use it directly
    if (article.id && article.title && article.source) {
      return article;
    }
    // Otherwise convert it to the right format
    return convertApiArticleToUiArticle(article);
  });

  if (isLoading && articles.length === 0) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
          <p className="mt-2 text-muted-foreground">Loading articles...</p>
        </div>
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <NoArticlesView 
        sourceName={source.name} 
        onRefresh={onRefresh} 
        isLoading={isLoading} 
      />
    );
  }

  return (
    <>
      {!isApiAvailable && (
        <Alert className="mb-6 bg-amber-50 border-amber-200">
          <Info className="h-4 w-4" />
          <AlertTitle>Using Demo Data</AlertTitle>
          <AlertDescription>
            API connection is unavailable. Showing demo articles instead of live data.
          </AlertDescription>
        </Alert>
      )}

      <h2 className="text-2xl font-serif font-bold mb-6">Latest Articles from {source.name}</h2>
      <ArticlesList 
        articles={processedArticles} 
        view={view}
        articlesPerPage={12}
        featuredCount={view === "grid" ? 3 : 0} 
      />
    </>
  );
};

export default SourceArticlesView;
