
import React from "react";
import { Source } from "@/data/types";
import SourceLogo from "@/components/source/SourceLogo";
import SourceMetadata from "@/components/source/SourceMetadata";

interface SourceInfoProps {
  source: Source;
  lastFetched: string | null;
  articlesCount: number;
}

const SourceInfo = ({ source, lastFetched, articlesCount }: SourceInfoProps) => {
  return (
    <div className="flex flex-col md:flex-row items-center md:items-start gap-6 mb-8 pb-6 border-b border-gray-300">
      <SourceLogo 
        name={source.name} 
        url={source.url} 
        logoUrl={source.logoUrl} 
      />
      <SourceMetadata 
        name={source.name}
        category={source.category}
        url={source.url}
        lastFetched={lastFetched}
        articlesCount={articlesCount}
      />
    </div>
  );
};

export default SourceInfo;
