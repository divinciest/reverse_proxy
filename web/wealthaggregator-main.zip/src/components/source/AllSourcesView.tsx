import React, { useState } from "react";
import Header from "@/components/Header";
import TopicBar from "@/components/TopicBar";
import ArticlesList from "@/components/ArticlesList";
import SourceProfileHeader from "@/components/source/SourceProfileHeader";
import { convertApiArticleToUiArticle } from "@/utils/articleUtils";
import { useArticles } from "@/hooks/useArticles";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from "lucide-react";

const AllSourcesView = () => {
  const [view, setView] = useState<"grid" | "list">("grid");
  const { articles: apiArticles, isLoading, isApiAvailable } = useArticles();
  
  // Convert to appropriate article format
  const articles = apiArticles.map(convertApiArticleToUiArticle);
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="border-t border-gray-300">
        <TopicBar />
      </div>
      
      <div className="container mx-auto py-6">
        <SourceProfileHeader 
          onRefresh={() => {}} 
          isLoading={isLoading} 
          view={view} 
          onViewChange={setView} 
        />
        
        <div className="flex flex-col md:flex-row items-center gap-6 mb-8 pb-6 border-b border-gray-300">
          <h1 className="text-3xl font-serif font-bold">All Sources</h1>
        </div>
        
        {!isApiAvailable && (
          <Alert className="mb-6 bg-amber-50 border-amber-200">
            <Info className="h-4 w-4" />
            <AlertTitle>Using Demo Data</AlertTitle>
            <AlertDescription>
              API connection is unavailable. Showing demo articles instead of live data.
            </AlertDescription>
          </Alert>
        )}
        
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
              <p className="mt-2 text-muted-foreground">Loading articles...</p>
            </div>
          </div>
        ) : (
          <ArticlesList 
            articles={articles} 
            view={view}
            // Since we added the prop to ArticlesList, we can keep it here
            articlesPerPage={15}
          />
        )}
      </div>
    </div>
  );
};

export default AllSourcesView;
