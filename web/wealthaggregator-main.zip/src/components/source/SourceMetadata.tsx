
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Clock, ExternalLink } from "lucide-react";
import { formatLastFetchFromString } from "@/utils/feedUtils";

interface SourceMetadataProps {
  name: string;
  category?: string;
  url: string;
  lastFetched: string | null;
  articlesCount: number;
}

const SourceMetadata = ({ 
  name, 
  category, 
  url, 
  lastFetched, 
  articlesCount 
}: SourceMetadataProps) => {
  return (
    <div>
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-3xl font-serif font-bold">{name}</h1>
        <Badge variant="outline" className="px-2 py-1 flex items-center gap-1">
          <Clock size={12} />
          {articlesCount} articles
        </Badge>
      </div>
      
      <p className="text-lg text-muted-foreground mt-2 font-serif">
        {category}
      </p>
      
      <div className="mt-2 text-sm text-muted-foreground">
        <span className="flex items-center gap-1">
          <Clock size={14} />
          Last updated: {formatLastFetchFromString(lastFetched)}
        </span>
      </div>
      
      <div className="mt-4">
        <a 
          href={url} 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-primary hover:underline flex items-center gap-1"
        >
          Visit {name} website <ExternalLink size={14} />
        </a>
      </div>
    </div>
  );
};

export default SourceMetadata;
