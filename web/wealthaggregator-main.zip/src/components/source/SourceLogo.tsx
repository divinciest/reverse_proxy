import React, { useState, useEffect } from "react";
import { getBestFaviconUrl } from "@/utils/favicon";

interface SourceLogoProps {
  name: string;
  url?: string;
  logoUrl?: string;
}

const SourceLogo = ({ name, url, logoUrl }: SourceLogoProps) => {
  const [sourceLogo, setSourceLogo] = useState<string | null>(null);

  useEffect(() => {
    console.log(`Generating logo for source: ${name}`);
    let domain = "";
    const nameLower = name.toLowerCase();
    
    if (nameLower.includes("forbes")) domain = "forbes.com";
    else if (nameLower.includes("cnbc")) domain = "cnbc.com";
    else if (nameLower.includes("financial times")) domain = "ft.com";
    else if (nameLower.includes("wall street journal")) domain = "wsj.com";
    else if (nameLower.includes("yahoo")) domain = "finance.yahoo.com";
    else if (nameLower.includes("marketwatch")) domain = "marketwatch.com";
    else if (nameLower.includes("bloomberg")) domain = "bloomberg.com";
    else if (nameLower.includes("reuters")) domain = "reuters.com";
    else if (nameLower.includes("business insider")) domain = "businessinsider.com";
    else if (nameLower.includes("nbc")) domain = "nbcnews.com";
    else if (url) {
      try {
        const urlObj = new URL(url);
        domain = urlObj.hostname;
        console.log(`Extracted domain for ${name}: ${domain}`);
      } catch (e) {
        console.error("Invalid URL:", url);
      }
    }
    
    if (logoUrl) {
      setSourceLogo(logoUrl);
    } else {
      const logo = getBestFaviconUrl(name, domain || url);
      setSourceLogo(logo);
      console.log(`Source: ${name}, Domain: ${domain}, Generated Logo: ${logo}`);
    }
  }, [name, url, logoUrl]);

  return (
    <div className="w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden border border-gray-300">
      {sourceLogo ? (
        <img 
          src={sourceLogo} 
          alt={name} 
          className="max-w-full max-h-full object-contain p-2" 
          onError={(e) => {
            console.log(`Source logo error for ${name}:`, sourceLogo);
            const target = e.target as HTMLImageElement;
            if (!target.src.includes('generateCompanyLogo')) {
              target.src = getBestFaviconUrl(name);
              console.log(`Fallback to simple favicon for ${name}`);
            }
          }}
        />
      ) : (
        <span className="text-3xl font-bold font-serif text-gray-700">
          {name.substring(0, 2).toUpperCase()}
        </span>
      )}
    </div>
  );
};

export default SourceLogo;
