
import React from "react";
import { Button } from "@/components/ui/button";
import { RefreshCw, AlertCircle } from "lucide-react";

interface NoArticlesViewProps {
  sourceName: string;
  onRefresh: () => void;
  isLoading: boolean;
}

const NoArticlesView = ({ sourceName, onRefresh, isLoading }: NoArticlesViewProps) => {
  return (
    <div className="text-center py-12">
      <AlertCircle size={40} className="mx-auto text-muted-foreground mb-4" />
      <p className="text-lg font-serif text-muted-foreground mb-2">
        No articles found from {sourceName}.
      </p>
      <p className="text-sm text-muted-foreground mb-4">
        Articles may not be available for this source yet.
      </p>
      <Button onClick={onRefresh} disabled={isLoading} className="mt-4">
        <RefreshCw size={16} className={`mr-2 ${isLoading ? "animate-spin" : ""}`} />
        {isLoading ? "Fetching Articles..." : "Fetch Articles"}
      </Button>
    </div>
  );
};

export default NoArticlesView;
