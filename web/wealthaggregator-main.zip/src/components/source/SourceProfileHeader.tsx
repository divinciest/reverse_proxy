
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft, RefreshCw } from "lucide-react";
import ViewToggle from "@/components/ViewToggle";

interface SourceProfileHeaderProps {
  onRefresh: () => void;
  isLoading: boolean;
  view: "grid" | "list";
  onViewChange: (view: "grid" | "list") => void;
}

const SourceProfileHeader = ({
  onRefresh,
  isLoading,
  view,
  onViewChange
}: SourceProfileHeaderProps) => {
  return (
    <div className="flex items-center justify-between mb-8">
      <Link to="/">
        <Button variant="outline" className="flex items-center gap-2">
          <ArrowLeft size={16} />
          Back to Home
        </Button>
      </Link>
      
      <div className="flex items-center gap-3">
        <Button 
          variant="outline" 
          size="sm"
          onClick={onRefresh}
          disabled={isLoading}
          className="flex items-center gap-2"
        >
          <RefreshCw size={16} className={isLoading ? "animate-spin" : ""} />
          {isLoading ? "Refreshing..." : "Refresh Articles"}
        </Button>
        
        <ViewToggle activeView={view} onChange={onViewChange} />
      </div>
    </div>
  );
};

export default SourceProfileHeader;
