
import React from "react";
import { FinanceBook } from "@/utils/books";
import BookAuthorSection from "./BookAuthorSection";
import BookMetadata from "./BookMetadata";
import BookDescription from "./BookDescription";
import BookEditionDetails from "./BookEditionDetails";

interface BookDetailsProps {
  book: FinanceBook;
  description: string;
}

const BookDetails = ({ book, description }: BookDetailsProps) => {
  return (
    <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
      <h1 className="text-3xl font-serif font-bold mb-2">{book.title}</h1>
      
      {/* Author section with follow button */}
      <BookAuthorSection author={book.author} />
      
      {/* Book metadata */}
      <BookMetadata 
        year={book.year} 
        categories={book.category} 
        rating={book.rating} 
      />
      
      {/* Book description */}
      <BookDescription description={description} bookId={book.id} />
      
      {/* Edition information */}
      <BookEditionDetails bookId={book.id} />
    </div>
  );
};

export default BookDetails;
