
import React from "react";

interface BookEditionDetailsProps {
  bookId: string;
}

const BookEditionDetails = ({ bookId }: BookEditionDetailsProps) => {
  return (
    <div className="border-t border-gray-200 pt-6 mt-6">
      <h2 className="text-xl font-semibold mb-4">Edition Details</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div>
          <p className="text-gray-500 text-sm">Format</p>
          <p>Paperback</p>
        </div>
        <div>
          <p className="text-gray-500 text-sm">Language</p>
          <p>English</p>
        </div>
        <div>
          <p className="text-gray-500 text-sm">Publisher</p>
          <p>{bookId === "rich-dad-poor-dad" ? "Plata Publishing" : "Penguin Random House"}</p>
        </div>
        <div>
          <p className="text-gray-500 text-sm">Pages</p>
          <p>{Math.floor(Math.random() * 300) + 150}</p>
        </div>
      </div>
    </div>
  );
};

export default BookEditionDetails;
