
import React, { useState, useEffect } from "react";
import { getFallbackBookCoverImage } from "@/utils/books";
import { FinanceBook } from "@/utils/books";
import BookBuyButton from "./BookBuyButton";

interface BookCoverProps {
  book: FinanceBook;
}

const BookCover = ({ book }: BookCoverProps) => {
  const [imageError, setImageError] = useState(false);
  const [imageSrc, setImageSrc] = useState(book.coverImage);

  // Reset image error state when book changes
  useEffect(() => {
    setImageError(false);
    setImageSrc(book.coverImage);
  }, [book.id, book.coverImage]);

  const handleImageError = () => {
    setImageError(true);
    setImageSrc(getFallbackBookCoverImage(book.id));
  };

  return (
    <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100 flex justify-center">
      <div className="max-w-xs w-full">
        <img 
          src={imageSrc} 
          alt={book.title} 
          className="w-full object-cover rounded shadow-lg mx-auto"
          onError={handleImageError}
        />
        
        {/* Buy button */}
        <div className="mt-6">
          <BookBuyButton book={book} />
        </div>
      </div>
    </div>
  );
};

export default BookCover;
