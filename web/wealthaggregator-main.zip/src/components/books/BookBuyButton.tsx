import React, { useState, useRef, useEffect } from "react";
import { ChevronDown, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FinanceBook } from "@/utils/books";

interface BookBuyButtonProps {
  book: FinanceBook;
}

type Retailer = {
  name: string;
  url: string;
  logo?: string;
};

const BookBuyButton: React.FC<BookBuyButtonProps> = ({ book }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Example retailers with logos
  const retailers: Retailer[] = [
    { name: "Amazon", url: book.affiliateUrl || "https://www.amazon.com", logo: "https://m.media-amazon.com/images/G/01/gc/designs/livepreview/a_amazon_logo_RGB_REV.png" },
    { name: "Blackwell's", url: "https://blackwells.co.uk", logo: "https://blackwells.co.uk/bookshop/assets/img/blackwells_logo_new.png" },
    { name: "Bookshop.org", url: "https://bookshop.org", logo: "https://images.booksense.com/images/bookshop-logo.png" },
    { name: "Barnes & Noble", url: "https://www.barnesandnoble.com", logo: "https://logos-world.net/wp-content/uploads/2020/11/Barnes-Noble-Logo.png" },
    { name: "Book Depository", url: "https://www.bookdepository.com", logo: "https://www.bookdepository.com/content/images/header/brand-logo.png" },
    { name: "Waterstones", url: "https://www.waterstones.com", logo: "https://www.waterstones.com/images/logo-waterstones.svg" },
  ];

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleRetailerClick = (retailerUrl: string) => {
    // Open the retailer's page in a new tab
    window.open(retailerUrl, "_blank", "noopener,noreferrer");
    setIsOpen(false);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <Button
        onClick={toggleDropdown}
        className="w-full bg-green-500 hover:bg-green-600 text-white flex items-center justify-between"
      >
        <div className="flex items-center">
          <ShoppingCart className="mr-2 h-4 w-4" />
          Buy the book
        </div>
        <ChevronDown className={`ml-2 h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </Button>
      
      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg">
          <div className="py-1">
            {retailers.map((retailer) => (
              <button
                key={retailer.name}
                className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 focus:bg-gray-100 focus:outline-none flex items-center"
                onClick={() => handleRetailerClick(retailer.url)}
              >
                <span className="flex-grow">{retailer.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default BookBuyButton;
