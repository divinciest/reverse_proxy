
import React from "react";
import { Calendar, BookOpen, Star } from "lucide-react";

interface BookMetadataProps {
  year: number;
  categories?: string[];
  rating?: number;
}

const BookMetadata = ({ year, categories, rating }: BookMetadataProps) => {
  return (
    <div className="flex flex-wrap gap-6 mb-6 text-gray-600">
      <div className="flex items-center">
        <Calendar className="h-5 w-5 mr-2" />
        <span>Published: {year}</span>
      </div>
      <div className="flex items-center">
        <BookOpen className="h-5 w-5 mr-2" />
        <span>Category: {categories?.join(", ") || "Finance"}</span>
      </div>
      <div className="flex items-center">
        <div className="flex items-center">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              className={`h-5 w-5 ${
                i < Math.floor(rating || 0) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
              }`}
            />
          ))}
          <span className="ml-2">{rating} ({Math.floor(Math.random() * 1000) + 100} ratings)</span>
        </div>
      </div>
    </div>
  );
};

export default BookMetadata;
