
import React from "react";

interface BookDescriptionProps {
  description: string;
  bookId: string;
}

const BookDescription = ({ description, bookId }: BookDescriptionProps) => {
  return (
    <div className="mb-8">
      <h2 className="text-xl font-semibold mb-4">About this book</h2>
      <div className="text-gray-700 space-y-4">
        <p>{description}</p>
      </div>
      
      {/* Part of series if applicable */}
      {bookId === "rich-dad-poor-dad" && (
        <div className="mt-6">
          <h2 className="text-xl font-semibold mb-4">Part of a series</h2>
          <p className="text-gray-700">This book is part of the Rich Dad Poor Dad series (18 books)</p>
        </div>
      )}
    </div>
  );
};

export default BookDescription;
