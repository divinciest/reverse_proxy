
import React from "react";
import { User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface BookAuthorSectionProps {
  author: string;
}

const BookAuthorSection = ({ author }: BookAuthorSectionProps) => {
  const { toast } = useToast();

  const handleFollowAuthor = () => {
    toast({
      title: "Author followed",
      description: `You are now following ${author}`
    });
  };

  return (
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center">
        <User className="h-5 w-5 text-gray-500 mr-2" />
        <span className="text-lg">{author}</span>
      </div>
      <Button onClick={handleFollowAuthor} variant="outline" size="sm">
        Follow Author
      </Button>
    </div>
  );
};

export default BookAuthorSection;
