
import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const BookNotFound = () => {
  return (
    <Card className="mt-8">
      <CardContent className="py-12 text-center">
        <h1 className="text-2xl font-serif mb-4">Book Not Found</h1>
        <p className="mb-6">The book you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link to="/books" className="flex items-center">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Books
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
};

export default BookNotFound;
