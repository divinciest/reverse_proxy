
import React from "react";
import { Link } from "react-router-dom";
import { FinanceBook } from "@/utils/books";
import BookCard from "./BookCard";

interface BookGridProps {
  books: FinanceBook[];
  view: "grid" | "list";
}

const BookGrid: React.FC<BookGridProps> = ({ books, view }) => {
  if (!books || books.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">No books found matching your criteria.</p>
      </div>
    );
  }

  return (
    <div className={`grid grid-cols-1 ${view === "grid" ? 
      "sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4" : 
      "sm:grid-cols-1"} gap-6 mt-6`}>
      {books.map((book) => (
        <BookCard key={book.id} book={book} />
      ))}
    </div>
  );
};

export default BookGrid;
