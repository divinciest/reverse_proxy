
import React from "react";
import { LineChart } from "lucide-react";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import StockChart from "@/components/StockChart";

interface StockChartCardProps {
  data: Array<{time: string; price: number}>;
  loading: boolean;
}

const StockChartCard = ({ data, loading }: StockChartCardProps) => {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Daily Chart</CardTitle>
          <LineChart size={16} className="text-muted-foreground" />
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-[200px] flex items-center justify-center">
            <p>Loading chart...</p>
          </div>
        ) : (
          <StockChart 
            data={data}
            height={200}
            width={300} 
            showTooltip={true}
            showAxis={true}
            className="w-full"
          />
        )}
      </CardContent>
    </Card>
  );
};

export default StockChartCard;
