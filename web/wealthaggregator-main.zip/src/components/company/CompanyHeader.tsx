
import React, { useState } from "react";
import { TrendingUp, TrendingDown, ExternalLink, ChevronDown, ChevronUp, User, Calendar, Globe, Users } from "lucide-react";

interface CompanyInfo {
  ceo?: string;
  founded?: string;
  website?: string;
  employees?: string;
}

interface CompanyHeaderProps {
  name: string;
  ticker: string;
  exchange: string;
  price: number;
  change: number;
  changePercent: number;
  description: string;
  companyInfo?: CompanyInfo;
}

const CompanyHeader = ({
  name,
  ticker,
  exchange,
  price,
  change,
  changePercent,
  description,
  companyInfo
}: CompanyHeaderProps) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="md:col-span-2">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">{name}</h1>
          <div className="flex items-center text-sm text-muted-foreground mt-1">
            <span className="font-medium">{ticker}</span>
            <span className="mx-1">•</span>
            <span>{exchange}</span>
            <a 
              href={`https://www.google.com/finance/quote/${ticker}:${exchange}`}
              target="_blank" 
              rel="noopener noreferrer"
              className="ml-2 text-primary inline-flex items-center"
            >
              <ExternalLink size={12} className="ml-1" />
            </a>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-2xl font-bold">${price}</div>
          <div className={`flex items-center justify-end ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {change >= 0 ? (
              <TrendingUp size={16} className="mr-1" />
            ) : (
              <TrendingDown size={16} className="mr-1" />
            )}
            <span>
              {change >= 0 ? '+' : ''}{change} ({changePercent}%)
            </span>
          </div>
        </div>
      </div>
      
      <div className="mb-6 border rounded-lg p-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-xl font-semibold">About</h2>
          <button 
            onClick={() => setExpanded(!expanded)} 
            className="text-gray-500 hover:text-gray-700"
          >
            {expanded ? <ChevronUp size={24} /> : <ChevronDown size={24} />}
          </button>
        </div>
        
        <div className={`overflow-hidden transition-all duration-300 ${expanded ? 'max-h-[1000px]' : 'max-h-24'}`}>
          <p className="text-muted-foreground mb-4">{description}</p>
          
          {companyInfo && Object.keys(companyInfo).length > 0 && (
            <div className="mt-6 space-y-4 border-t pt-4">
              {companyInfo.ceo && (
                <div className="flex items-center justify-between border-b pb-3">
                  <div className="flex items-center text-muted-foreground">
                    <User size={18} className="mr-2" />
                    <span>CEO</span>
                  </div>
                  <div className="font-medium text-blue-600">
                    <a href={`https://www.google.com/search?q=${encodeURIComponent(companyInfo.ceo)}`} target="_blank" rel="noopener noreferrer">
                      {companyInfo.ceo}
                    </a>
                  </div>
                </div>
              )}
              
              {companyInfo.founded && (
                <div className="flex items-center justify-between border-b pb-3">
                  <div className="flex items-center text-muted-foreground">
                    <Calendar size={18} className="mr-2" />
                    <span>FOUNDED</span>
                  </div>
                  <div className="font-medium">
                    {companyInfo.founded}
                  </div>
                </div>
              )}
              
              {companyInfo.website && (
                <div className="flex items-center justify-between border-b pb-3">
                  <div className="flex items-center text-muted-foreground">
                    <Globe size={18} className="mr-2" />
                    <span>WEBSITE</span>
                  </div>
                  <div className="font-medium text-blue-600">
                    <a href={`https://${companyInfo.website}`} target="_blank" rel="noopener noreferrer">
                      {companyInfo.website}
                    </a>
                  </div>
                </div>
              )}
              
              {companyInfo.employees && (
                <div className="flex items-center justify-between pb-3">
                  <div className="flex items-center text-muted-foreground">
                    <Users size={18} className="mr-2" />
                    <span>EMPLOYEES</span>
                  </div>
                  <div className="font-medium">
                    {companyInfo.employees}
                  </div>
                </div>
              )}
              
              <div className="text-sm text-blue-600">
                <a href="https://en.wikipedia.org/wiki/Tesla,_Inc." target="_blank" rel="noopener noreferrer">
                  Wikipedia
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CompanyHeader;
