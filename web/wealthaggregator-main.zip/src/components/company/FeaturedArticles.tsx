
import React from "react";
import { Link } from "react-router-dom";
import { Newspaper } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Article } from "@/data";
import ArticleImage from "@/components/ArticleImage";

interface FeaturedArticlesProps {
  articles: Article[];
}

const FeaturedArticles = ({ articles }: FeaturedArticlesProps) => {
  if (articles.length === 0) {
    return null;
  }
  
  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Featured Articles</h2>
        <Newspaper size={18} className="text-muted-foreground" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {articles.map(article => (
          <Link to={`/article/${article.id}`} key={article.id} className="block">
            <Card className="h-full hover:shadow-md transition-shadow">
              <ArticleImage 
                imageUrl={article.imageUrl} 
                title={article.title} 
                sentiment={article.sentiment} 
                source={article.source}
                imageClassName="rounded-t-lg"
              />
              <CardContent className="pt-4">
                <h3 className="font-semibold line-clamp-2 mb-2">{article.title}</h3>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{new Date(article.publishDate).toLocaleDateString()}</span>
                  <span>{article.source}</span>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default FeaturedArticles;
