
import React from "react";
import { Article } from "@/data/types";
import ArticlesList from "@/components/ArticlesList";
import FeaturedArticles from "@/components/company/FeaturedArticles";
import CompanyNewsSection from "@/components/company/CompanyNewsSection";
import { convertDataArticleToApiArticle } from "@/utils/articleUtils";

interface CompanyArticlesProps {
  companyId: string | undefined;
  articles: Article[];
  isLoading?: boolean; // Added isLoading prop
}

const CompanyArticles = ({ companyId, articles, isLoading = false }: CompanyArticlesProps) => {
  // Sort articles by publish date (newest first)
  const sortedArticles = [...articles].sort((a, b) => 
    new Date((b.publishDate || b.date || new Date().toISOString())).getTime() - 
    new Date((a.publishDate || a.date || new Date().toISOString())).getTime()
  );
  
  // If loading, show loading state
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
          <p className="mt-2 text-muted-foreground">Loading articles...</p>
        </div>
      </div>
    );
  }
  
  // Get top news articles (first 3 articles)
  const topNews = sortedArticles.slice(0, 3);
  
  // Get featured articles (next 3 articles, not in top news)
  const featuredArticles = sortedArticles.slice(3, 6);
  
  // Get remaining articles (excluding the first 6)
  const otherArticles = sortedArticles.slice(6);

  // Get articles for "By the numbers" section (3 articles after featured section)
  const byTheNumbersArticles = sortedArticles.slice(6, 9);

  // Convert to API article format
  const convertedOtherArticles = otherArticles.map(convertDataArticleToApiArticle);

  return (
    <>
      <CompanyNewsSection articles={topNews} title="Top news" />
      
      <CompanyNewsSection 
        articles={byTheNumbersArticles} 
        title="By the numbers" 
      />

      <FeaturedArticles articles={featuredArticles} />

      <div>
        <h2 className="text-xl font-semibold mb-4">All Articles</h2>
        <ArticlesList articles={convertedOtherArticles} view="list" />
      </div>
    </>
  );
};

export default CompanyArticles;
