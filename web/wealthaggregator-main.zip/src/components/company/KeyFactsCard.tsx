
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableRow } from "@/components/ui/table";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Either accept the company data interface from CompanyData.ts
// or use additional properties for market data
interface CompanyDataType {
  id: string;
  name: string;
  ticker: string;
  exchange: string;
  price: number;
  change: number;
  changePercent: number;
  industry: string;
  description: string;
  marketCap?: string;
  volume?: string;
  pe?: number;
  eps?: number;
  dividend?: string;
  beta?: number;
}

interface KeyFactsCardProps {
  companyData: CompanyDataType;
}

const KeyFactsCard = ({ companyData }: KeyFactsCardProps) => {
  // Check if we have real market data
  const hasMarketData = 
    companyData.marketCap !== undefined && 
    companyData.volume !== undefined &&
    companyData.pe !== undefined &&
    companyData.eps !== undefined &&
    companyData.dividend !== undefined &&
    companyData.beta !== undefined;

  if (!hasMarketData) {
    return (
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Key Facts</h2>
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>API Not Available</AlertTitle>
          <AlertDescription>
            Market data API is not implemented or unavailable. This system requires a real API connection.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <h2 className="text-xl font-semibold mb-4">Key Facts</h2>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">Market Cap</TableCell>
                <TableCell>{companyData.marketCap}</TableCell>
                <TableCell className="font-medium">P/E Ratio</TableCell>
                <TableCell>{companyData.pe}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Volume</TableCell>
                <TableCell>{companyData.volume}</TableCell>
                <TableCell className="font-medium">EPS</TableCell>
                <TableCell>${companyData.eps}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Dividend</TableCell>
                <TableCell>{companyData.dividend}</TableCell>
                <TableCell className="font-medium">Beta</TableCell>
                <TableCell>{companyData.beta}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default KeyFactsCard;
