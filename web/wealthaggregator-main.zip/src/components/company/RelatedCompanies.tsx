import React from "react";
import { Link } from "react-router-dom";
import { Building, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { getBestFaviconUrl } from "@/utils/favicon";

interface CompanyData {
  id: string;
  name: string;
  ticker: string;
  logo?: string;
  industry: string;
}

interface RelatedCompaniesProps {
  companies: CompanyData[];
  currentCompanyId: string;
}

const RelatedCompanies = ({ companies, currentCompanyId }: RelatedCompaniesProps) => {
  // Filter out the current company and limit to 3 companies
  const relatedCompanies = companies
    .filter(company => company.id !== currentCompanyId)
    .slice(0, 3);

  if (relatedCompanies.length === 0) {
    return null;
  }

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Related Companies</h2>
        <Building size={18} className="text-muted-foreground" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {relatedCompanies.map(company => (
          <Card key={company.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center space-x-4">
                <Avatar className="h-12 w-12 border border-gray-200">
                  <AvatarImage 
                    src={company.logo || getBestFaviconUrl(company.name)}
                    alt={company.name}
                  />
                  <AvatarFallback className="bg-gray-100 text-gray-800 font-bold">
                    {company.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold">{company.name}</h3>
                  <p className="text-sm text-muted-foreground">{company.ticker}</p>
                </div>
                <Link to={`/company/${company.id}`} className="text-primary hover:text-primary/80">
                  <ArrowRight size={16} />
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default RelatedCompanies;
