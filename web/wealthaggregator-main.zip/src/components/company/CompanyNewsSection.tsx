
import React from "react";
import { Link } from "react-router-dom";
import { ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Article } from "@/data/types";

interface CompanyNewsProps {
  articles: Article[];
  title?: string;
}

const CompanyNewsSection = ({ articles, title = "Latest News" }: CompanyNewsProps) => {
  if (articles.length === 0) {
    return null;
  }

  // Function to format the time relative to now (e.g. "2 days ago", "10 hours ago")
  const getRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return `${diffInSeconds} seconds ago`;
    }
    
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
      return `${diffInMinutes} minute${diffInMinutes === 1 ? '' : 's'} ago`;
    }
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return `${diffInHours} hour${diffInHours === 1 ? '' : 's'} ago`;
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 30) {
      return `${diffInDays} day${diffInDays === 1 ? '' : 's'} ago`;
    }
    
    const diffInMonths = Math.floor(diffInDays / 30);
    if (diffInMonths < 12) {
      return `${diffInMonths} month${diffInMonths === 1 ? '' : 's'} ago`;
    }
    
    return `${Math.floor(diffInMonths / 12)} year${Math.floor(diffInMonths / 12) === 1 ? '' : 's'} ago`;
  };

  return (
    <div className="mb-8">
      <h2 className="text-xl font-semibold mb-4">{title}</h2>
      
      <div className="space-y-4">
        {articles.slice(0, 6).map((article, index) => (
          <Card key={article.id} className="overflow-hidden hover:shadow-md transition-shadow">
            <div className="flex flex-col md:flex-row">
              {article.imageUrl && (
                <div className="w-full md:w-1/4 h-48 md:h-auto">
                  <img 
                    src={article.imageUrl} 
                    alt={article.title} 
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
              )}
              
              <CardContent className={`flex-1 p-4 ${!article.imageUrl ? 'w-full' : ''}`}>
                <div className="flex items-center text-sm text-muted-foreground mb-1">
                  <span className="font-medium">{article.source}</span>
                </div>
                <h3 className="font-semibold text-lg mb-2 hover:text-blue-600">
                  <a 
                    href={article.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:underline"
                  >
                    {article.title}
                  </a>
                </h3>
                <p className="text-muted-foreground line-clamp-2 mb-3 text-sm">{article.summary}</p>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">
                    {getRelativeTime(article.publishDate)}
                  </span>
                  <a 
                    href={article.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline text-xs flex items-center"
                  >
                    Read more <ExternalLink size={12} className="ml-1" />
                  </a>
                </div>
              </CardContent>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default CompanyNewsSection;
