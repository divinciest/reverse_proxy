
import React from "react";
import { CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";
import TopicBadge from "@/components/TopicBadge";
import { Link } from "react-router-dom";

interface ArticleFooterProps {
  topics: string[];
  url: string;
  onTopicClick?: (topic: string) => void;
}

const ArticleFooter = ({ topics, url, onTopicClick }: ArticleFooterProps) => {
  if (!topics.length) return null;
  
  return (
    <CardFooter className="flex flex-col items-start pt-0 px-4 pb-4">
      <div className="flex flex-wrap gap-2 mb-3">
        {topics.slice(0, 3).map((topic) => (
          <Link 
            key={topic} 
            to={`/topic/${encodeURIComponent(topic.replace(/ /g, '-'))}`}
            onClick={(e) => {
              if (onTopicClick) {
                e.preventDefault();
                onTopicClick(topic);
              }
            }}
          >
            <TopicBadge topic={topic} variant="topic" />
          </Link>
        ))}
      </div>
      
      <div className="mt-2 w-full flex justify-between items-center">
        {topics.length > 3 && (
          <div className="text-xs text-muted-foreground">
            +{topics.length - 3} more topics
          </div>
        )}
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="ml-auto text-xs h-8 px-2 hover:bg-gray-100"
          asChild
        >
          <a 
            href={url} 
            target="_blank" 
            rel="noopener noreferrer" 
            onClick={(e) => e.stopPropagation()}
          >
            Source <ExternalLink className="h-3 w-3 ml-1" />
          </a>
        </Button>
      </div>
    </CardFooter>
  );
};

export default ArticleFooter;
