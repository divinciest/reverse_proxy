
import React, { useState } from "react";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";

export interface SearchBarProps {
  placeholder?: string;
  className?: string;
  onSearch?: (query: string) => void;
  value?: string;
  onChange?: (value: string) => void;
}

const SearchBar = ({
  placeholder = "Search...",
  className,
  onSearch,
  value,
  onChange
}: SearchBarProps) => {
  const [query, setQuery] = useState(value || "");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(query);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setQuery(newValue);
    if (onChange) {
      onChange(newValue);
    }
  };

  return (
    <form
      className={cn(
        "relative rounded-lg border border-gray-300 focus-within:border-primary transition-colors",
        className
      )}
      onSubmit={handleSubmit}
    >
      <input
        type="text"
        placeholder={placeholder}
        value={query}
        onChange={handleChange}
        className="w-full pl-4 pr-10 py-2 rounded-lg text-sm focus:outline-none"
      />
      <button
        type="submit"
        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-primary"
      >
        <Search size={18} />
      </button>
    </form>
  );
};

export default SearchBar;
