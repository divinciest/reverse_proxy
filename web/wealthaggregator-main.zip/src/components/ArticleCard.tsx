
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import TopicBadge from "@/components/TopicBadge";
import SourceLabel from "@/components/SourceLabel";
import ArticleImage from "@/components/ArticleImage";
import DateHeader from "@/components/DateHeader";
import { Article } from "@/data/types";

interface ArticleCardProps {
  article: Article;
  onTopicClick?: (topic: string) => void;
  openInNewTab?: boolean;
  className?: string;
  imageClassName?: string;
  contentClassName?: string;
  onClick?: () => void;
}

const ArticleCard = ({ 
  article, 
  onTopicClick, 
  openInNewTab = false,
  className = "",
  imageClassName = "",
  contentClassName = "",
  onClick
}: ArticleCardProps) => {
  // Default fallback image
  const imageUrl = article.imageUrl || "/placeholder.svg";
  
  // Prepare target and rel attributes for links
  const linkProps = openInNewTab 
    ? { target: "_blank", rel: "noopener noreferrer" } 
    : {};
  
  const handleCardClick = () => {
    if (onClick) {
      onClick();
    }
  };
  
  // IMPORTANT: Do not modify the tag handling logic below, as it's critical for proper tag display
  // This ensures we always have tags to display by using a fallback priority system
  const displayTags = article.tags || article.topics || [];
  
  return (
    <Card 
      className={`overflow-hidden transition-shadow hover:shadow-md ${className}`}
      onClick={handleCardClick}
    >
      <div className="flex flex-col h-full">
        {/* Image container - now at the top */}
        <div className="relative h-48">
          <ArticleImage 
            imageUrl={imageUrl} 
            title={article.title}
            altText={article.title}
            sentiment={article.sentiment || "neutral"} 
            imageClassName={`object-cover w-full h-full ${imageClassName}`} 
            source={article.source}
            showSentiment={true} // Show sentiment badge in the image
          />
        </div>
        
        {/* Content container - now below the image */}
        <CardContent className={`p-4 flex flex-col flex-grow ${contentClassName}`}>
          <div className="mb-1">
            <SourceLabel 
              source={article.source} 
              sourceUrl={article.sourceUrl} 
            />
          </div>
          
          <Link 
            to={article.url || "#"} 
            className="group mb-2"
            {...linkProps}
            onClick={(e) => onClick && e.preventDefault()}
          >
            <h3 className="text-xl font-bold font-serif mb-2 group-hover:text-blue-700 transition-colors line-clamp-2">
              {article.title}
            </h3>
          </Link>
          
          <p className="text-gray-700 mb-4 line-clamp-3 flex-grow">
            {article.summary}
          </p>
          
          <div className="mt-auto">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap gap-2">
                {displayTags.length > 0 ? (
                  displayTags.map((tag, index) => (
                    <TopicBadge 
                      key={`${tag}-${index}`}
                      topic={tag} 
                      onClick={onTopicClick ? () => onTopicClick(tag) : undefined}
                    />
                  ))
                ) : (
                  <TopicBadge 
                    topic="Uncategorized" 
                    variant="default"
                  />
                )}
              </div>
              
              <div className="flex items-center text-sm text-gray-500">
                <DateHeader date={article.date} hoursAgo={article.hoursAgo} />
              </div>
            </div>
          </div>
        </CardContent>
      </div>
    </Card>
  );
};

export default ArticleCard;
