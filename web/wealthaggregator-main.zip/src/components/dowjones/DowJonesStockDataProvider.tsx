
import React, { useState, useEffect, useCallback } from 'react';
import { getDowJonesStocks, getDowJonesIndex, DowJonesIndex, DowJonesStock } from '@/utils/dowJonesDataService';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

/**
 * CRITICAL WARNING - ZERO TOLERANCE POLICY FOR MOCK DATA
 * 
 * ABSOLUTELY NO MOCK DATA IS ALLOWED IN THIS COMPONENT, UNDER ANY CIRCUMSTANCES.
 * 
 * This file MUST only fetch data EXCLUSIVELY from real market data APIs.
 * Even in the case of errors, testing, or development, NO HARDCODED DATA
 * or FALLBACK VALUES are permitted.
 * 
 * Violation of this policy is strictly forbidden.
 * 
 * If API calls fail:
 * - Display appropriate error states
 * - Log the error
 * - But NEVER fall back to sample/mock/hardcoded data
 * 
 * NO EXCEPTIONS. NO TEMPORARY SOLUTIONS.
 */

interface DowJonesProviderState {
  djiaIndex: DowJonesIndex | null;
  indexLoading: boolean;
  indexError: Error | null;
  stocksData: DowJonesStock[];
  stocksError: Error | null;
  loading: boolean;
  handleRefresh: () => void;
  fetchIndexData: () => Promise<void>;
  fetchStocksData: () => Promise<void>;
}

interface DowJonesStockDataProviderProps {
  children: (state: DowJonesProviderState) => React.ReactNode;
}

const DowJonesStockDataProvider: React.FC<DowJonesStockDataProviderProps> = ({ children }) => {
  const [djiaIndex, setDjiaIndex] = useState<DowJonesIndex | null>(null);
  const [stocksData, setStocksData] = useState<DowJonesStock[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [indexLoading, setIndexLoading] = useState<boolean>(true);
  const [indexError, setIndexError] = useState<Error | null>(null);
  const [stocksError, setStocksError] = useState<Error | null>(null);

  const fetchIndexData = useCallback(async () => {
    try {
      setIndexLoading(true);
      setIndexError(null);
      
      // Must use real API call, which will currently throw an error since mock data is forbidden
      const data = getDowJonesIndex();
      setDjiaIndex(data);
    } catch (error) {
      console.error("Error fetching Dow Jones index data:", error);
      setIndexError(error as Error);
      setDjiaIndex(null);
    } finally {
      setIndexLoading(false);
    }
  }, []);

  const fetchStocksData = useCallback(async () => {
    try {
      setLoading(true);
      setStocksError(null);
      
      // Must use real API call, which will currently throw an error since mock data is forbidden
      const data = getDowJonesStocks();
      setStocksData(data);
    } catch (error) {
      console.error("Error fetching Dow Jones stocks:", error);
      setStocksError(error as Error);
      setStocksData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchIndexData();
    fetchStocksData();
  }, [fetchIndexData, fetchStocksData]);

  const handleRefresh = useCallback(() => {
    fetchIndexData();
    fetchStocksData();
  }, [fetchIndexData, fetchStocksData]);

  const providerState: DowJonesProviderState = {
    djiaIndex,
    indexLoading,
    indexError,
    stocksData,
    stocksError,
    loading,
    handleRefresh,
    fetchIndexData,
    fetchStocksData
  };

  // Provide the state to child components
  return <>{children(providerState)}</>;
};

export default DowJonesStockDataProvider;
