
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, RefreshCw } from "lucide-react";
import DowJonesStocksGridView from './DowJonesStocksGridView';
import DowJonesStocksListView from './DowJonesStocksListView';
import { DowJonesStock } from '@/utils/dowJonesDataService';
import DowJonesStocksHeader from './DowJonesStocksHeader';

interface DowJonesStocksDisplaySectionProps {
  stocksData: DowJonesStock[];
  loading: boolean;
  stocksError: Error | null;
  onRefresh: () => void;
  fetchStocksData: () => Promise<void>;
}

const DowJonesStocksDisplaySection = ({
  stocksData,
  loading,
  stocksError,
  onRefresh,
  fetchStocksData
}: DowJonesStocksDisplaySectionProps) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'rank' | 'weight' | 'price' | 'change' | 'name'>('rank');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Handler for sort change
  const handleSortChange = (newSortBy: 'rank' | 'weight' | 'price' | 'change' | 'name') => {
    if (sortBy === newSortBy) {
      // Toggle sort order if clicking the same column
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      // Set new sort column with default order
      setSortBy(newSortBy);
      setSortOrder('asc');
    }
  };

  // Sort stocks based on current sort criteria
  const sortedStocks = [...stocksData].sort((a, b) => {
    let comparison = 0;
    
    if (sortBy === 'name') {
      comparison = a.name.localeCompare(b.name);
    } else if (sortBy === 'change') {
      comparison = a.changePercent - b.changePercent;
    } else {
      comparison = a[sortBy] - b[sortBy];
    }
    
    return sortOrder === 'asc' ? comparison : -comparison;
  });

  if (stocksError) {
    return (
      <Alert variant="destructive" className="mb-8">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription className="flex justify-between items-center">
          <span>Failed to load Dow Jones stocks: {stocksError.message}</span>
          <button 
            onClick={fetchStocksData}
            className="px-3 py-1 bg-red-100 text-red-800 rounded-md text-sm hover:bg-red-200"
          >
            Retry
          </button>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="mb-8">
      <DowJonesStocksHeader 
        viewMode={viewMode} 
        setViewMode={setViewMode}
        loading={loading}
        onRefresh={onRefresh}
      />

      {viewMode === 'grid' ? (
        <DowJonesStocksGridView 
          stocks={sortedStocks} 
          loading={loading} 
          onSortChange={handleSortChange}
          sortBy={sortBy}
          sortOrder={sortOrder}
        />
      ) : (
        <DowJonesStocksListView 
          stocks={sortedStocks} 
          loading={loading}
          onSortChange={handleSortChange}
          sortBy={sortBy}
          sortOrder={sortOrder}
        />
      )}
    </div>
  );
};

export default DowJonesStocksDisplaySection;
