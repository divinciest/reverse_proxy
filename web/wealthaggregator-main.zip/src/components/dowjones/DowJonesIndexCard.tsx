
import React from "react";
import { ArrowUp, ArrowDown, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { DowJonesIndex } from "@/utils/dowJonesDataService";
import { Link } from "react-router-dom";

interface DowJonesIndexCardProps {
  index: DowJonesIndex;
  isLoading?: boolean;
}

const DowJonesIndexCard = ({ index, isLoading = false }: DowJonesIndexCardProps) => {
  if (isLoading) {
    return (
      <div className="w-full bg-white rounded-lg border p-4 mb-8">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-36" />
          <Skeleton className="h-8 w-48" />
        </div>
        <Skeleton className="h-4 w-full mt-4" />
        <Skeleton className="h-4 w-2/3 mt-2" />
        <div className="flex gap-2 mt-4">
          <Skeleton className="h-9 w-32" />
          <Skeleton className="h-9 w-32" />
        </div>
      </div>
    );
  }

  const isPositive = index.changePercent >= 0;
  
  return (
    <div className="w-full bg-white rounded-lg border p-4 mb-8 hover:shadow-md transition-shadow">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div className="mb-3 sm:mb-0">
          <h2 className="text-2xl font-bold">Dow Jones Industrial Average</h2>
          <Link to="/dowjones" className="text-blue-600 hover:underline text-sm">DJIA Index</Link>
        </div>
        <div className="flex flex-col items-start sm:items-end">
          <div className="text-3xl font-mono">
            {index.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className={cn(
            "flex items-center",
            isPositive ? "text-green-600" : "text-red-600"
          )}>
            {isPositive ? (
              <ArrowUp className="h-4 w-4 mr-1" />
            ) : (
              <ArrowDown className="h-4 w-4 mr-1" />
            )}
            <span className="font-mono">
              {isPositive ? '+' : ''}{index.change.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ({isPositive ? '+' : ''}{index.changePercent.toFixed(2)}%)
            </span>
          </div>
        </div>
      </div>
      
      <div className="mt-4 text-gray-500 flex items-center">
        <Clock className="h-4 w-4 mr-1" />
        <span className="text-sm">Last updated: {index.lastUpdated}</span>
      </div>
      
      <div className="mt-4 flex flex-wrap gap-2">
        <Link 
          to="/stocks"
          className="bg-blue-50 text-blue-700 px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-100"
        >
          View All Stocks
        </Link>
        <Link 
          to="/markets"
          className="bg-gray-100 text-gray-700 px-4 py-2 rounded-md text-sm font-medium hover:bg-gray-200"
        >
          All Markets
        </Link>
      </div>
    </div>
  );
};

export default DowJonesIndexCard;
