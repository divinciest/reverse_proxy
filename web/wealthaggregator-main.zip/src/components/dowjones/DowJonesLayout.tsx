
import React from "react";
import Header from "@/components/Header";
import StockTickerTape from "@/components/StockTickerTape";
import BreadcrumbNav from "@/components/BreadcrumbNav";

interface DowJonesLayoutProps {
  children: React.ReactNode;
}

const DowJonesLayout: React.FC<DowJonesLayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="border-t-2 border-b-2 border-gray-800">
        <StockTickerTape />
      </div>
      
      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={[{ label: "Markets", href: "/markets" }, { label: "Dow Jones" }]} />
        
        {children}
        
        {/* Citation */}
        <div className="text-xs text-gray-500 text-center mt-8 pb-4">
          Index data courtesy of Dow Jones Indices LLC
        </div>
      </div>
    </div>
  );
};

export default DowJonesLayout;
