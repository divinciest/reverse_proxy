
import React from "react";
import { DowJonesIndex, DowJonesStock } from "@/utils/dowJonesDataService";
import DowJonesIndexCardSection from "./DowJonesIndexCardSection";
import DowJonesStocksDisplaySection from "./DowJonesStocksDisplaySection";

interface DowJonesPageContentProps {
  djiaIndex: DowJonesIndex | null;
  indexLoading: boolean;
  indexError: Error | null;
  stocksData: DowJonesStock[];
  stocksError: Error | null;
  loading: boolean;
  handleRefresh: () => void;
  fetchIndexData: () => Promise<void>;
  fetchStocksData: () => Promise<void>;
}

const DowJonesPageContent: React.FC<DowJonesPageContentProps> = ({
  djiaIndex,
  indexLoading,
  indexError,
  stocksData,
  stocksError,
  loading,
  handleRefresh,
  fetchIndexData,
  fetchStocksData
}) => {
  return (
    <>
      {/* Dow Jones Index Card Section */}
      <DowJonesIndexCardSection 
        djiaIndex={djiaIndex}
        indexLoading={indexLoading}
        indexError={indexError}
        fetchIndexData={fetchIndexData}
      />
      
      {/* Stocks Display Section */}
      <DowJonesStocksDisplaySection 
        stocksData={stocksData}
        loading={loading}
        stocksError={stocksError}
        onRefresh={handleRefresh}
        fetchStocksData={fetchStocksData}
      />
    </>
  );
};

export default DowJonesPageContent;
