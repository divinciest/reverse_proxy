
import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { DowJonesStock } from '@/utils/dowJonesDataService';
import { Link } from 'react-router-dom';

interface DowJonesStocksGridViewProps {
  stocks: DowJonesStock[];
  loading: boolean;
  onSortChange: (sortBy: 'rank' | 'weight' | 'price' | 'change' | 'name') => void;
  sortBy: 'rank' | 'weight' | 'price' | 'change' | 'name';
  sortOrder: 'asc' | 'desc';
}

const DowJonesStocksGridView = ({ 
  stocks, 
  loading, 
  onSortChange,
  sortBy,
  sortOrder 
}: DowJonesStocksGridViewProps) => {

  const SortButtons = () => {
    return (
      <div className="flex flex-wrap gap-2 mb-4">
        <button
          onClick={() => onSortChange('rank')}
          className={cn(
            "px-3 py-1 text-sm rounded-md",
            sortBy === 'rank' 
              ? "bg-blue-100 text-blue-800" 
              : "bg-gray-100 text-gray-800 hover:bg-gray-200"
          )}
        >
          Rank {sortBy === 'rank' && (sortOrder === 'asc' ? '↑' : '↓')}
        </button>
        <button
          onClick={() => onSortChange('weight')}
          className={cn(
            "px-3 py-1 text-sm rounded-md",
            sortBy === 'weight' 
              ? "bg-blue-100 text-blue-800" 
              : "bg-gray-100 text-gray-800 hover:bg-gray-200"
          )}
        >
          Weight {sortBy === 'weight' && (sortOrder === 'asc' ? '↑' : '↓')}
        </button>
        <button
          onClick={() => onSortChange('name')}
          className={cn(
            "px-3 py-1 text-sm rounded-md",
            sortBy === 'name' 
              ? "bg-blue-100 text-blue-800" 
              : "bg-gray-100 text-gray-800 hover:bg-gray-200"
          )}
        >
          Name {sortBy === 'name' && (sortOrder === 'asc' ? '↑' : '↓')}
        </button>
        <button
          onClick={() => onSortChange('price')}
          className={cn(
            "px-3 py-1 text-sm rounded-md",
            sortBy === 'price' 
              ? "bg-blue-100 text-blue-800" 
              : "bg-gray-100 text-gray-800 hover:bg-gray-200"
          )}
        >
          Price {sortBy === 'price' && (sortOrder === 'asc' ? '↑' : '↓')}
        </button>
        <button
          onClick={() => onSortChange('change')}
          className={cn(
            "px-3 py-1 text-sm rounded-md",
            sortBy === 'change' 
              ? "bg-blue-100 text-blue-800" 
              : "bg-gray-100 text-gray-800 hover:bg-gray-200"
          )}
        >
          Change {sortBy === 'change' && (sortOrder === 'asc' ? '↑' : '↓')}
        </button>
      </div>
    );
  };

  if (loading) {
    return (
      <>
        <SortButtons />
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {[...Array(30)].map((_, index) => (
            <Card key={index} className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Skeleton className="h-5 w-16" />
                <Skeleton className="h-4 w-8" />
              </div>
              <Skeleton className="h-6 w-32 mb-3" />
              <Skeleton className="h-5 w-20 mb-2" />
              <div className="flex justify-between">
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-4 w-12" />
              </div>
            </Card>
          ))}
        </div>
      </>
    );
  }

  return (
    <>
      <SortButtons />
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {stocks.map((stock) => {
          const isPositive = stock.changePercent >= 0;
          const symbolLower = stock.symbol.toLowerCase();
          
          return (
            <Link 
              key={stock.symbol} 
              to={`/company/${symbolLower}`}
              className="block hover:no-underline"
            >
              <Card className="p-4 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-lg">{stock.symbol}</span>
                  <span className="text-gray-500 text-xs">#{stock.rank}</span>
                </div>
                <h3 className="font-medium text-gray-800 mb-2 truncate" title={stock.name}>
                  {stock.name}
                </h3>
                <div className="text-xl font-mono mb-1">${stock.price.toFixed(2)}</div>
                <div className="flex justify-between items-center">
                  <div className={cn(
                    "flex items-center",
                    isPositive ? "text-green-600" : "text-red-600"
                  )}>
                    {isPositive ? (
                      <ArrowUp className="h-4 w-4 mr-1" />
                    ) : (
                      <ArrowDown className="h-4 w-4 mr-1" />
                    )}
                    <span>
                      {isPositive ? '+' : ''}{stock.changePercent.toFixed(2)}%
                    </span>
                  </div>
                  <span className="text-sm text-gray-600">
                    Weight: {stock.weight.toFixed(2)}%
                  </span>
                </div>
              </Card>
            </Link>
          );
        })}
      </div>
    </>
  );
};

export default DowJonesStocksGridView;
