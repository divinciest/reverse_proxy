
import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { DowJonesStock } from '@/utils/dowJonesDataService';
import { Link } from 'react-router-dom';

interface DowJonesStocksListViewProps {
  stocks: DowJonesStock[];
  loading: boolean;
  onSortChange: (sortBy: 'rank' | 'weight' | 'price' | 'change' | 'name') => void;
  sortBy: 'rank' | 'weight' | 'price' | 'change' | 'name';
  sortOrder: 'asc' | 'desc';
}

const DowJonesStocksListView = ({
  stocks,
  loading,
  onSortChange,
  sortBy,
  sortOrder
}: DowJonesStocksListViewProps) => {
  
  const renderSortIcon = (column: 'rank' | 'weight' | 'price' | 'change' | 'name') => {
    if (sortBy !== column) return null;
    
    return sortOrder === 'asc' ? '↑' : '↓';
  };

  if (loading) {
    return (
      <div className="w-full text-center p-8">
        <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto"></div>
        <p className="mt-2 text-gray-600">Loading stocks data...</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead 
              className="cursor-pointer hover:bg-gray-50" 
              onClick={() => onSortChange('rank')}
            >
              Rank {renderSortIcon('rank')}
            </TableHead>
            <TableHead 
              className="cursor-pointer hover:bg-gray-50" 
              onClick={() => onSortChange('name')}
            >
              Symbol & Company {renderSortIcon('name')}
            </TableHead>
            <TableHead 
              className="cursor-pointer hover:bg-gray-50 text-right" 
              onClick={() => onSortChange('price')}
            >
              Price {renderSortIcon('price')}
            </TableHead>
            <TableHead 
              className="cursor-pointer hover:bg-gray-50 text-right" 
              onClick={() => onSortChange('change')}
            >
              Change {renderSortIcon('change')}
            </TableHead>
            <TableHead 
              className="cursor-pointer hover:bg-gray-50 text-right" 
              onClick={() => onSortChange('weight')}
            >
              Weight {renderSortIcon('weight')}
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {stocks.map((stock) => {
            const isPositive = stock.changePercent >= 0;
            const symbolLower = stock.symbol.toLowerCase();
            
            return (
              <TableRow key={stock.symbol} className="hover:bg-gray-50">
                <TableCell className="font-medium">{stock.rank}</TableCell>
                <TableCell>
                  <Link to={`/company/${symbolLower}`} className="hover:underline">
                    <div>
                      <span className="font-bold">{stock.symbol}</span>
                      <div className="text-sm text-gray-600">{stock.name}</div>
                    </div>
                  </Link>
                </TableCell>
                <TableCell className="text-right font-mono">
                  ${stock.price.toFixed(2)}
                </TableCell>
                <TableCell className={cn(
                  "text-right",
                  isPositive ? "text-green-600" : "text-red-600"
                )}>
                  <div className="flex items-center justify-end">
                    {isPositive ? (
                      <ArrowUp className="h-4 w-4 mr-1" />
                    ) : (
                      <ArrowDown className="h-4 w-4 mr-1" />
                    )}
                    <span>
                      {isPositive ? '+' : ''}{stock.changePercent.toFixed(2)}%
                    </span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  {stock.weight.toFixed(2)}%
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
};

export default DowJonesStocksListView;
