
import React from 'react';
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";

interface DowJonesStocksHeaderProps {
  viewMode: 'grid' | 'list';
  setViewMode: (mode: 'grid' | 'list') => void;
  loading: boolean;
  onRefresh: () => void;
}

const DowJonesStocksHeader = ({
  viewMode,
  setViewMode,
  loading,
  onRefresh
}: DowJonesStocksHeaderProps) => {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
      <h2 className="text-2xl font-bold">Dow Jones Stocks</h2>
      
      <div className="flex items-center gap-2 mt-3 sm:mt-0">
        <Tabs 
          value={viewMode} 
          onValueChange={(v) => setViewMode(v as 'grid' | 'list')} 
          className="w-auto"
        >
          <TabsList>
            <TabsTrigger value="grid">Grid</TabsTrigger>
            <TabsTrigger value="list">List</TabsTrigger>
          </TabsList>
        </Tabs>
        
        <Button 
          variant="outline" 
          size="sm" 
          className="gap-1"
          onClick={onRefresh}
          disabled={loading}
        >
          <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
          Refresh
        </Button>
      </div>
    </div>
  );
};

export default DowJonesStocksHeader;
