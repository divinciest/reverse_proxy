
import React from "react";
import { ArrowUp, ArrowDown, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";
import { MarketIndex } from "@/utils/stockDataService";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface IndexCardProps {
  index: MarketIndex;
}

const IndexCard = ({ index }: IndexCardProps) => {
  return (
    <Card className="mb-8">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            S&P 500 Index 
            <span className="text-sm font-normal text-gray-500 ml-2">^GSPC</span>
          </div>
          <div className="flex items-center">
            <span className="text-3xl font-bold">{index.price.toLocaleString()}</span>
            <span 
              className={cn(
                "ml-2 flex items-center",
                index.changePercent >= 0 ? "text-green-600" : "text-red-600"
              )}
            >
              {index.changePercent >= 0 ? (
                <ArrowUp size={20} className="mr-1" />
              ) : (
                <ArrowDown size={20} className="mr-1" />
              )}
              {index.change >= 0 ? '+' : ''}{index.change.toFixed(2)} ({index.changePercent.toFixed(2)}%)
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">
          The Standard and Poor's 500, or simply the S&P 500, is a stock market index tracking the stock performance of 500 large companies listed on stock exchanges in the United States.
        </p>
        <div className="flex flex-wrap gap-3 mt-4">
          <Button variant="outline" size="sm" className="gap-1">
            <ExternalLink size={14} />
            <a href="https://www.google.com/finance/quote/.INX:INDEXSP" target="_blank" rel="noopener noreferrer">
              Google Finance
            </a>
          </Button>
          <Button variant="outline" size="sm" className="gap-1">
            <ExternalLink size={14} />
            <a href="https://www.spglobal.com/spdji/en/indices/equity/sp-500/" target="_blank" rel="noopener noreferrer">
              S&P Global Site
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default IndexCard;
