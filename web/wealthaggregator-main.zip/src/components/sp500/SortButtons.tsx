
import React from "react";
import { Button } from "@/components/ui/button";

interface SortButtonsProps {
  currentSort: string;
  setCurrentSort: (sortType: string) => void;
  disabled?: boolean;
}

const SortButtons = ({ currentSort, setCurrentSort, disabled = false }: SortButtonsProps) => {
  return (
    <div className="flex flex-wrap gap-2 mb-4">
      <Button 
        variant={currentSort === "default" ? "default" : "outline"} 
        size="sm"
        onClick={() => setCurrentSort("default")}
        disabled={disabled}
      >
        Default
      </Button>
      <Button 
        variant={currentSort === "percentGain" ? "default" : "outline"} 
        size="sm"
        onClick={() => setCurrentSort("percentGain")}
        disabled={disabled}
      >
        % Gain
      </Button>
      <Button 
        variant={currentSort === "percentLoss" ? "default" : "outline"} 
        size="sm"
        onClick={() => setCurrentSort("percentLoss")}
        disabled={disabled}
      >
        % Loss
      </Button>
      <Button 
        variant={currentSort === "marketCap" ? "default" : "outline"} 
        size="sm"
        onClick={() => setCurrentSort("marketCap")}
        disabled={disabled}
      >
        Market Cap
      </Button>
    </div>
  );
};

export default SortButtons;
