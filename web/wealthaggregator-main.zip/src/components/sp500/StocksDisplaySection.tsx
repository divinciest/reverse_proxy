
import React, { useState, useMemo } from "react";
import { StockPickData } from "@/utils/stockPickService";
import FilterToolbar from "@/components/FilterToolbar";
import SortButtons from "@/components/sp500/SortButtons";
import StockGridView from "@/components/sp500/StockGridView";
import StockListView from "@/components/sp500/StockListView";

type SortType = "default" | "az" | "za" | "percentGain" | "percentLoss" | "marketCap";

interface StocksDisplaySectionProps {
  stocksData: StockPickData[];
  loading: boolean;
  stocksError: Error | null;
  onRefresh: () => void;
  fetchStocksData: () => Promise<void>;
}

const StocksDisplaySection = ({ 
  stocksData, 
  loading, 
  stocksError,
  onRefresh,
  fetchStocksData
}: StocksDisplaySectionProps) => {
  const [view, setView] = useState<"grid" | "list">("grid");
  const [currentSort, setCurrentSort] = useState<SortType>("default");
  const [dateFilter, setDateFilter] = useState<string>("today");

  // Memoized sorted stocks to prevent re-sorting on every render
  const sortedStocks = useMemo(() => {
    if (!stocksData) return [];
    
    const sortedData = [...stocksData];
    
    switch (currentSort) {
      case "az":
        return sortedData.sort((a, b) => a.symbol.localeCompare(b.symbol));
      case "za":
        return sortedData.sort((a, b) => b.symbol.localeCompare(a.symbol));
      case "percentGain":
        return sortedData.sort((a, b) => b.changePercent - a.changePercent);
      case "percentLoss":
        return sortedData.sort((a, b) => a.changePercent - b.changePercent);
      case "marketCap":
        return sortedData.sort((a, b) => (b.marketCap || 0) - (a.marketCap || 0));
      default:
        return sortedData;
    }
  }, [stocksData, currentSort]);  // Only re-calculate when stocksData or currentSort changes

  // Custom sort handler for the toolbar
  const handleSort = (sortType: string) => {
    setCurrentSort(sortType as SortType);
  };

  return (
    <>
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between mb-4">
        <h2 className="text-2xl font-bold">S&P 500 Companies</h2>
        
        <FilterToolbar
          dateFilter={dateFilter}
          onDateFilterChange={setDateFilter}
          view={view}
          onViewChange={setView}
          onRefresh={onRefresh}
          sortProps={{
            onSort: handleSort,
            currentSort: currentSort
          }}
        />
      </div>
      
      {/* Custom sort buttons */}
      <SortButtons 
        currentSort={currentSort}
        setCurrentSort={handleSort}
        disabled={loading || !!stocksError}
      />
      
      {/* Stocks Display (Grid or List) */}
      {view === "grid" ? (
        <StockGridView 
          stocks={sortedStocks} 
          isLoading={loading}
          error={stocksError}
          onRetry={fetchStocksData}
        />
      ) : (
        <StockListView 
          stocks={sortedStocks} 
          isLoading={loading}
          error={stocksError}
          onRetry={fetchStocksData}
        />
      )}
    </>
  );
};

export default StocksDisplaySection;
