
import React from "react";
import { Link } from "react-router-dom";
import { ArrowUp, ArrowDown, AlertCircle, Loader } from "lucide-react";
import { cn } from "@/lib/utils";
import { StockPickData } from "@/utils/stockPickService";
import { formatToBillions } from "@/utils/formatUtils";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";

interface StockListViewProps {
  stocks: StockPickData[];
  isLoading: boolean;
  error: Error | null;
  onRetry: () => void;
}

const StockListView = ({ stocks, isLoading, error, onRetry }: StockListViewProps) => {
  if (error) {
    return (
      <Alert variant="destructive" className="mb-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription className="flex justify-between items-center">
          <span>Failed to load stock data: {error.message}</span>
          <button 
            onClick={onRetry}
            className="px-3 py-1 bg-red-100 text-red-800 rounded-md text-sm hover:bg-red-200"
          >
            Retry
          </button>
        </AlertDescription>
      </Alert>
    );
  }
  
  if (stocks.length === 0 && !isLoading) {
    return (
      <div className="text-center py-8 border rounded-md bg-gray-50">
        <p className="text-gray-500">No stock data available at the moment.</p>
        <button 
          onClick={onRetry}
          className="mt-2 px-4 py-2 bg-gray-200 rounded-md text-sm hover:bg-gray-300"
        >
          Refresh
        </button>
      </div>
    );
  }

  return (
    <div className="relative">
      {isLoading && (
        <div className="absolute inset-0 bg-white/70 flex items-center justify-center z-10">
          <div className="flex flex-col items-center">
            <Loader className="h-8 w-8 animate-spin text-gray-500" />
            <span className="mt-2 text-gray-500">Loading stock data...</span>
          </div>
        </div>
      )}
      
      <Table className="border">
        <TableHeader>
          <TableRow>
            <TableHead>Symbol</TableHead>
            <TableHead>Company</TableHead>
            <TableHead className="text-right">Price</TableHead>
            <TableHead className="text-right">Change (%)</TableHead>
            <TableHead className="text-right">Market Cap</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading && stocks.length === 0 ? (
            Array.from({ length: 5 }).map((_, index) => (
              <TableRow key={`skeleton-${index}`}>
                <TableCell colSpan={5} className="h-12 animate-pulse bg-gray-100"></TableCell>
              </TableRow>
            ))
          ) : (
            stocks.map((stock) => (
              <TableRow 
                key={stock.symbol}
                className={cn(
                  "hover:bg-gray-100",
                  stock.changePercent >= 0 ? "hover:bg-green-200" : "hover:bg-red-200"
                )}
              >
                <TableCell className="font-medium">
                  <Link to={`/company/${stock.symbol.toLowerCase()}`}>
                    {stock.symbol}
                  </Link>
                </TableCell>
                <TableCell>{stock.name}</TableCell>
                <TableCell className="text-right">${stock.price.toFixed(2)}</TableCell>
                <TableCell 
                  className={cn(
                    "text-right flex items-center justify-end",
                    stock.changePercent >= 0 ? "text-green-800" : "text-red-800"
                  )}
                >
                  {stock.changePercent >= 0 ? (
                    <ArrowUp size={20} className="mr-1" />
                  ) : (
                    <ArrowDown size={20} className="mr-1" />
                  )}
                  {stock.changePercent.toFixed(2)}%
                </TableCell>
                <TableCell className="text-right">
                  ${stock.marketCap ? formatToBillions(stock.marketCap * 1000000000).replace('.0B', 'B') : 'N/A'}
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};

// Memoize the component to prevent unnecessary re-renders
export default React.memo(StockListView);
