
import React from "react";
import { Link } from "react-router-dom";
import { ArrowUp, ArrowDown, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { StockPickData } from "@/utils/stockPickService";
import { formatToBillions } from "@/utils/formatUtils";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface StockGridViewProps {
  stocks: StockPickData[];
  isLoading: boolean;
  error: Error | null;
  onRetry: () => void;
}

const StockGridView = ({ stocks, isLoading, error, onRetry }: StockGridViewProps) => {
  if (error) {
    return (
      <Alert variant="destructive" className="mb-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription className="flex justify-between items-center">
          <span>Failed to load stock data: {error.message}</span>
          <button 
            onClick={onRetry}
            className="px-3 py-1 bg-red-100 text-red-800 rounded-md text-sm hover:bg-red-200"
          >
            Retry
          </button>
        </AlertDescription>
      </Alert>
    );
  }
  
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
        {[...Array(12)].map((_, index) => (
          <div key={index} className="p-3 rounded-md border border-gray-200">
            <div className="flex justify-between items-start">
              <Skeleton className="h-5 w-16 mb-2" />
              <Skeleton className="h-5 w-12" />
            </div>
            <Skeleton className="h-6 w-20 mb-2" />
            <Skeleton className="h-3 w-16" />
          </div>
        ))}
      </div>
    );
  }
  
  if (stocks.length === 0) {
    return (
      <div className="text-center py-8 border rounded-md bg-gray-50">
        <p className="text-gray-500">No stock data available at the moment.</p>
        <button 
          onClick={onRetry}
          className="mt-2 px-4 py-2 bg-gray-200 rounded-md text-sm hover:bg-gray-300"
        >
          Refresh
        </button>
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
      {stocks.map((stock) => (
        <Link 
          key={stock.symbol} 
          to={`/company/${stock.symbol.toLowerCase()}`}
          className="block"
        >
          <div 
            className={cn(
              "p-3 rounded-md border transition-shadow hover:shadow-md",
              stock.changePercent >= 0 ? "bg-green-200 border-green-300" : "bg-red-200 border-red-300"
            )}
          >
            <div className="flex justify-between items-center">
              <div className="font-bold text-lg">{stock.symbol}</div>
              <div 
                className={cn(
                  "flex items-center",
                  stock.changePercent >= 0 ? "text-green-800" : "text-red-800"
                )}
              >
                {stock.changePercent >= 0 ? (
                  <ArrowUp size={20} className="mr-1" />
                ) : (
                  <ArrowDown size={20} className="mr-1" />
                )}
                <span className="font-medium">{stock.changePercent.toFixed(2)}%</span>
              </div>
            </div>
            <div className="text-xs truncate mt-1 text-gray-600" style={{ fontSize: '12px' }}>
              {stock.name}
            </div>
            <div className="mt-1 text-lg font-semibold">${stock.price.toFixed(2)}</div>
            {stock.marketCap && (
              <div className="text-xs text-gray-500 mt-1">
                ${formatToBillions(stock.marketCap * 1000000000).replace('.0B', 'B')}
              </div>
            )}
          </div>
        </Link>
      ))}
    </div>
  );
};

// Memoize the component to prevent unnecessary re-renders
export default React.memo(StockGridView);
