
import React from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import IndexCard from "@/components/sp500/IndexCard";

interface IndexCardSectionProps {
  spxIndex: any;
  indexLoading: boolean;
  indexError: Error | null;
  fetchIndexData: () => Promise<void>;
}

const IndexCardSection = ({ 
  spxIndex, 
  indexLoading, 
  indexError, 
  fetchIndexData 
}: IndexCardSectionProps) => {
  if (indexLoading) {
    return (
      <div className="w-full bg-white rounded-lg border p-4 mb-8">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-36" />
          <Skeleton className="h-8 w-48" />
        </div>
        <Skeleton className="h-4 w-full mt-4" />
        <Skeleton className="h-4 w-2/3 mt-2" />
        <div className="flex gap-2 mt-4">
          <Skeleton className="h-9 w-32" />
          <Skeleton className="h-9 w-32" />
        </div>
      </div>
    );
  }

  if (indexError) {
    return (
      <Alert variant="destructive" className="mb-8">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription className="flex justify-between items-center">
          <span>Failed to load S&P 500 index data: {indexError.message}</span>
          <button 
            onClick={fetchIndexData}
            className="px-3 py-1 bg-red-100 text-red-800 rounded-md text-sm hover:bg-red-200"
          >
            Retry
          </button>
        </AlertDescription>
      </Alert>
    );
  }

  return spxIndex ? <IndexCard index={spxIndex} /> : null;
};

export default IndexCardSection;
