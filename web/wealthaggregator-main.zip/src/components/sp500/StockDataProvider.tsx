
import React, { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { fetchMarketIndices, MarketIndex } from "@/utils/stockDataService";
import { getMultipleStockPicks, StockPickData } from "@/utils/stockPickService";

// List of S&P 500 companies with their symbols
// This is a subset of major companies in the index
export const SP500_STOCKS = [
  { ticker: "MSFT", exchange: "NASDAQ", name: "Microsoft Corp" },
  { ticker: "AAPL", exchange: "NASDAQ", name: "Apple Inc" },
  { ticker: "AMZN", exchange: "NASDAQ", name: "Amazon.com Inc" },
  { ticker: "META", exchange: "NASDAQ", name: "Meta Platforms Inc" },
  { ticker: "GOOGL", exchange: "NASDAQ", name: "Alphabet Inc Class A" },
  { ticker: "TSLA", exchange: "NASDAQ", name: "Tesla Inc" },
  { ticker: "NVDA", exchange: "NASDAQ", name: "NVIDIA Corp" },
  { ticker: "JPM", exchange: "NYSE", name: "JPMorgan Chase & Co" },
  { ticker: "V", exchange: "NYSE", name: "Visa Inc" },
  { ticker: "PG", exchange: "NYSE", name: "Procter & Gamble Co" },
  { ticker: "UNH", exchange: "NYSE", name: "UnitedHealth Group Inc" },
  { ticker: "MA", exchange: "NYSE", name: "Mastercard Inc" },
  { ticker: "HD", exchange: "NYSE", name: "Home Depot Inc" },
  { ticker: "DIS", exchange: "NYSE", name: "Walt Disney Co" },
  { ticker: "MCD", exchange: "NYSE", name: "McDonald's Corp" },
  { ticker: "NFLX", exchange: "NASDAQ", name: "Netflix Inc" },
  { ticker: "INTC", exchange: "NASDAQ", name: "Intel Corp" },
  { ticker: "BAC", exchange: "NYSE", name: "Bank of America Corp" },
  { ticker: "KO", exchange: "NYSE", name: "Coca-Cola Co" },
  { ticker: "PEP", exchange: "NASDAQ", name: "PepsiCo Inc" },
  { ticker: "ADBE", exchange: "NASDAQ", name: "Adobe Inc" },
  { ticker: "CSCO", exchange: "NASDAQ", name: "Cisco Systems Inc" },
  { ticker: "WMT", exchange: "NYSE", name: "Walmart Inc" },
  { ticker: "CRM", exchange: "NYSE", name: "Salesforce Inc" },
  { ticker: "TMO", exchange: "NYSE", name: "Thermo Fisher Scientific" },
  { ticker: "ABT", exchange: "NYSE", name: "Abbott Laboratories" },
  { ticker: "COST", exchange: "NASDAQ", name: "Costco Wholesale Corp" },
  { ticker: "ACN", exchange: "NYSE", name: "Accenture PLC" },
  { ticker: "AVGO", exchange: "NASDAQ", name: "Broadcom Inc" },
  { ticker: "DHR", exchange: "NYSE", name: "Danaher Corp" },
  { ticker: "LLY", exchange: "NYSE", name: "Eli Lilly & Co" },
  { ticker: "TXN", exchange: "NASDAQ", name: "Texas Instruments Inc" },
  { ticker: "NKE", exchange: "NYSE", name: "Nike Inc" },
  { ticker: "PYPL", exchange: "NASDAQ", name: "PayPal Holdings Inc" },
  { ticker: "UPS", exchange: "NYSE", name: "United Parcel Service" },
];

interface StockDataProviderProps {
  children: (data: {
    spxIndex: MarketIndex | null;
    indexLoading: boolean;
    indexError: Error | null;
    stocksData: StockPickData[];
    stocksError: Error | null;
    loading: boolean;
    handleRefresh: () => Promise<void>;
    fetchIndexData: () => Promise<void>;
    fetchStocksData: () => Promise<void>;
  }) => React.ReactNode;
}

const StockDataProvider = ({ children }: StockDataProviderProps) => {
  const [spxIndex, setSpxIndex] = useState<MarketIndex | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [indexLoading, setIndexLoading] = useState<boolean>(true);
  const [indexError, setIndexError] = useState<Error | null>(null);
  const [stocksData, setStocksData] = useState<StockPickData[]>([]);
  const [stocksError, setStocksError] = useState<Error | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchIndexData = async () => {
    setIndexLoading(true);
    setIndexError(null);
    try {
      // Fetch market indices data
      const indices = await fetchMarketIndices();
      const spx = indices.find(index => index.symbol === "^GSPC");
      if (spx) {
        setSpxIndex(spx);
      } else {
        throw new Error("S&P 500 index data not found");
      }
    } catch (error) {
      console.error("Failed to fetch S&P 500 index data:", error);
      setIndexError(error instanceof Error ? error : new Error("Unknown error fetching index data"));
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load S&P 500 index data"
      });
    } finally {
      setIndexLoading(false);
    }
  };

  const fetchStocksData = async () => {
    setLoading(true);
    setStocksError(null);
    try {
      // Fetch stock data for the grid
      const stockPicks = await getMultipleStockPicks(SP500_STOCKS);
      setStocksData(stockPicks);
    } catch (error) {
      console.error("Failed to fetch stocks data:", error);
      setStocksError(error instanceof Error ? error : new Error("Unknown error fetching stocks"));
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load stock data"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchData = async () => {
    await Promise.all([
      fetchIndexData(),
      fetchStocksData()
    ]);
  };

  const handleRefresh = async () => {
    toast({
      title: "Refreshing",
      description: "Updating market data..."
    });
    await fetchData();
    toast({
      title: "Refreshed",
      description: "Market data has been updated"
    });
  };

  return (
    <>
      {children({
        spxIndex,
        indexLoading,
        indexError,
        stocksData,
        stocksError,
        loading,
        handleRefresh,
        fetchIndexData,
        fetchStocksData
      })}
    </>
  );
};

export default StockDataProvider;
