
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import SearchBar from "@/components/SearchBar";
import HeaderUserSection from "@/components/HeaderUserSection";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

const HeaderWithAuth = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isAuthenticated, user, logout } = useAuth();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleSearch = (query: string) => {
    console.log("Search query:", query);
    // Implementation for search functionality
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center gap-x-3">
            <Link to="/">
              <img 
                src="/lovable-uploads/5ce5c9e9-85f0-4d6f-86b3-4b3a36a4184c.png" 
                alt="AdvisorAssist" 
                className="h-8"
              />
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex md:items-center md:gap-8">
            <nav className="flex space-x-6">
              <Link to="/" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium">Home</Link>
              <Link to="/topics" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium">Topics</Link>
              <Link to="/stocks" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium">Companies</Link>
              <Link to="/dowjones" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium">Dow Jones</Link>
              <Link to="/sp500" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium">S&P 500</Link>
              <Link to="/markets" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium">Markets</Link>
              <Link to="/billionaires" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium">Billionaires</Link>
              <Link to="/authors" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium">Authors</Link>
              <Link to="/books" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium">Books</Link>
            </nav>
          </div>

          {/* Search & Auth */}
          <div className="hidden md:flex items-center gap-4">
            <SearchBar 
              placeholder="Search articles..."
              className="w-64"
              onSearch={handleSearch}
            />
            <HeaderUserSection />
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button 
              onClick={toggleMenu} 
              className="text-gray-500 hover:text-gray-700 transition-colors"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 bg-white">
            <div className="space-y-2 pb-4">
              <SearchBar 
                placeholder="Search articles..."
                onSearch={handleSearch}
              />
            </div>
            <nav className="flex flex-col space-y-3 border-t border-gray-200 pt-4">
              <Link to="/" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium" onClick={toggleMenu}>Home</Link>
              <Link to="/topics" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium" onClick={toggleMenu}>Topics</Link>
              <Link to="/stocks" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium" onClick={toggleMenu}>Companies</Link>
              <Link to="/dowjones" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium" onClick={toggleMenu}>Dow Jones</Link>
              <Link to="/sp500" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium" onClick={toggleMenu}>S&P 500</Link>
              <Link to="/markets" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium" onClick={toggleMenu}>Markets</Link>
              <Link to="/billionaires" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium" onClick={toggleMenu}>Billionaires</Link>
              <Link to="/authors" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium" onClick={toggleMenu}>Authors</Link>
              <Link to="/books" className="text-sm text-gray-700 hover:text-blue-600 transition-colors font-medium" onClick={toggleMenu}>Books</Link>
            </nav>
            
            <div className="mt-4 pt-4 border-t border-gray-200">
              {isAuthenticated ? (
                <div className="flex flex-col gap-3">
                  <div className="text-sm font-medium">
                    {user?.username || user?.email}
                  </div>
                  <div className="flex gap-3">
                    <Link to="/profile">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        onClick={toggleMenu}
                      >
                        Profile
                      </Button>
                    </Link>
                    <Button 
                      variant="secondary" 
                      size="sm" 
                      onClick={() => {
                        logout();
                        toggleMenu();
                      }}
                    >
                      Logout
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-3">
                  <Link to="/login" className="w-full">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="w-full"
                      onClick={toggleMenu}
                    >
                      Login
                    </Button>
                  </Link>
                  <Link to="/signup" className="w-full">
                    <Button 
                      variant="default" 
                      size="sm"
                      className="w-full"
                      onClick={toggleMenu}
                    >
                      Sign Up
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default HeaderWithAuth;
