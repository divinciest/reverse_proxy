
import React from "react";
import { Link } from "react-router-dom";
import { getWidgets } from "@/data/widgets/widgetData";
import WidgetCard from "./WidgetCard";

interface WidgetGridProps {
  filter?: "all" | "featured" | "news" | "books" | "stocks" | "billionaires" | "indexes";
}

const WidgetGrid: React.FC<WidgetGridProps> = ({ filter = "all" }) => {
  const widgets = getWidgets();
  
  // Filter widgets based on the filter prop
  const filteredWidgets = filter === "all" 
    ? widgets 
    : filter === "featured" 
      ? widgets.filter(widget => widget.featured) 
      : widgets.filter(widget => widget.category === filter);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {filteredWidgets.map((widget) => (
        <WidgetCard key={widget.id} widget={widget} />
      ))}
    </div>
  );
};

export default WidgetGrid;
