
import React from "react";
import { Link } from "react-router-dom";
import { Widget } from "@/data/widgets/widgetTypes";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

interface WidgetCardProps {
  widget: Widget;
}

const WidgetCard: React.FC<WidgetCardProps> = ({ widget }) => {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-md border-2 hover:border-primary/50">
      <div className="relative">
        <Link to={`/widget/${widget.id}`}>
          <img 
            src={widget.imageUrl} 
            alt={widget.name} 
            className="w-full h-40 object-cover"
          />
        </Link>
        {widget.featured && (
          <div className="absolute top-2 right-2 bg-primary text-white px-2 py-1 text-xs rounded-full">
            Featured
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <Link to={`/widget/${widget.id}`} className="hover:text-primary">
          <h3 className="font-medium text-lg mb-1">{widget.name}</h3>
        </Link>
        <p className="text-sm text-muted-foreground line-clamp-2 h-10">
          {widget.description}
        </p>
        <div className="flex items-center mt-2">
          <div className="bg-primary/10 text-primary text-xs px-2 py-1 rounded">
            {widget.category}
          </div>
          <div className="text-xs text-muted-foreground ml-2">
            {widget.users} users
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button className="w-full">
          <Plus className="h-4 w-4 mr-2" />
          Add Widget
        </Button>
      </CardFooter>
    </Card>
  );
};

export default WidgetCard;
