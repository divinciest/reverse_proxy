
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';

interface FeedSourceStat {
  name: string;
  value: number;
  percentage: number;
  color: string;
}

const feedSourceStats: FeedSourceStat[] = [
  { name: 'Yahoo Finance', value: 83, percentage: 29, color: '#6b46c1' },
  { name: 'Latest from Forbes', value: 49, percentage: 17, color: '#1a1a1a' },
  { name: 'ZeroHedge News', value: 49, percentage: 17, color: '#2d2d2d' },
  { name: 'US Top News', value: 46, percentage: 16, color: '#f6c344' },
  { name: 'Markets', value: 29, percentage: 10, color: '#f5d6ba' },
  { name: 'All News', value: 20, percentage: 7, color: '#5c5037' },
  { name: 'MarketWatch', value: 11, percentage: 4, color: '#4da057' },
];

const StatsChart = () => {
  const total = feedSourceStats.reduce((acc, item) => acc + item.value, 0);

  return (
    <div className="w-full">
      <div className="h-[220px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={feedSourceStats}
              cx="50%"
              cy="50%"
              labelLine={false}
              innerRadius={50}
              outerRadius={80}
              paddingAngle={2}
              dataKey="value"
            >
              {feedSourceStats.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <text
              x="50%"
              y="50%"
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-2xl font-bold"
            >
              {total}
            </text>
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="space-y-2 mt-2">
        {feedSourceStats.map((item, index) => (
          <div key={index} className="flex items-center justify-between">
            <div className="flex items-center">
              <div 
                className="w-3 h-3 rounded-sm mr-2"
                style={{ backgroundColor: item.color }} 
              />
              <span className="text-sm font-medium">{item.name}</span>
            </div>
            <span className="text-sm font-medium">{item.percentage}%</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StatsChart;
