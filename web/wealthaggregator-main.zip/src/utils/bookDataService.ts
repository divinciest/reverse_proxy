
// This file is kept for backward compatibility
// It re-exports everything from the books directory
export * from './books';
