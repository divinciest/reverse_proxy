
/**
 * CRITICAL WARNING - ZERO TOLERANCE POLICY FOR MOCK DATA
 * 
 * ABSOLUTELY NO MOCK DATA IS ALLOWED IN THIS SERVICE, UNDER ANY CIRCUMSTANCES.
 * 
 * This file MUST only contain functions that fetch data EXCLUSIVELY from
 * real market data APIs. Even in the case of errors, testing, or development,
 * NO HARDCODED DATA or FALLBACK VALUES are permitted.
 * 
 * Violation of this policy is strictly forbidden.
 * 
 * If API calls fail:
 * - Throw errors that are properly handled by components
 * - Log the error
 * - But NEVER fall back to sample/mock/hardcoded data
 * 
 * NO EXCEPTIONS. NO TEMPORARY SOLUTIONS.
 */

export interface StockDataPoint {
  time: string;
  price: number;
}

// Real implementation should fetch from a market data API
export const fetchStockData = async (
  ticker: string,
  exchange: string
): Promise<Array<StockDataPoint>> => {
  // This function MUST be implemented with a real API
  // Until then, throw an error
  throw new Error("Stock data API not implemented - mock data is forbidden");
};

export interface MarketIndex {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
}

// Real implementation should fetch from a market data API
export const fetchMarketIndices = async (): Promise<MarketIndex[]> => {
  // This function MUST be implemented with a real API
  // Until then, throw an error
  throw new Error("Market indices API not implemented - mock data is forbidden");
};

/*
Example real implementation:

export const fetchRealStockData = async (ticker: string, exchange: string) => {
  const response = await fetch(`/api/stocks/${ticker}?exchange=${exchange}`);
  if (!response.ok) {
    throw new Error('Failed to fetch stock data');
  }
  return await response.json();
};
*/
