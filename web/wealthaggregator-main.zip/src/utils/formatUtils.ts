// Format number to billions with B suffix
export const formatToBillions = (value: number): string => {
  const inBillions = value / 1000000000;
  // If it's a whole number (or very close to it), don't show decimals
  if (Math.abs(inBillions - Math.round(inBillions)) < 0.1) {
    return `${Math.round(inBillions).toLocaleString()}B`;
  }
  // Otherwise show one decimal point
  return `${inBillions.toFixed(1).replace(/\B(?=(\d{3})+(?!\d))/g, ',')}B`;
};
