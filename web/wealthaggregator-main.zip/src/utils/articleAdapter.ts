
import { Article } from "@/data/types";

/**
 * Adapts an article object to be compatible with the ArticleCard component
 * Ensures all required properties are present with fallbacks
 */
export const adaptArticleForCard = (article: Article | any) => {
  return {
    id: article.id || "",
    title: article.title || "",
    summary: article.summary || "",
    source: article.source || "",
    category: article.category || article.source || "",
    sentiment: article.sentiment || "neutral",
    publishDate: article.publishDate || article.date || new Date().toISOString(),
    topics: article.topics || article.tags || [],
    url: article.url || article.sourceUrl || "#",
    imageUrl: article.imageUrl || undefined,
    sourceCount: article.sourceCount || undefined
  };
};

/**
 * Checks if an article has all required properties for the ArticleCard
 */
export const isArticleValidForCard = (article: any): boolean => {
  return (
    article &&
    typeof article === "object" &&
    typeof article.title === "string" &&
    typeof article.source === "string"
  );
};

/**
 * Adapt billionaire news item to article format for ArticleCard
 */
export const adaptBillionaireNewsToArticle = (news: any, billionaireName: string): Article => {
  return {
    id: news.id || `news-${Date.now()}`,
    title: news.title || "",
    summary: news.summary || "",
    source: news.source || "Forbes",
    sourceUrl: news.url || "#",
    category: "Billionaires",
    sentiment: "neutral",
    publishDate: news.date || new Date().toISOString(),
    topics: news.relatedCompanies || [],
    url: news.url || "#",
    imageUrl: news.imageUrl,
    tags: [billionaireName, "Billionaire", ...news.relatedCompanies || []],
  };
};
