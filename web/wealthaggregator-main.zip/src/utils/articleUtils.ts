
import { Article as ApiArticle } from "@/utils/feedService";
import { Article as DataArticle } from "@/data/types";

// IMPORTANT: There should be no sample data or example data or hardcoded examples of data.
// ALWAYS use the API to fetch real data. Never resort to static mock data in production.

/**
 * Converts an API article to the format used by the UI components
 */
export const convertApiArticleToUiArticle = (article: ApiArticle): DataArticle => {
  return {
    id: article.id?.toString() || article.sourceUrl || Date.now().toString(), // Ensure id is always a string and not undefined
    title: article.title,
    source: article.source,
    sourceUrl: article.sourceUrl,
    category: article.source,
    summary: article.summary,
    publishDate: article.date || new Date().toISOString(),
    date: article.date,
    url: article.sourceUrl,
    sentiment: (article as any).sentiment as 'bullish' | 'neutral' | 'bearish' || 'neutral',
    imageUrl: (article as any).imageUrl as string | undefined,
    topics: article.tags || [],
    tags: article.tags || [],
    hoursAgo: article.hoursAgo,
    author: article.author,
    sourceLogo: article.sourceLogo,
    sourceColor: article.sourceColor,
    companies: article.companies || []
  };
};

/**
 * Converts a local data article to API article format
 * This is mainly used for backward compatibility with existing components
 * that expect the API format
 */
export const convertDataArticleToApiArticle = (article: DataArticle): ApiArticle => {
  // Create a base article object
  const apiArticle: Partial<ApiArticle> = {
    title: article.title,
    source: article.source,
    author: article.author || { name: "Unknown", image: null },
    date: article.publishDate || article.date,
    hoursAgo: article.hoursAgo || 0,
    summary: article.summary,
    tags: article.topics || article.tags || [],
    companies: article.companies || [],
    sourceUrl: article.sourceUrl || article.url || '',
    sourceLogo: article.sourceLogo || "",
    sourceColor: article.sourceColor || "",
    id: article.id
  };

  // Add any additional properties
  if (article.imageUrl) {
    (apiArticle as any).imageUrl = article.imageUrl;
  }

  if (article.sentiment) {
    (apiArticle as any).sentiment = article.sentiment;
  }

  return apiArticle as ApiArticle;
};
