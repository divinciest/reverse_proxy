
import { Tag } from "@/types/admin";

const API_BASE_URL = "https://api.advisorassist.ai/api";

// Helper function to get the auth token from localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('authToken');
};

// Helper function to create headers with authorization
const createHeaders = (): HeadersInit => {
  const token = getAuthToken();
  const headers: HeadersInit = {
    "Content-Type": "application/json"
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  return headers;
};

export const tagService = {
  async getAllTags(): Promise<Tag[]> {
    try {
      // Using the public endpoint /api/tags
      const response = await fetch(`${API_BASE_URL}/tags`, {
        headers: createHeaders()
      });
      
      if (!response.ok) {
        throw new Error(`Failed to fetch tags: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data.tags.map((tag: any) => ({
        _id: tag._id,
        tagName: tag.tagName,
        aliases: tag.aliases || [],
        createdAt: tag.createdAt,
        lastModified: tag.lastModified
      }));
    } catch (error) {
      console.error("Error fetching tags:", error);
      throw error;
    }
  },
  
  async addTag(tagName: string, aliases: string[]): Promise<Tag> {
    try {
      const response = await fetch(`${API_BASE_URL}/admin/tags/add`, {
        method: "POST",
        headers: createHeaders(),
        body: JSON.stringify({ tagName, aliases })
      });
      
      if (!response.ok) {
        throw new Error(`Failed to add tag: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data.tag;
    } catch (error) {
      console.error("Error adding tag:", error);
      throw error;
    }
  },
  
  async updateTag(tagId: string, updates: { tagName?: string; aliases?: string[] }): Promise<Tag> {
    try {
      const response = await fetch(`${API_BASE_URL}/admin/tags/${tagId}`, {
        method: "PUT",
        headers: createHeaders(),
        body: JSON.stringify(updates)
      });
      
      if (!response.ok) {
        throw new Error(`Failed to update tag: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data.tag;
    } catch (error) {
      console.error("Error updating tag:", error);
      throw error;
    }
  },
  
  async deleteTag(tagId: string): Promise<string> {
    try {
      const response = await fetch(`${API_BASE_URL}/admin/tags/${tagId}`, {
        method: "DELETE",
        headers: createHeaders()
      });
      
      if (!response.ok) {
        throw new Error(`Failed to delete tag: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data.tag_id;
    } catch (error) {
      console.error("Error deleting tag:", error);
      throw error;
    }
  }
};
