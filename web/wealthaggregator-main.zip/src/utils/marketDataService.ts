
/**
 * Utility service for market data
 */

export interface MarketIndex {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  region?: string;
  weight?: number;
}

export interface MarketRegion {
  name: string;
  active?: boolean;
}

// Market regions
export const marketRegions: MarketRegion[] = [
  { name: "Americas", active: true },
  { name: "Europe" },
  { name: "Asia" },
  { name: "Currencies" },
  { name: "Crypto" },
  { name: "Futures" }
];

// Market indices data with most recent values
// In a production app, this would be fetched from an API
export const getMarketIndices = (): MarketIndex[] => {
  return [
    // Americas
    { 
      symbol: "^DJI", 
      name: "Dow Jones", 
      price: 38654.42, 
      change: 134.65, 
      changePercent: 0.35, 
      region: "Americas",
      weight: 100
    },
    { 
      symbol: "^GSPC", 
      name: "S&P 500", 
      price: 5670.97, 
      change: 37.90, 
      changePercent: 0.67, 
      region: "Americas",
      weight: 100
    },
    { 
      symbol: "^IXIC", 
      name: "Nasdaq", 
      price: 17601.05, 
      change: 151.16, 
      changePercent: 0.87, 
      region: "Americas" 
    },
    { 
      symbol: "^RUT", 
      name: "Russell", 
      price: 2045.36, 
      change: 33.12, 
      changePercent: 1.65, 
      region: "Americas" 
    },
    { 
      symbol: "^GSPTSE", 
      name: "TSX", 
      price: 25307.18, 
      change: 273.90, 
      changePercent: 1.09, 
      region: "Americas" 
    },
    
    // Europe
    { 
      symbol: "^FTSE", 
      name: "FTSE 100", 
      price: 8142.15, 
      change: 3.91, 
      changePercent: 0.05, 
      region: "Europe" 
    },
    { 
      symbol: "^GDAXI", 
      name: "DAX", 
      price: 18349.74, 
      change: 120.65, 
      changePercent: 0.66, 
      region: "Europe" 
    },
    { 
      symbol: "^FCHI", 
      name: "CAC 40", 
      price: 7413.25, 
      change: 91.35, 
      changePercent: 1.25, 
      region: "Europe" 
    },
    
    // Asia
    { 
      symbol: "^N225", 
      name: "Nikkei", 
      price: 37919.65, 
      change: 268.32, 
      changePercent: 0.71, 
      region: "Asia" 
    },
    { 
      symbol: "^HSI", 
      name: "Hang Seng", 
      price: 16783.72, 
      change: -156.41, 
      changePercent: -0.92, 
      region: "Asia" 
    },
    { 
      symbol: "000001.SS", 
      name: "Shanghai", 
      price: 2897.34, 
      change: 15.23, 
      changePercent: 0.53, 
      region: "Asia" 
    },
    
    // Add more markets for each region as needed
  ];
};
