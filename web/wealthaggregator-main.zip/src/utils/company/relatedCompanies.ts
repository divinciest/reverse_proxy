
/**
 * Related companies data
 */

export const getRelatedCompanies = () => {
  return [
    {
      id: "intc",
      name: "Intel Corporation",
      ticker: "INTC",
      industry: "Semiconductors"
    },
    {
      id: "amd",
      name: "Advanced Micro Devices",
      ticker: "AMD",
      industry: "Semiconductors"
    },
    {
      id: "nvda",
      name: "NVIDIA Corporation",
      ticker: "NVDA",
      industry: "Semiconductors"
    },
    {
      id: "tsm",
      name: "Taiwan Semiconductor",
      ticker: "TSM",
      industry: "Semiconductors"
    },
    {
      id: "aapl",
      name: "Apple Inc.",
      ticker: "AAPL",
      industry: "Consumer Electronics"
    },
    {
      id: "msft",
      name: "Microsoft Corporation",
      ticker: "MSFT",
      industry: "Software"
    },
    {
      id: "tsla",
      name: "Tesla, Inc.",
      ticker: "TSLA",
      industry: "Auto Manufacturers"
    }
  ];
};
