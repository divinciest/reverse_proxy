
/**
 * Company additional information data
 */

// Company additional information
export const getCompanyInfo = (id: string) => {
  switch (id) {
    case "tsla":
      return {
        ceo: "Elon Musk",
        founded: "Jul 1, 2003",
        website: "tesla.com",
        employees: "125,665"
      };
    case "intc":
      return {
        ceo: "Pat Gelsinger",
        founded: "Jul 18, 1968",
        website: "intel.com",
        employees: "131,900"
      };
    case "aapl":
      return {
        ceo: "Tim Cook",
        founded: "Apr 1, 1976",
        website: "apple.com",
        employees: "164,000"
      };
    case "msft":
      return {
        ceo: "Satya Nadella",
        founded: "Apr 4, 1975",
        website: "microsoft.com",
        employees: "221,000"
      };
    default:
      return {};
  }
};
