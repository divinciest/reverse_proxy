
/**
 * CRITICAL WARNING - ZERO TOLERANCE POLICY FOR MOCK DATA
 * 
 * ABSOLUTELY NO MOCK DATA IS ALLOWED IN THIS SERVICE, UNDER ANY CIRCUMSTANCES.
 * 
 * This file MUST only contain functions that fetch data EXCLUSIVELY from
 * real company data APIs. Even in the case of errors, testing, or development,
 * NO HARDCODED DATA or FALLBACK VALUES are permitted.
 * 
 * Violation of this policy is strictly forbidden.
 * 
 * If API calls fail:
 * - Return empty objects with proper types
 * - Log the error
 * - But NEVER fall back to sample/mock/hardcoded data
 * 
 * NO EXCEPTIONS. NO TEMPORARY SOLUTIONS.
 */

import { getCompanyDescription } from './companyDescriptions';

// Interface for company data to provide proper typing
export interface CompanyData {
  id: string;
  name: string;
  ticker: string;
  exchange: string;
  price: number;
  change: number;
  changePercent: number;
  industry: string;
  description: string;
}

// Default error object for when API is not implemented
export const API_NOT_IMPLEMENTED_ERROR = {
  message: "Company data API not implemented - mock data is forbidden. Must implement real API before using this function.",
  apiAvailable: false
};

export const getCompanyData = (companyId: string | undefined): CompanyData => {
  // Log the error for debugging but don't throw an exception
  console.error(API_NOT_IMPLEMENTED_ERROR.message);
  
  // Return an empty object with proper type structure
  // This avoids TypeScript errors while still adhering to no-mock-data policy
  return {
    id: companyId || '',
    name: 'API Not Available',
    ticker: 'N/A',
    exchange: 'N/A',
    price: 0,
    change: 0,
    changePercent: 0,
    industry: 'API Not Available',
    description: getCompanyDescription(companyId || '') || 'API Not Available'
  };
};
