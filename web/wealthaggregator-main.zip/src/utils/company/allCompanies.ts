
/**
 * CRITICAL WARNING - ZERO TOLERANCE POLICY FOR MOCK DATA
 * 
 * ABSOLUTELY NO MOCK DATA IS ALLOWED IN THIS SERVICE, UNDER ANY CIRCUMSTANCES.
 * 
 * This file MUST only contain functions that fetch data EXCLUSIVELY from
 * real company data APIs. Even in the case of errors, testing, or development,
 * NO HARDCODED DATA or FALLBACK VALUES are permitted.
 * 
 * Violation of this policy is strictly forbidden.
 * 
 * If API calls fail:
 * - Return empty arrays
 * - Log the error
 * - But NEVER fall back to sample/mock/hardcoded data
 * 
 * NO EXCEPTIONS. NO TEMPORARY SOLUTIONS.
 */

import { CompanyData, API_NOT_IMPLEMENTED_ERROR } from './companyData';

export const getCompanies = (): CompanyData[] => {
  // Log the error for debugging but don't throw
  console.error("Companies API not implemented - mock data is forbidden. Must implement real API before using this function.");
  
  // Return an empty array with the proper type
  // This is NOT mock data - it's an empty result that prevents UI crashes
  return [];
};
