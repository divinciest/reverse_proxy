
import { authService } from "./auth";
import { CompanyMetadata, Article, FeedInfo } from "./feedService";

const API_BASE_URL = "https://api.advisorassist.ai/api";

export const companyService = {
  async getPlatformCompanies(): Promise<CompanyMetadata[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/platform_companies`);
      
      if (!response.ok) {
        throw new Error("Failed to fetch platform companies");
      }
      
      const data = await response.json();
      return data.companies;
    } catch (error) {
      console.error("Error fetching platform companies:", error);
      throw error;
    }
  },
  
  async getCompanyArticles(companyName: string): Promise<{
    company: string;
    articles: Article[];
    feeds_sourced: FeedInfo[];
    companies_metadata: CompanyMetadata[];
  }> {
    try {
      const response = await fetch(`${API_BASE_URL}/company_articles/${encodeURIComponent(companyName)}`);
      
      if (!response.ok) {
        throw new Error("Failed to fetch company articles");
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`Error fetching articles for company ${companyName}:`, error);
      throw error;
    }
  }
};

// Admin-specific operations for companies
export const adminCompanyService = {
  async addCompany(name: string, domain: string, aliases?: string[]): Promise<CompanyMetadata> {
    const token = authService.getToken();
    
    if (!token) {
      throw new Error("Authentication required");
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/admin/company/add`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ name, domain, aliases })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to add company");
      }
      
      const data = await response.json();
      return data.company;
    } catch (error) {
      console.error("Error adding company:", error);
      throw error;
    }
  },
  
  async updateCompanyStatus(companyId: string, enabled: boolean): Promise<void> {
    const token = authService.getToken();
    
    if (!token) {
      throw new Error("Authentication required");
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/admin/company/update_status`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ company_id: companyId, enabled })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update company status");
      }
    } catch (error) {
      console.error("Error updating company status:", error);
      throw error;
    }
  }
};
