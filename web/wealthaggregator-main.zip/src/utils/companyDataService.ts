
/**
 * Utility service for company data and information
 * This is a facade that re-exports functions from the individual modules
 */

// Re-export all company data related functions
export { getCompanyDescription } from './company/companyDescriptions';
export { getCompanyInfo } from './company/companyInfo';
export { getCompanyData } from './company/companyData';
export { getRelatedCompanies } from './company/relatedCompanies';
export { getCompanies } from './company/allCompanies';
