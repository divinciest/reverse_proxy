
import { toast } from "sonner";

export interface User {
  _id: string;
  email: string;
  username?: string;
  role: "user" | "admin";
  profilePicture?: string;
  bio?: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

const API_BASE_URL = "https://api.advisorassist.ai/api";

export const authService = {
  async signup(email: string, password: string, username?: string, isAdmin: boolean = false, adminKey?: string): Promise<boolean> {
    try {
      const response = await fetch(`${API_BASE_URL}/signup`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
          username,
          role: isAdmin ? "admin" : "user",
          admin_key: isAdmin ? adminKey : undefined
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        toast.error(errorData.message || "Registration failed");
        return false;
      }

      toast.success("Registration successful! Please sign in.");
      return true;
    } catch (error) {
      console.error("Signup error:", error);
      toast.error("An error occurred during registration. Please try again.");
      return false;
    }
  },

  async login(email: string, password: string): Promise<AuthResponse | null> {
    try {
      const response = await fetch(`${API_BASE_URL}/signin`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        toast.error(errorData.message || "Login failed");
        return null;
      }

      const data = await response.json();
      
      // Store the token in localStorage
      localStorage.setItem("authToken", data.token);
      localStorage.setItem("userData", JSON.stringify(data.user));
      
      return data;
    } catch (error) {
      console.error("Login error:", error);
      toast.error("An error occurred during login. Please try again.");
      return null;
    }
  },

  async getCurrentUser(): Promise<User | null> {
    try {
      const token = localStorage.getItem("authToken");
      
      if (!token) {
        return null;
      }
      
      const response = await fetch(`${API_BASE_URL}/me`, {
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });

      if (!response.ok) {
        // If token is invalid, clear it
        if (response.status === 401) {
          this.logout();
        }
        return null;
      }

      const user = await response.json();
      return user;
    } catch (error) {
      console.error("Error getting current user:", error);
      return null;
    }
  },
  
  logout() {
    localStorage.removeItem("authToken");
    localStorage.removeItem("userData");
    window.location.href = "/";
  },
  
  isAuthenticated(): boolean {
    return !!localStorage.getItem("authToken");
  },
  
  getToken(): string | null {
    return localStorage.getItem("authToken");
  },
  
  isAdmin(): boolean {
    const userData = localStorage.getItem("userData");
    if (!userData) return false;
    
    try {
      const user = JSON.parse(userData);
      return user.role === "admin";
    } catch (e) {
      return false;
    }
  }
};
