
export interface FinanceBook {
  id: string;
  title: string;
  author: string;
  year: number;
  coverImage: string;
  description?: string;
  affiliateUrl: string;
  category?: string[];
  rating?: number;
  featured?: boolean;
}
