
import { financeBooks } from './booksData';

// Function to check and get better images
export const getBetterBookCoverImage = (title: string, author: string): string | null => {
  // This is a helper function that searches for better book cover images
  // based on title and author match
  const bookMatch = financeBooks.find(book => 
    book.title.toLowerCase().includes(title.toLowerCase()) || 
    title.toLowerCase().includes(book.title.toLowerCase()) ||
    book.author.toLowerCase().includes(author.toLowerCase()) ||
    author.toLowerCase().includes(book.author.toLowerCase())
  );
  
  return bookMatch ? bookMatch.coverImage : null;
};

// Function to get a fallback image if the main image fails to load
export const getFallbackBookCoverImage = (bookId: string): string => {
  // Map of specific fallback images for certain books
  const fallbackImages: Record<string, string> = {
    "intelligent-investor": "https://m.media-amazon.com/images/I/91yj3mbz4JL._AC_UF1000,1000_QL80_.jpg",
    "rich-dad-poor-dad": "https://m.media-amazon.com/images/I/81bsw6fnUiL._AC_UF1000,1000_QL80_.jpg",
    "millionaire-next-door": "https://m.media-amazon.com/images/I/81sJ9oXK4JL._AC_UF1000,1000_QL80_.jpg",
    "psychology-of-money": "https://m.media-amazon.com/images/I/71J3+5lrCDL._AC_UF1000,1000_QL80_.jpg",
    "random-walk": "https://m.media-amazon.com/images/I/71HRz8eCZxL._AC_UF1000,1000_QL80_.jpg",
    "richest-man-in-babylon": "https://m.media-amazon.com/images/I/71l9pCV98TL._AC_UF1000,1000_QL80_.jpg",
    "total-money-makeover": "https://m.media-amazon.com/images/I/81cL+cM7JJL._AC_UF1000,1000_QL80_.jpg",
    "think-and-grow-rich": "https://m.media-amazon.com/images/I/71UypkUjStL._AC_UF1000,1000_QL80_.jpg",
    "when-genius-failed": "https://m.media-amazon.com/images/I/71zU6R+CmyL._AC_UF1000,1000_QL80_.jpg",
    "i-will-teach-you-to-be-rich": "https://m.media-amazon.com/images/I/81t-rSVWh0L._AC_UF1000,1000_QL80_.jpg",
    "common-stocks-uncommon-profits": "https://m.media-amazon.com/images/I/71DHEagosIL._AC_UF1000,1000_QL80_.jpg",
    "simple-path-to-wealth": "https://m.media-amazon.com/images/I/81Lb75AgajL._AC_UF1000,1000_QL80_.jpg",
    "little-book-common-sense-investing": "https://m.media-amazon.com/images/I/81ZB-hHXH5L._AC_UF1000,1000_QL80_.jpg",
    "bogleheads-guide-investing": "https://m.media-amazon.com/images/I/913gdFdPstL._AC_UF1000,1000_QL80_.jpg",
    "one-up-on-wall-street": "https://m.media-amazon.com/images/I/81oMQeXD1PL._AC_UF1000,1000_QL80_.jpg",
    "your-money-or-your-life": "https://m.media-amazon.com/images/I/71tjqndwDkL._AC_UF1000,1000_QL80_.jpg",
    "essays-warren-buffett": "https://m.media-amazon.com/images/I/6111offiBKL._AC_UF1000,1000_QL80_.jpg",
    "security-analysis": "https://m.media-amazon.com/images/I/81StSOpmkjL._AC_UF1000,1000_QL80_.jpg",
    "four-pillars-of-investing": "https://m.media-amazon.com/images/I/714bscGQDwL._AC_UF1000,1000_QL80_.jpg",
    "millionaire-teacher": "https://m.media-amazon.com/images/I/61vpTDV-IwL._AC_UF1000,1000_QL80_.jpg"
  };
  
  // If we have a specific fallback for this book, use it
  if (fallbackImages[bookId]) {
    console.log(`Using specific fallback for ${bookId}`);
    return fallbackImages[bookId];
  }
  
  // Try to find the book in our data
  const book = financeBooks.find(b => b.id === bookId);
  if (book?.coverImage) {
    console.log(`Using book data fallback for ${bookId}`);
    return book.coverImage;
  }
  
  // Last resort fallback
  console.log(`Using placeholder fallback for ${bookId}`);
  return "https://placehold.co/144x192/e2e8f0/64748b?text=" + encodeURIComponent(bookId.replace(/-/g, ' '));
};
