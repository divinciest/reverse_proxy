
import { FinanceBook } from './types';

// Enhanced finance books data with better cover images
export const financeBooks: FinanceBook[] = [
  {
    id: "intelligent-investor",
    title: "The Intelligent Investor",
    author: "Benjamin Graham",
    year: 1949,
    coverImage: "https://m.media-amazon.com/images/I/91yj3mbz4JL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Intelligent-Investor-Definitive-Investing-Essentials/dp/0060555661",
    category: ["Investing", "Stock Market"],
    rating: 4.7,
    featured: true
  },
  {
    id: "rich-dad-poor-dad",
    title: "Rich Dad Poor Dad",
    author: "Robert Kiyosaki",
    year: 1997,
    coverImage: "https://m.media-amazon.com/images/I/81bsw6fnUiL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Rich-Dad-Poor-Teach-Middle/dp/1612680194",
    category: ["Personal Finance", "Financial Education"],
    rating: 4.7,
    featured: true
  },
  {
    id: "millionaire-next-door",
    title: "The Millionaire Next Door",
    author: "Thomas J. Stanley",
    year: 1996,
    coverImage: "https://m.media-amazon.com/images/I/81sJ9oXK4JL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Millionaire-Next-Door-Surprising-Americas/dp/1589795474",
    category: ["Personal Finance", "Wealth Building"],
    rating: 4.7,
    featured: true
  },
  {
    id: "psychology-of-money",
    title: "The Psychology of Money",
    author: "Morgan Housel",
    year: 2020,
    coverImage: "https://m.media-amazon.com/images/I/71J3+5lrCDL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Psychology-Money-Timeless-lessons-happiness/dp/0857197681",
    category: ["Personal Finance", "Behavioral Finance"],
    rating: 4.7,
    featured: true
  },
  {
    id: "random-walk",
    title: "A Random Walk Down Wall Street",
    author: "Burton Malkiel",
    year: 1973,
    coverImage: "https://m.media-amazon.com/images/I/71HRz8eCZxL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Random-Walk-Down-Wall-Street/dp/0393330338",
    category: ["Investing", "Stock Market"],
    rating: 4.6
  },
  {
    id: "richest-man-in-babylon",
    title: "The Richest Man in Babylon",
    author: "George Samuel Clason",
    year: 1926,
    coverImage: "https://m.media-amazon.com/images/I/71l9pCV98TL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Richest-Man-Babylon-George-Clason/dp/1505339111",
    category: ["Personal Finance", "Wealth Building"],
    rating: 4.7
  },
  {
    id: "total-money-makeover",
    title: "The Total Money Makeover",
    author: "Dave Ramsey",
    year: 2003,
    coverImage: "https://m.media-amazon.com/images/I/81cL+cM7JJL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Total-Money-Makeover-Classic-Financial/dp/1595555277",
    category: ["Personal Finance", "Debt Management"],
    rating: 4.7
  },
  {
    id: "think-and-grow-rich",
    title: "Think and Grow Rich",
    author: "Napoleon Hill",
    year: 1937,
    coverImage: "https://m.media-amazon.com/images/I/71UypkUjStL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Think-Grow-Rich-Napoleon-Hill/dp/0449214923",
    category: ["Personal Development", "Wealth Building"],
    rating: 4.7
  },
  {
    id: "when-genius-failed",
    title: "When Genius Failed",
    author: "Roger Lowenstein",
    year: 2000,
    coverImage: "https://m.media-amazon.com/images/I/71zU6R+CmyL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/When-Genius-Failed-Long-Term-Management/dp/0375758259",
    category: ["Finance", "Financial History"],
    rating: 4.6
  },
  {
    id: "i-will-teach-you-to-be-rich",
    title: "I Will Teach You To Be Rich",
    author: "Ramit Sethi",
    year: 2009,
    coverImage: "https://m.media-amazon.com/images/I/81t-rSVWh0L._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Will-Teach-Rich-Second/dp/1523505745",
    category: ["Personal Finance", "Wealth Building"],
    rating: 4.7
  },
  {
    id: "common-stocks-uncommon-profits",
    title: "Common Stocks and Uncommon Profits",
    author: "Philip Arthur Fisher",
    year: 1958,
    coverImage: "https://m.media-amazon.com/images/I/71DHEagosIL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Common-Stocks-Uncommon-Profits-Writings/dp/0471445509",
    category: ["Investing", "Stock Market"],
    rating: 4.5
  },
  {
    id: "simple-path-to-wealth",
    title: "The Simple Path to Wealth",
    author: "J. L. Collins",
    year: 2016,
    coverImage: "https://m.media-amazon.com/images/I/81Lb75AgajL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Simple-Path-Wealth-financial-independence/dp/1533667926",
    category: ["Investing", "Financial Independence"],
    rating: 4.8
  },
  {
    id: "little-book-common-sense-investing",
    title: "Little Book of Common Sense Investing",
    author: "John C. Bogle",
    year: 2007,
    coverImage: "https://m.media-amazon.com/images/I/81ZB-hHXH5L._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Little-Book-Common-Sense-Investing/dp/1119404509",
    category: ["Investing", "Index Funds"],
    rating: 4.7
  },
  {
    id: "bogleheads-guide-investing",
    title: "The Bogleheads' Guide to Investing",
    author: "Taylor Larimore, Mel Lindauer, Michael LeBoeuf",
    year: 2006,
    coverImage: "https://m.media-amazon.com/images/I/913gdFdPstL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Bogleheads-Guide-Investing-Taylor-Larimore/dp/1118921283",
    category: ["Investing", "Index Funds"],
    rating: 4.7
  },
  {
    id: "one-up-on-wall-street",
    title: "One Up on Wall Street",
    author: "Peter Lynch",
    year: 1989,
    coverImage: "https://m.media-amazon.com/images/I/81oMQeXD1PL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/One-Up-Wall-Street-Already/dp/0743200403",
    category: ["Investing", "Stock Market"],
    rating: 4.7
  },
  {
    id: "your-money-or-your-life",
    title: "Your Money Or Your Life",
    author: "Vicki Robin",
    year: 1992,
    coverImage: "https://m.media-amazon.com/images/I/71tjqndwDkL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Your-Money-Life-Transforming-Relationship/dp/0143115766",
    category: ["Personal Finance", "Financial Independence"],
    rating: 4.6
  },
  {
    id: "essays-warren-buffett",
    title: "The Essays of Warren Buffett",
    author: "Warren Buffett",
    year: 1997,
    coverImage: "https://m.media-amazon.com/images/I/6111offiBKL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Essays-Warren-Buffett-Lessons-Corporate/dp/1611637589",
    category: ["Investing", "Business"],
    rating: 4.8
  },
  {
    id: "security-analysis",
    title: "Security Analysis",
    author: "Benjamin Graham & David Dodd",
    year: 1934,
    coverImage: "https://m.media-amazon.com/images/I/81StSOpmkjL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Security-Analysis-Foreword-Buffett-Editions/dp/0071592539/",
    category: ["Investing", "Security Analysis"],
    rating: 4.7
  },
  {
    id: "four-pillars-of-investing",
    title: "The Four Pillars of Investing",
    author: "William Bernstein",
    year: 2002,
    coverImage: "https://m.media-amazon.com/images/I/714bscGQDwL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Four-Pillars-Investing-Building-Portfolio/dp/0071747052/",
    category: ["Investing", "Portfolio Management"],
    rating: 4.6
  },
  {
    id: "millionaire-teacher",
    title: "Millionaire Teacher",
    author: "Andrew Hallam",
    year: 2011,
    coverImage: "https://m.media-amazon.com/images/I/61vpTDV-IwL._AC_UF1000,1000_QL80_.jpg",
    affiliateUrl: "https://www.amazon.com/Millionaire-Teacher-Wealth-Should-Learned/dp/1119356296/",
    category: ["Investing", "Financial Independence"],
    rating: 4.7
  }
];
