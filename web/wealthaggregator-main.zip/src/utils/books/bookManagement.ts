
import { FinanceBook } from './types';
import { financeBooks } from './booksData';

// Function to add books not already in our collection
export const addNewBook = (book: FinanceBook): void => {
  if (!financeBooks.some(b => b.id === book.id)) {
    financeBooks.push(book);
  }
};
