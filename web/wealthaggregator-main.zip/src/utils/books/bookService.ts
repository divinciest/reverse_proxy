
import { FinanceBook } from './types';
import { financeBooks } from './booksData';

// Get all finance books
export const getFinanceBooks = (): FinanceBook[] => {
  return financeBooks;
};

// Get book by ID
export const getBookById = (id: string): FinanceBook | undefined => {
  return financeBooks.find(book => book.id === id);
};

// Get featured books
export const getFeaturedBooks = (): FinanceBook[] => {
  return financeBooks.filter(book => book.featured);
};

// Get books by category
export const getBooksByCategory = (category: string): FinanceBook[] => {
  return financeBooks.filter(book => book.category?.includes(category));
};
