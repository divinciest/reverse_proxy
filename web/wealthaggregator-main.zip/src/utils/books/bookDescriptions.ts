
import { FinanceBook } from './types';

// Book descriptions mapped by book ID
export const bookDescriptions: Record<string, string> = {
  "intelligent-investor": "The Intelligent Investor by Benjamin Graham, first published in 1949, is a widely acclaimed book on value investing. The book teaches readers strategies on how to successfully use value investing in the stock market. Historically, the stock market has rewarded investors for buying bargain-priced stocks rather than following market trends.",
  
  "rich-dad-poor-dad": "Rich Dad Poor Dad is Robert's story of growing up with two dads — his real father and the father of his best friend, his rich dad — and the ways in which both men shaped his thoughts about money and investing. The book explodes the myth that you need to earn a high income to be rich and explains the difference between working for money and having your money work for you.",
  
  "millionaire-next-door": "The Millionaire Next Door identifies seven common traits that show up again and again among those who have accumulated wealth. Most of the truly wealthy in America don't live in Beverly Hills or on Park Avenue—they live next door. This book offers a fascinating look at America's wealthy and how they acquired and maintain their wealth.",
  
  "psychology-of-money": "Doing well with money isn't necessarily about what you know. It's about how you behave. And behavior is hard to teach, even to really smart people. Money―investing, personal finance, and business decisions―is typically taught as a math-based field, where data and formulas tell us exactly what to do. But in the real world people don't make financial decisions on a spreadsheet. They make them at the dinner table, or in a meeting room, where personal history, your own unique view of the world, ego, pride, marketing, and odd incentives are scrambled together.",
  
  "random-walk": "A Random Walk Down Wall Street centers around the Efficient Market Hypothesis, which states that individual investors cannot use past stock price performance and public information to beat the market. Burton G. Malkiel's central idea is that it's virtually impossible for individual investors to consistently outperform market averages.",
  
  "richest-man-in-babylon": "The Richest Man in Babylon is a 1926 book by George S. Clason that dispenses financial advice through a collection of parables set 8,000 years ago in ancient Babylon. The book remains in print almost a century after the parables were originally published, and is regarded as a classic of personal financial advice.",
  
  "total-money-makeover": "The Total Money Makeover is a complete guide to getting out of debt, building an emergency fund, and achieving financial success. Ramsey debunks the many myths of money and attacks the illusions and downright deceptions of the American dream, which encourages nothing but overspending and massive amounts of debt.",
  
  "think-and-grow-rich": "Think and Grow Rich was written by Napoleon Hill in 1937 and promoted as a personal development and self-improvement book. He claimed to be inspired by a suggestion from business magnate and later-philanthropist Andrew Carnegie. While the book's title and much of the writing concerns increasing income, the author insists that his philosophy can help people succeed in any line of work, to do and be anything they can imagine.",
  
  "when-genius-failed": "When Genius Failed is the cautionary financial tale of our time, the gripping saga of what happened when an elite group of investors believed they could actually deconstruct risk and use virtually limitless leverage to create limitless wealth. In Roger Lowenstein's hands, it is a brilliant tale peppered with fast money, vivid characters, and high drama.",
  
  "i-will-teach-you-to-be-rich": "At last, for a generation that's materially ambitious yet financially clueless comes I Will Teach You To Be Rich, Ramit Sethi's 6-week personal finance program for 20-to-35-year-olds. A completely practical approach delivered with a nonjudgmental style that makes readers want to do what Sethi says, it is based around the four pillars of personal finance—banking, saving, budgeting, and investing—and the wealth-building ideas of personal entrepreneurship.",
  
  "common-stocks-uncommon-profits": "Widely respected and admired, Philip Fisher is among the most influential investors of all time. His investment philosophies, introduced almost forty years ago, are not only studied and applied by today's financiers and investors, but are also regarded by many as gospel. This book is invaluable reading and has been since it was first published in 1958.",
  
  "simple-path-to-wealth": "The Simple Path to Wealth by JL Collins is a comprehensive guide to financial independence. Collins provides clear and straightforward advice on how to create wealth through low-cost index fund investing. The book emphasizes the importance of living below your means, avoiding debt, and investing in broad market index funds for long-term wealth creation.",
  
  "little-book-common-sense-investing": "The Little Book of Common Sense Investing by Vanguard founder John C. Bogle shares the secret to getting more than your fair share of stock market returns. Bogle describes the simplest and most effective investment strategy for building wealth over the long term: buy and hold, at very low cost, a mutual fund that tracks a broad stock market index such as the S&P 500.",
  
  "bogleheads-guide-investing": "The Bogleheads' Guide to Investing is a hands-on resource for implementing the proven investing advice from legendary mutual fund pioneer John C. Bogle. This witty and wonderful book offers contrarian advice that provides the first step on the road to investment success, illustrating how relying on typical 'common sense' promoted by Wall Street is destined to leave you poorer.",
  
  "one-up-on-wall-street": "In One Up On Wall Street, Peter Lynch explains how everyday investors can achieve better returns than investment professionals by using the knowledge they already have. He explains how to research and select stocks and mutual funds, and shows why it's important to focus on companies you understand and can monitor regularly.",
  
  "your-money-or-your-life": "Your Money or Your Life is a systematic approach to transforming your relationship with money and achieving financial independence. The authors present a nine-step program for living more meaningfully and getting out of debt, allowing you to redesign your life to match your values and withdraw from the workforce earlier than you might have thought possible.",
  
  "essays-warren-buffett": "The Essays of Warren Buffett: Lessons for Corporate America is a collection of Warren Buffett's letters to shareholders of Berkshire Hathaway written over the past few decades. They explain Buffett's foundational principles on management, investing, and corporate governance in extraordinary clarity and simplicity.",
  
  "security-analysis": "Security Analysis is a book written by professors Benjamin Graham and David Dodd of Columbia Business School, which laid the intellectual foundation for what would later be called value investing. The first edition was published in 1934, shortly after the Wall Street crash and start of the Great Depression. It's considered the bible of value investing and is studied by investors worldwide.",
  
  "four-pillars-of-investing": "The Four Pillars of Investing by William Bernstein gives investors the tools they need to construct top-returning portfolios without the help of a financial adviser. In a relaxed, nonthreatening style, Dr. Bernstein provides a distinctive blend of market history, investing theory, and behavioral finance—all presented through the lens of sustainable, long-term investing.",
  
  "millionaire-teacher": "Millionaire Teacher shows how anyone can achieve financial independence through smart investing and the right mindset. Author Andrew Hallam was a high school English teacher who built a million-dollar portfolio on a teacher's salary. He shares nine rules of wealth that helped him become financially independent before he was 40 years old."
};

// Function to get a book description by ID
export const getBookDescription = (bookId: string): string => {
  return bookDescriptions[bookId] || "No description available for this book.";
};

// Function to get a book description by book object
export const getBookDescriptionByBook = (book: FinanceBook): string => {
  return getBookDescription(book.id);
};

