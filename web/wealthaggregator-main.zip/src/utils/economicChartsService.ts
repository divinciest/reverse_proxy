
/**
 * Economic Charts Service
 * This service provides data for various economic charts and indicators
 */

export interface ChartData {
  id: string;
  name: string;
  description: string;
  category: string;
  timeframe: string;
  imageUrl: string;
  dataPoints: Array<{
    date: string;
    value: number;
  }>;
}

// Categories of economic charts
export const chartCategories = [
  'Interest Rates',
  'Stock Market',
  'Employment',
  'Inflation',
  'GDP',
  'Housing',
  'Commodities'
];

// Sample chart data
export const getEconomicCharts = (): ChartData[] => {
  return [
    {
      id: 'federal-funds-rate',
      name: 'Federal Funds Rate',
      description: 'The federal funds rate is the interest rate at which depository institutions trade federal funds with each other overnight. Changes in this rate influence other interest rates and impact broader economic activity.',
      category: 'Interest Rates',
      timeframe: '1954-Present',
      imageUrl: '/lovable-uploads/7b296eec-8c4f-4138-8cf1-5b1b5d219b85.png',
      dataPoints: generateDataPoints(8, 1954, 2024, 0, 20)
    },
    {
      id: '10-year-treasury',
      name: '10-Year Treasury Rate',
      description: 'The 10-year Treasury note is a debt obligation issued by the U.S. Treasury with a 10-year maturity. It is considered a benchmark for other interest rates.',
      category: 'Interest Rates',
      timeframe: '1962-Present',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(8, 1962, 2024, 1, 15)
    },
    {
      id: '1-year-treasury',
      name: '1-Year Treasury Rate',
      description: 'The 1-year Treasury rate represents the yield on U.S. Treasury bills with a maturity of one year. It is an important indicator of short-term interest rates.',
      category: 'Interest Rates',
      timeframe: '1962-Present',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(6, 1962, 2024, 0, 16)
    },
    {
      id: 'libor-rates',
      name: 'LIBOR Rates',
      description: 'LIBOR (London Interbank Offered Rate) is a benchmark interest rate at which major global banks lend to one another in the international interbank market.',
      category: 'Interest Rates',
      timeframe: '1986-2021',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(5, 1986, 2021, 0, 12)
    },
    {
      id: 'ted-spread',
      name: 'TED Spread',
      description: 'The TED spread is the difference between the 3-month LIBOR and the 3-month Treasury bill rate. It is an indicator of credit risk in the general economy.',
      category: 'Interest Rates',
      timeframe: '1986-Present',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(4, 1986, 2024, 0, 4)
    },
    {
      id: 'sp500',
      name: 'S&P 500',
      description: 'The S&P 500 is a stock market index that measures the performance of 500 large companies listed on stock exchanges in the United States.',
      category: 'Stock Market',
      timeframe: '1950-Present',
      imageUrl: '/lovable-uploads/7b296eec-8c4f-4138-8cf1-5b1b5d219b85.png',
      dataPoints: generateDataPoints(10, 1950, 2024, 250, 5000)
    },
    {
      id: 'inflation-rate',
      name: 'Inflation Rate (CPI)',
      description: 'The Consumer Price Index (CPI) measures the average change in prices paid by consumers for a basket of goods and services over time.',
      category: 'Inflation',
      timeframe: '1950-Present',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(6, 1950, 2024, -2, 15)
    },
    {
      id: 'unemployment-rate',
      name: 'Unemployment Rate',
      description: 'The unemployment rate represents the percentage of the total labor force that is unemployed but actively seeking employment and willing to work.',
      category: 'Employment',
      timeframe: '1948-Present',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(7, 1948, 2024, 3, 11)
    },
    {
      id: 'gdp-growth',
      name: 'GDP Growth Rate',
      description: 'The GDP Growth Rate measures how fast the economy is growing, represented as a percentage rate of change in the Gross Domestic Product.',
      category: 'GDP',
      timeframe: '1947-Present',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(5, 1947, 2024, -5, 8)
    },
    {
      id: 'housing-starts',
      name: 'Housing Starts',
      description: 'Housing starts measure the number of new residential construction projects that have begun during a particular period.',
      category: 'Housing',
      timeframe: '1959-Present',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(7, 1959, 2024, 400, 2500)
    },
    {
      id: 'gold-prices',
      name: 'Gold Prices',
      description: 'Gold prices reflect the value of gold per ounce in U.S. dollars, serving as an indicator of investor sentiment and economic uncertainty.',
      category: 'Commodities',
      timeframe: '1950-Present',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(8, 1950, 2024, 35, 2100)
    },
    {
      id: 'oil-prices',
      name: 'Oil Prices (WTI)',
      description: 'West Texas Intermediate (WTI) crude oil prices, measured in U.S. dollars per barrel, are a major benchmark for oil prices worldwide.',
      category: 'Commodities',
      timeframe: '1950-Present',
      imageUrl: '/lovable-uploads/299899c9-1255-4580-aae0-957323f78e4e.png',
      dataPoints: generateDataPoints(9, 1950, 2024, 10, 150)
    }
  ];
};

// Get a specific chart by ID
export const getChartById = (chartId: string): ChartData | undefined => {
  const charts = getEconomicCharts();
  return charts.find(chart => chart.id === chartId);
};

// Get charts by category
export const getChartsByCategory = (category: string): ChartData[] => {
  const charts = getEconomicCharts();
  return charts.filter(chart => chart.category === category);
};

// Helper function to generate realistic mock data points
function generateDataPoints(
  volatility: number, 
  startYear: number, 
  endYear: number,
  minValue: number,
  maxValue: number
): Array<{ date: string; value: number }> {
  const dataPoints = [];
  let currentValue = minValue + Math.random() * (maxValue - minValue) / 2;
  
  // Generate quarterly data points
  for (let year = startYear; year <= endYear; year++) {
    for (let quarter = 1; quarter <= 4; quarter++) {
      // Skip future quarters in the current year
      if (year === endYear && quarter > 1) continue;
      
      // Random walk with mean reversion
      const randomChange = (Math.random() - 0.5) * volatility;
      const meanReversionFactor = 0.1;
      const midPoint = (minValue + maxValue) / 2;
      
      // Calculate the pull towards the midpoint
      const pullToMidpoint = (midPoint - currentValue) * meanReversionFactor;
      
      // Update current value with random change and mean reversion
      currentValue = currentValue + randomChange + pullToMidpoint;
      
      // Ensure value stays within bounds
      currentValue = Math.max(minValue, Math.min(maxValue, currentValue));
      
      // Add recessions every ~10 years
      const isRecession = year % 10 >= 8 && year % 10 <= 9;
      
      // Format date as YYYY-MM-DD
      const month = quarter * 3 - 2;
      const date = `${year}-${month.toString().padStart(2, '0')}-01`;
      
      // During recessions, values tend to decline
      if (isRecession) {
        currentValue = currentValue * 0.95;
      }
      
      dataPoints.push({
        date,
        value: parseFloat(currentValue.toFixed(2))
      });
    }
  }
  
  return dataPoints;
}
