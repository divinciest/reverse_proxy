
// Types that match the backend API response structure
export interface FeedSource {
  _id: string;
  name: string;
  domain: string;
  urls: string[];
  link: string;
  favicon: string;
  color: string;
  enabled: boolean;
  created_at?: string;
}

export interface FeedInfo {
  title: string;
  url: string;
  link: string;
  favicon: string;
  color: string;
  error?: string;
}

export interface CompanyMetadata {
  _id: string;
  name: string;
  domain: string;
  aliases: string[];
  favicon: string;
  color: string;
  enabled: boolean;
  article_count?: number; // Added for company article count from the API
  created_at?: string;
}

export interface Article {
  title: string;
  source: string;
  author: { name: string; image: string | null };
  date: string;
  hoursAgo: number;
  summary: string;
  tags: string[];
  companies: CompanyMetadata[];
  sourceUrl: string;
  sourceLogo: string;
  sourceColor: string;
  id?: string;
  body?: string;
  topic?: string;
}

export interface UserProfile {
  _id: string;
  email: string;
  username?: string;
  role: "user" | "admin";
  profilePicture?: string;
  bio?: string;
  created_at?: string;
}

const API_BASE_URL = "https://api.advisorassist.ai/api";

// Sample RSS feed URLs to use as fallback when API is unavailable
const FALLBACK_RSS_FEEDS = [
  "https://feeds.feedburner.com/TechCrunch/",
  "https://www.wired.com/feed/rss",
  "https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml",
  "https://www.wsj.com/xml/rss/3_7455.xml",
  "https://feeds.a.dj.com/rss/RSSMarketsMain.xml",
  "https://www.ft.com/rss/companies",
  "https://www.ft.com/rss/markets"
];

// Helper function to get the auth token from localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('authToken');
};

// Helper function to create headers with authorization if token exists
const createHeaders = (includeAuth: boolean = false): HeadersInit => {
  const headers: HeadersInit = {
    "Content-Type": "application/json"
  };
  
  if (includeAuth) {
    const token = getAuthToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }
  
  return headers;
};

export const feedService = {
  async getPopularFeeds(): Promise<FeedSource[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/popular_feeds`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch popular feeds: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data.feeds;
    } catch (error) {
      console.error("Error fetching popular feeds:", error);
      // Return some default feeds when API fails
      return Array(5).fill(0).map((_, i) => ({
        _id: `default-${i}`,
        name: `Default Feed ${i+1}`,
        domain: `defaultfeed${i+1}.com`,
        urls: [FALLBACK_RSS_FEEDS[i % FALLBACK_RSS_FEEDS.length]],
        link: `https://defaultfeed${i+1}.com`,
        favicon: "",
        color: "#8b5cf6",
        enabled: true
      }));
    }
  },
  
  async parseRssFeed(url: string): Promise<{ articles: Article[], feedInfo: FeedInfo, companies: CompanyMetadata[] }> {
    try {
      const response = await fetch(`${API_BASE_URL}/parse_rss`, {
        method: "POST",
        headers: createHeaders(),
        body: JSON.stringify({ url })
      });
      
      if (!response.ok) {
        throw new Error(`Failed to parse RSS feed: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error parsing RSS feed:", error);
      throw error;
    }
  },
  
  async getFeedsArticles(urls: string[], since?: number): Promise<{ 
    articles: Article[], 
    feeds: Record<string, FeedInfo>,
    companies: CompanyMetadata[] 
  }> {
    try {
      // Use the new endpoint as described in the API documentation
      const response = await fetch(`${API_BASE_URL}/get_feeds_articles`, {
        method: "POST",
        headers: createHeaders(),
        body: JSON.stringify({ urls, since })
      });
      
      if (!response.ok) {
        throw new Error(`Failed to get feeds articles: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error getting feeds articles:", error);
      throw error;
    }
  },
  
  async clearRssCache(): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/clear_rss_cache`, {
        method: "POST",
        headers: createHeaders()
      });
      
      if (!response.ok) {
        throw new Error(`Failed to clear RSS cache: ${response.status} ${response.statusText}`);
      }
    } catch (error) {
      console.error("Error clearing RSS cache:", error);
      throw error;
    }
  },

  async getCompanyArticles(companyName: string): Promise<{
    company: string;
    articles: Article[];
    feeds_sourced: FeedInfo[];
    companies_metadata: CompanyMetadata[];
  }> {
    try {
      const response = await fetch(`${API_BASE_URL}/company_articles/${encodeURIComponent(companyName)}`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch company articles: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`Error fetching articles for company ${companyName}:`, error);
      throw error;
    }
  },

  async getPlatformCompanies(): Promise<CompanyMetadata[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/platform_companies`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch platform companies: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data.companies;
    } catch (error) {
      console.error("Error fetching platform companies:", error);
      // Return some default companies when API fails
      return Array(5).fill(0).map((_, i) => ({
        _id: `default-company-${i}`,
        name: `Company ${i+1}`,
        domain: `company${i+1}.com`,
        aliases: [],
        favicon: "",
        color: "#8b5cf6",
        enabled: true
      }));
    }
  }
};

// Admin-specific operations for feed sources
export const adminFeedService = {
  async addFeedSource(name: string, urls: string[]): Promise<FeedSource> {
    const token = getAuthToken();
    
    if (!token) {
      throw new Error("Authentication required");
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/admin/feed_source/add`, {
        method: "POST",
        headers: createHeaders(true),
        body: JSON.stringify({ name, urls })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to add feed source: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data.feed;
    } catch (error) {
      console.error("Error adding feed source:", error);
      throw error;
    }
  },
  
  async updateFeedStatus(feedId: string, enabled: boolean): Promise<void> {
    const token = getAuthToken();
    
    if (!token) {
      throw new Error("Authentication required");
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/admin/feed_source/update_status`, {
        method: "POST",
        headers: createHeaders(true),
        body: JSON.stringify({ feed_id: feedId, enabled })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to update feed status: ${response.status} ${response.statusText}`);
      }
    } catch (error) {
      console.error("Error updating feed status:", error);
      throw error;
    }
  },

  async addCompany(name: string, domain: string, aliases?: string[]): Promise<CompanyMetadata> {
    const token = getAuthToken();
    
    if (!token) {
      throw new Error("Authentication required");
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/admin/company/add`, {
        method: "POST",
        headers: createHeaders(true),
        body: JSON.stringify({ name, domain, aliases })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to add company: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      return data.company;
    } catch (error) {
      console.error("Error adding company:", error);
      throw error;
    }
  },
  
  async updateCompanyStatus(companyId: string, enabled: boolean): Promise<void> {
    const token = getAuthToken();
    
    if (!token) {
      throw new Error("Authentication required");
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/admin/company/update_status`, {
        method: "POST",
        headers: createHeaders(true),
        body: JSON.stringify({ company_id: companyId, enabled })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to update company status: ${response.status} ${response.statusText}`);
      }
    } catch (error) {
      console.error("Error updating company status:", error);
      throw error;
    }
  }
};

// Auth service for handling user authentication
export const authService = {
  async signUp(email: string, password: string, username?: string): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/signup`, {
        method: "POST",
        headers: createHeaders(),
        body: JSON.stringify({ email, password, username })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to sign up: ${response.status} ${response.statusText}`);
      }
    } catch (error) {
      console.error("Error signing up:", error);
      throw error;
    }
  },

  async signIn(email: string, password: string): Promise<{ token: string, user: UserProfile }> {
    try {
      const response = await fetch(`${API_BASE_URL}/signin`, {
        method: "POST",
        headers: createHeaders(),
        body: JSON.stringify({ email, password })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to sign in: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      // Store the token in localStorage
      localStorage.setItem('authToken', data.token);
      
      return data;
    } catch (error) {
      console.error("Error signing in:", error);
      throw error;
    }
  },

  async getUserProfile(): Promise<UserProfile> {
    try {
      const response = await fetch(`${API_BASE_URL}/me`, {
        headers: createHeaders(true)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to get user profile: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error("Error getting user profile:", error);
      throw error;
    }
  },

  async updateUserProfile(updates: { username?: string, bio?: string, profilePicture?: string }): Promise<{ message: string, user: UserProfile }> {
    try {
      const response = await fetch(`${API_BASE_URL}/update_profile`, {
        method: "POST",
        headers: createHeaders(true),
        body: JSON.stringify(updates)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to update profile: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error("Error updating user profile:", error);
      throw error;
    }
  },

  getToken(): string | null {
    return getAuthToken();
  },

  isAuthenticated(): boolean {
    return !!getAuthToken();
  },

  logout(): void {
    localStorage.removeItem('authToken');
  }
};
