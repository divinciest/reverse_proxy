
// Define types for the admin interface

export interface FeedSource {
  id: string;
  name: string;
  logo: string | null;
  count: number;
  selected: boolean;
  url: string;
  lastFetched: string;
}

export interface CompanySource {
  id: string;
  name: string;
  logo: string | null;
  count: number;
  selected: boolean;
  url: string;
}

export interface AuthorSource {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  articles: number;
  verified: boolean;
}

export interface TopicSource {
  id: string;
  name: string;
  articles: number;
  trending: boolean;
}

export interface Topic {
  name: string;
  count: number;
  selected: boolean;
}

export interface Tag {
  _id: string;
  tagName: string;
  aliases: string[];
  createdAt?: string;
  lastModified?: string;
}
